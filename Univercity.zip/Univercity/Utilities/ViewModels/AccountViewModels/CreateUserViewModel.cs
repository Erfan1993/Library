﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
namespace Utilities.ViewModels.AccountViewModels
{
    public class CreateUserViewModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Family { get; set; }
        public int NationCode { get; set; }
        public IFormFile Image { get; set; }
        public string PhoneNumber { get; set; }
        public List<SelectListItem> UserRole { get; set; }
        public List <SelectListItem> Fields { get; set; }
        public int FieldID { get; set; }
        public string Email { get; set; }
        public string RoleID { get; set; }
        public string StudentCode { get; set; }
        public string UserName { get; set; }
        public DateTime EnterDate { get; set; }
        public int Average { get; set; }
        public DateTime BirthDate { get; set; }
        public string Password { get; set; }
    }
}
