﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.ViewModels.AccountViewModels
{
    public class RoleViewModel
    {
        public string ID { get; set; }
        public string RoleName { get; set; }
    }
}
