﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.ViewModels.CourseViewModels
{
    public class CreateCoursGroupViewModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public byte ClassRoom { get; set; }
        public byte Capacity { get; set; }
        public DateTime Time { get; set; }
        public DateTime ExampleTime { get; set; }
        public List<SelectListItem> Fields { get; set; }
        public int FieldID { get; set; }
        public List<SelectListItem> Books { get; set; }
        public int BookID { get; set; }
        public List<SelectListItem> Teachers { get; set; }
        public int TeacherID { get; set; }
    }
}
