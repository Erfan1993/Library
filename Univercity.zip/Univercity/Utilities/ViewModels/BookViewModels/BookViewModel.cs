﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities.ViewModels.BookViewModels
{
    public class BookViewModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public byte Units { get; set; }
        public Single Price { get; set; }
        public int PassCode { get; set; }
        public List<SelectListItem> Books { get; set; }
    }
}
