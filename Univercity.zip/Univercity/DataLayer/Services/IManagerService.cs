﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IManagerService
    {
        void AddBook(Book NewBook);
        List<Book> GetAllBooks();
        void Save();
        List<Book> GetAllBooksByFieldID(int FieldId);
        List<User> GetAllTeachersByFieldID(int FieldID);
        List<Fields> GetAllFields();
        void CreateCourseGroup(LearningGroup group);
    }
}
