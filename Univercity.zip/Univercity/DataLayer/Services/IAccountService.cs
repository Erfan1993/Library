﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IAccountService
    {
        bool CreateUser(User User, string Password);
        List<Role> GetAllroles();
        Role GetRoleById(string Id);
        bool AddToRole(User user, string RoleName);
        List<Fields> GetAllfields();
        void AddField(User user, int fieldid);
        void Save();
    }
}
