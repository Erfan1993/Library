﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
    public class Book
    {
        [Key]
        public int ID { get; set; }
        public string Name { get; set; }
        public byte Unit { get; set; }
        public float Price { get; set; }
        public int PassCode { get; set; }

        //[ForeignKey("BookID")]
        public int BookID { get; set; }
        //public virtual Book Books { get; set; }

        [ForeignKey("FieldID")]
        public int FieldID { get; set; }
        public virtual Fields Field { get; set; }
    }
}
