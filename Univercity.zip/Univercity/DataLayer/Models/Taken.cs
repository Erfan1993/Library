﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
    public class Taken
    {
        [Key]
        public int ID { get; set; }
        //public byte Count { get; set; }

        [ForeignKey("Student")]
        public string StudentID { get; set; }
        public virtual User Student { get; set; }

        [ForeignKey("LearningGroup")]
        public int LearningGroupID { get; set; }
        public virtual LearningGroup LearningGroup { get; set; }
    }
}
