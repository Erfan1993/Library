﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
    public class User : IdentityUser
    {
        public string Name { get; set; }
        public string Family { get; set; }
        public int NationCode { get; set; }
        public int PersonalCode { get; set; }
        public string Image { get; set; }

        [ForeignKey("FieldID")]
        public int FieldID { get; set; }
        public virtual Fields Field { get; set; }
    }
}
