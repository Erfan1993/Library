﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
    public class LearningGroup
    {
        [Key]
        public int ID { get; set; }
        public string Name { get; set; }
        public DateTime Time { get; set; }
        public DateTime ExampleTime { get; set; }

        [ForeignKey("TeacherID")]
        public int TeacherID { get; set; }
        public virtual User Teachers { get; set; }
        public byte Capacity { get; set; }
        public byte ClassRoom { get; set; }

        [ForeignKey("BooksID")]
        public int BooksID { get; set; }
        public virtual Book Books { get; set; }

        [ForeignKey("FieldID")]
        public int FieldID { get; set; }
    }
}
