﻿using DataLayer.DataContext;
using DataLayer.Models;
using DataLayer.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class ManagerRepository : IManagerService
    {
        private UnivercityDataContext _context;

        public ManagerRepository(UnivercityDataContext context)
        {
            _context = context;
        }

        public void AddBook(Book NewBook)
        {
            _context.Books.Add(NewBook);
        }

        public void CreateCourseGroup(LearningGroup group)
        {
            _context.LearningGroups.Add(group);
        }

        public List<Book> GetAllBooks()
        {
            return _context.Books.ToList();
        }

        public List<Book> GetAllBooksByFieldID(int FieldId)
        {
            //return _context.Books.Include(a => a.FieldCode).Where(a => a.FieldCode.ID == FieldId).ToList(); 
            return _context.Books.Include(a => a.Field).Where(a => a.Field.ID == FieldId).ToList();
            //return new List<Book>().ToList();
        }

        public List<Fields> GetAllFields()
        {
            return _context.Fields.ToList();
        }

        public List<User> GetAllTeachersByFieldID(int FieldID)
        {
            //return _context.Users.Include(U => U.FieldCode).Where(U => U.FieldCode.ID == FieldID).ToList();
            return _context.Users.Include(U => U.Field).Where(U => U.Field.ID == FieldID).ToList();
            //return new List<User>().ToList();
        }
        public void Save()
        {
            _context.SaveChanges();
        }
    }
}
