﻿using DataLayer.DataContext;
using DataLayer.Models;
using DataLayer.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class AccountRepository : IAccountService
    {
        private SignInManager<User> _SignInManager;
        private UserManager<User> _UserManager;
        private RoleManager<Role> _RoleManager;
        private UnivercityDataContext _context;

        public AccountRepository(UnivercityDataContext context
                                 , SignInManager<User> signInManager
                                 , UserManager<User> userManager
                                 , RoleManager<Role> roleManager)
        {
            _context = context;
            _SignInManager = signInManager;
            _UserManager = userManager;
            _RoleManager = roleManager;
        }

        public void AddField(User user, int fieldid)
        {
            var m = _context.Users.Find(user.Id);
            var f = _context.Fields.Find(fieldid);
            //m.FieldCode = f;

            _context.Users.Update(m);
        }

        public bool AddToRole(User user, string RoleName)
        {
            var res = _UserManager.AddToRoleAsync(user, RoleName);
            if (res.Result.Succeeded)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool CreateUser(User User, string Password)
        {
            if (User != null)
            {
                var a = _UserManager.CreateAsync(User, Password);
                if (a.Result.Succeeded)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        public List<Fields> GetAllfields()
        {
            return _context.Fields.ToList();
        }
        public List<Role> GetAllroles()
        {
            return _context.Roles.ToList();
        }
        public Role GetRoleById(string Id)
        {
            return _context.Roles.Find(Id);
        }
        public void Save()
        {
            _context.SaveChanges();
        }


    }
}
