﻿using DataLayer.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.DataContext
{
    public class UnivercityDataContext : IdentityDbContext<User, Role, string>
    {
        public UnivercityDataContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Taken> Takens { get; set; }
        public DbSet<LearningGroup> LearningGroups { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Fields> Fields { get; set; }
    }
}
