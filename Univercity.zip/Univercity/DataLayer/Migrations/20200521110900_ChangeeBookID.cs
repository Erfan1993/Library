﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class ChangeeBookID : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Books_Books_BooksID",
                table: "Books");

            migrationBuilder.DropIndex(
                name: "IX_Books_BooksID",
                table: "Books");

            migrationBuilder.DropColumn(
                name: "BooksID",
                table: "Books");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BooksID",
                table: "Books",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Books_BooksID",
                table: "Books",
                column: "BooksID");

            migrationBuilder.AddForeignKey(
                name: "FK_Books_Books_BooksID",
                table: "Books",
                column: "BooksID",
                principalTable: "Books",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
