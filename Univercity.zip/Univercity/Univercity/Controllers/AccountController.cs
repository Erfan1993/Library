﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataLayer.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Utilities.ViewModels.AccountViewModels;

namespace Univercity.Controllers
{
    public class AccountController : Controller
    {
        private IAccountService _AccountServices;
        public AccountController(IAccountService acntservice)
        {
            _AccountServices = acntservice;
        }
        [HttpGet]
        public IActionResult login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginViewModel User)
        {

            
            return View();
        }

    }
}