﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using DataLayer.Models;
using DataLayer.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Utilities.ViewModels.AccountViewModels;
using Utilities.ViewModels.BookViewModels;
using Utilities.ViewModels.CourseViewModels;

namespace Univercity.Controllers
{
    public class ManagerController : Controller
    {
        private IAccountService _AccountServices;
        private IServiceProvider _serviceProvider;
        private IManagerService _ManagerService;
        private IHostingEnvironment _AppEnvironment;
        public ManagerController(IAccountService account
                                 , IServiceProvider service
                                 , IManagerService managerService
                                 , IHostingEnvironment hostingEnvironment)
        {
            _AccountServices = account;
            _serviceProvider = service;
            _ManagerService = managerService;
            _AppEnvironment = hostingEnvironment;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult CreateStudent()
        {
            var model = new CreateUserViewModel();
            var roles = _AccountServices.GetAllroles();
            var fields = _AccountServices.GetAllfields();
            model.UserRole = roles.Select(r => new SelectListItem
            {
                Text = r.Name,
                Value = r.Id
            }).ToList();

            model.Fields = fields.Select(f => new SelectListItem
            {
                Text = f.FieldName,
                Value = f.ID.ToString()
            }).ToList();

            return View(model);
        }

        [HttpPost]
        public IActionResult CreateStudent(CreateUserViewModel input)
        {
            if (ModelState.IsValid)
            {

                var model = new User()
                {
                    Name = input.Name,
                    Family = input.Family,
                    UserName = input.UserName,
                    Email = input.Email,
                    NationCode = input.NationCode,
                    PhoneNumber = input.PhoneNumber,
                    PersonalCode = input.NationCode
                };

                var Imagemodel = input.Image;
                if (Imagemodel != null && Imagemodel.Length > 0)
                {
                    var uploads = Path.Combine(_AppEnvironment.WebRootPath, @"Image\");
                    if (Imagemodel.Length > 0)
                    {
                        var fileName = Guid.NewGuid().ToString().Replace("-", "") + Path.GetExtension(Imagemodel.FileName);
                        using (var fileStream = new FileStream(Path.Combine(uploads, fileName), FileMode.Create))
                        {
                            Imagemodel.CopyToAsync(fileStream);
                            model.Image = fileName;
                        }
                    }
                }

                string Pass = input.Password;
                var res = _AccountServices.CreateUser(model, Pass);

                if (res == true)
                {
                    string RoleName = _AccountServices.GetRoleById(input.RoleID).Name.ToString();
                    _AccountServices.AddToRole(model, RoleName);
                    _AccountServices.AddField(model, input.FieldID);
                }
                else if (res == false)
                {

                }

                _AccountServices.Save();
            }
            return RedirectToAction("CreateStudent");
        }

        [HttpGet]
        public IActionResult AddBook()
        {
            var model = new BookViewModel();
            var res = _ManagerService.GetAllBooks();
            model.Books = res.Select(a => new SelectListItem
            {
                Text = a.Name,
                Value = a.ID.ToString()
            }).ToList();
            return View(model);
        }

        [HttpPost]
        public IActionResult AddBook(BookViewModel InputModel)
        {
            var model = new Book()
            {
                Name = InputModel.Name,
                Price = InputModel.Price,
                Unit = InputModel.Units,
                PassCode = InputModel.PassCode
            };
            _ManagerService.AddBook(model);
            _ManagerService.Save();
            return RedirectToAction("AddBook");
        }

        [HttpGet]
        public IActionResult CreateGroupCourse()
        {
            var output = new CreateCoursGroupViewModel();

            var fields = _ManagerService.GetAllFields();
            output.Fields = fields.Select(a => new SelectListItem
            {
                Text = a.FieldName,
                Value = a.ID.ToString()
            }).ToList();

            return View(output);
        }

        [HttpPost]
        public IActionResult CreateGroupCourseStep_1(CreateCoursGroupViewModel Input)
        {
            var book = _ManagerService.GetAllBooksByFieldID(Input.FieldID);
            var teacher = _ManagerService.GetAllTeachersByFieldID(Input.FieldID);
            Input.Books = book.Select(F => new SelectListItem
            {
                Text = F.Name,
                Value = F.ID.ToString()
            }).ToList();
            Input.Teachers = teacher.Select(T => new SelectListItem
            {
                Text = T.Name,
                Value = T.Id
            }).ToList();
            return View(Input);
        }

        [HttpPost]
        public IActionResult KeepGroup(CreateCoursGroupViewModel Input)
        {
            //var res = new LearningGroup()
            //{
            //    Name = Input.Name,
            //    Capacity = Input.Capacity,
            //    ClassRoom = Input.ClassRoom,
            //    ExampleTime = Input.ExampleTime,
            //    Time = Input.Time,
            //    FieldCode = Input.FieldID,
            //    BookCode = Input.BookID,
            //    TID = Input.TeacherID
            //};

            //_ManagerService.CreateCourseGroup(res);

            _ManagerService.Save();


            return RedirectToAction("CreateGroupCourse");
        }
    }
}