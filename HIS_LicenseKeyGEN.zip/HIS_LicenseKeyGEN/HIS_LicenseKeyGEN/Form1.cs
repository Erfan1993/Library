﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HIS_LicenseKeyGEN
{
    public partial class HIS_LicenseKeyGEN : Form
    {
        public HIS_LicenseKeyGEN()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = txtSNDate.Text.Trim().Replace("/", "").Replace(" ", "");
            txtLicense.Text = "";
            if (str .Length != 8)
            {
                MessageBox.Show("تاریخ 8 رقم میباشد");
                return;
            }
            string time = DateTime.Now.ToString("HH:mm tt");

            time = time.Substring(0, 5);
            time = time.Replace(":", "");
            str = str + time;
            char[] ch = new char[str.Length];
            string temp = "";

            for (int i = 0; i <= str.Length - 1; i++)
            {
                char s = str[i];
                ch[i] = s;
                int a = (int)ch[i];
                a += 30;
                temp += a.ToString();
            }
            string temp2;
            int counter = 0;
            for (int j = 0; j < temp.Length; j += 2)
            {
                counter++;
                temp2 = temp[j] + "" + temp[j + 1];

                char t = (char)(Convert.ToInt32(temp2));
                txtLicense.Text += t;
                if (counter == 4)
                {
                    txtLicense.Text += "-";
                    counter = 0;
                }
            }
            txtLicense.Text = txtLicense.Text.Substring(0,14);
        }
    }
}
