﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoreLibraryProject.Models.ViewModels
{
    public class LoginViewModel
    {
        [Display(Name ="نام کاربری")]
        [Required(ErrorMessage ="نام کاربری را وارد کنید")]
        public string UserName{ get; set; }



        [Display(Name = "رمز عبور ")]
        [Required(ErrorMessage = "رمز عبور را وارد کنید")]
        [DataType(DataType.Password)]
        public string Pawword{ get; set; }


        [Display(Name = "مرا بخاطر بسپار  ")]
        public bool RememberMe{ get; set; }

    }
}
