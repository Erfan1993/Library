﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoreLibraryProject.Models.ViewModels
{
    public class UserViewModel
    {
        public string ID { get; set; }

        [Display(Name = "نام کاربری")]
        [Required(ErrorMessage = "نام کاربری را وارد کنید")]
        public string UserName { get; set; }

        [Display(Name = "کلمه عبور")]
        [Required(ErrorMessage = "کلمه عبور را وارد کنید")]
        [DataType(DataType.Password)]
        [StringLength(20, MinimumLength = 6, ErrorMessage = "حداقل طول رمز عبور و حد اکـثر 20-6 کاراکتر")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "تکرار کلمه عبور")]
        [Required(ErrorMessage = " تکرار کلمه عبور را وارد کنید")]
        [Compare("Password",ErrorMessage ="تکرار رمز عبور اشتباه است")]
        public string ConfirmPassword { get; set; }


        //[Display(Name = "نام و نام خانوادگی ")]
        //[Required(ErrorMessage = "نام و نام خانوادگی را وارد نمایید")]
        //public string FullName { get; set; }


        [Display(Name = "نام خانوادگی")]
        [Required(ErrorMessage = "نام را وارد نمایید")]
        public String FirstName{ get; set; }

        [Display(Name = "نام")]
        [Required(ErrorMessage = "نام خانوادگی را وارد نمایید")]
        public string LastName{ get; set; }

        [Display(Name ="شماره تلفن")]
        [Required(ErrorMessage ="شماره تلفن را وارد کنید")]
        public  string PhoneNumber { get; set; }

        [DataType(DataType.EmailAddress)]
        [Display(Name = "ایمیل")]
        [Required(ErrorMessage = "ایمیل را وارد نمایید")]
        public string Email { get; set; }
        
        /// <summary>
        /// for show role in DropDown
        /// </summary>
        public List<SelectListItem> ApplicationRoles { get; set; }

        [Display(Name = "نقش")]
        public string ApplicationRoleId { get; set; }
    }
}
