﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoreLibraryProject.Models.ViewModels
{
    public class ApplicationRoleViewModel
    {
        public string Id { get; set; }

        [Display(Name ="عنوان نقش")]
        [Required(ErrorMessage ="عنوان نقش را وارد نمایید")]
        public string Name { get; set; }

        [Display(Name ="توضیحات نقش")]

        [Required(ErrorMessage ="توضیحات نقش را وارد نمایید")]
        public string Description { get; set; }
        public int NumberOfUser { get; set; }
    }
}
