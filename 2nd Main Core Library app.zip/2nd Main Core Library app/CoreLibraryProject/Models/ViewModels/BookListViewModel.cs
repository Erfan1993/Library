﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoreLibraryProject.Models.ViewModels
{
    public class BookListViewModel
    {
  
        public int BookId { get; set; }

        [Display(Name = "نام کتاب")]
        public string BookName { get; set; }


        [Display(Name = "تعداد صفحات")]
      
        public int BookPageCount { get; set; }

        [Display(Name = "تصویر کتاب")]
        public string BookImage { get; set; }


        public int AutherID { get; set; }



        public int BookGroupId { get; set; }


        [Display(Name = "نویسنده ")]
        public string AutherName { get; set; }

        [Display(Name = "گروهبندی  ")]
        public string BookGroupName { get; set; }
    }
}
