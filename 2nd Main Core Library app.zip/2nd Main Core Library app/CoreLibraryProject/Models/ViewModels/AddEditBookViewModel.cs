﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoreLibraryProject.Models.ViewModels
{
    public class AddEditBookViewModel
    {
        [Key]
        public int BookId { get; set; }


        [Display(Name = "نام کتاب :")]
        [Required(ErrorMessage = "نام کتاب را وارد کنید")]
        public string BookName { get; set; }

        [Display(Name = "توضیحات کتاب :")]
        [Required(ErrorMessage = "توضیحات کتاب را وارد کنید")]
        public string BookDescription { get; set; }

        [Display(Name = "تعد صفحات  :")]
        //[Required(ErrorMessage = "تعداد ضفحات کتاب را وارد کنید")]
        public int BookPageCount { get; set; }

        [Display(Name = "تصویر کتاب :")]
        //[Required(ErrorMessage = "تصویر کتاب را وارد کنید")]
        public string BookImage { get; set; }


        ////////////////////////////

        [Display(Name = "گروهبندی")]
        public int BookGroupID { get; set; }
        public List<SelectListItem> BookGroups { get; set; }



        [Display(Name = "نام نویسنده")]
        public int AutherId { get; set; }
        public List<SelectListItem> Authers { get; set; }

    }
}
