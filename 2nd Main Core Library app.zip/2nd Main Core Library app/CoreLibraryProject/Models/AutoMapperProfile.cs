﻿using AutoMapper;
using CoreLibraryProject.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreLibraryProject.Models
{
    public class AutoMapperProfile : Profile
    {

        public AutoMapperProfile()
        {
            CreateMap<AddEditBookViewModel, Book>();

        }

    }
}
