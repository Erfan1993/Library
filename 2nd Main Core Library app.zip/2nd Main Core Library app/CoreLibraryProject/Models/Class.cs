﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoreLibraryProject.Models
{
    public class Class
    {
        //model auther
        [Key]
        public int AutherId { get; set; }

        [Display(Name = "نام نویسنده")]
        [Required(ErrorMessage = "نام نویسنده زا وارد کنید")]
        public string AutherName { get; set; }

        [Display(Name = "درباره  نویسنده")]
        [Required(ErrorMessage = "توضیحات را وارد نمایید")]
        public string AutherDescription { get; set; }


        public virtual ICollection<Book> Books { get; set; }
    }
}
