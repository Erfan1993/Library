﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CoreLibraryProject.Models
{
    public class Book
    {
        //model book
        [Key]
        public int BookId { get; set; }
        public string BookName { get; set; }
        public string BookDescription { get; set; }
        public int BookPageCount { get; set; }
        public string BookImage { get; set; }

        /////////////////////////////////////

        [ForeignKey("AutherId")]
        public int AutherId { get; set; }
        public virtual model Authers { get; set; }


        public int BookGroupIDs { get; set; }
        [ForeignKey("BookGroupId")]
        public virtual BookGroup BookGroups { get; set; }
    }
}
