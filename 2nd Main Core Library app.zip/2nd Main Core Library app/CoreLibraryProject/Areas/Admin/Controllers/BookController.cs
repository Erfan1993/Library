using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreLibraryProject.Models;
using CoreLibraryProject.Models.ViewModels;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using Microsoft.AspNetCore.Authorization;

namespace CoreLibraryProject.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class BookController : Controller
    {
        private ApplicationDbContext _Context;
        private IServiceProvider _serviceProvider;
        private readonly IHostingEnvironment _AppEnvironment;
        public BookController(IHostingEnvironment AppEnvironment, ApplicationDbContext dbContext, IServiceProvider serviceProvider)
        {
            _Context = dbContext;
            _serviceProvider = serviceProvider;
            _AppEnvironment = AppEnvironment;

        }
        [HttpGet]
        public IActionResult Index()
        {
            List<BookListViewModel> model = new List<BookListViewModel>();

            var query = (from b in _Context.books
                         join a in _Context.authors on b.AutherId equals a.AutherId
                         join bg in _Context.bookGroups on b.BookGroupIDs equals bg.BookGroupId


                         select new
                         {
                             b.BookId,
                             b.BookName,
                             b.BookPageCount,
                             b.BookImage,
                             b.AutherId,
                             b.BookGroupIDs,
                             a.AutherName,
                             bg.BbookGroupName

                         });

            foreach (var item in query)
            {
                BookListViewModel obj_model = new BookListViewModel();
                obj_model.BookId = item.BookId;
                obj_model.BookName = item.BookName;
                obj_model.BookImage = item.BookImage;
                obj_model.BookPageCount = item.BookPageCount;
                obj_model.AutherID = item.AutherId;
                obj_model.BookGroupId = item.BookGroupIDs;
                obj_model.AutherName = item.AutherName;
                obj_model.BookGroupName = item.BbookGroupName;


                model.Add(obj_model);

            }
            return View(model);
        }

        [HttpGet]
        public IActionResult AddBook()
        {
            AddEditBookViewModel model = new AddEditBookViewModel();

            model.BookGroups = _Context.bookGroups.Select(bg => new SelectListItem
            {
                Text = bg.BbookGroupName,
                Value = bg.BookGroupId.ToString()
            }).ToList();

            model.Authers = _Context.authors.Select(a => new SelectListItem
            {
                Text = a.AutherName,
                Value = a.AutherId.ToString()
            }).ToList();


            return PartialView("_AddEditBook", model);
        }

        public IActionResult EditBook(int ID)
        {
            AddEditBookViewModel model = new AddEditBookViewModel();
            model.BookGroups = _Context.bookGroups.Select(bg => new SelectListItem
            {
                Text = bg.BbookGroupName,
                Value = bg.BookGroupId.ToString()
            }).ToList();

            model.Authers = _Context.authors.Select(a => new SelectListItem
            {
                Text = a.AutherName,
                Value = a.AutherId.ToString()
            }).ToList();

            if (ID != 0)
            {
                using (var db = _serviceProvider.GetRequiredService<ApplicationDbContext>())
                {
                    Book book = _Context.books.Where(b => b.BookId == ID).SingleOrDefault();
                    if (book != null)
                    {
                        model.BookId = book.BookId;
                        model.BookName = book.BookName;
                        model.BookDescription = book.BookDescription;
                        model.BookPageCount = book.BookPageCount;
                        model.AutherId = book.AutherId;
                        model.BookGroupID = book.BookGroupIDs;

                    }
                }
            }

            return PartialView("_AddEditBook", model);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        //public async Task<IActionResult> AddEditBook(int BookId, AddEditBookViewModel model, IEnumerable<IFormFile> files)
        public IActionResult AddEditBook(int BookId, AddEditBookViewModel model, string RedirectUrl)
        {

       
            //if (ModelState.IsValid)
            //{
            //    var upload = System.IO.Path.Combine(_AppEnvironment.WebRootPath, "Upload\\NormalImage\\");
            //    foreach (var file in files)
            //    {
            //        if (file != null && file.Length > 0)
            //        {
            //            var filename = Guid.NewGuid().ToString().Replace("-", "") + Path.GetExtension(file.FileName);
            //            using (var fx = new FileStream(Path.Combine(upload, filename), FileMode.Create))
            //            {
            //                await file.CopyToAsync(fx);
            //                model.BookImage = filename;
            //            }
            //            /////// Resize image//////////
            //            InsertShowImage.ImageResizer img = new InsertShowImage.ImageResizer();
            //            img.Resize(upload + filename, _AppEnvironment.WebRootPath + "\\Upload\\TumbnailImage\\"+filename);
            //            /////// Resize image
            //        }
            //        if (BookId==0)
            //        {
            //            using (var db = _serviceProvider.GetRequiredService<ApplicationDbContext>())
            //            {
            //                Book bookmodel = AutoMapper.Mapper.Map<AddEditBookViewModel, Book>(model);
            //                db.books.Add(bookmodel);
            //                db.SaveChanges();
            //            }
            //            return Json(new { status = "success", message = "کتاب ایجاد شد" });
            //        }
            //        else
            //        {
            //            using (var db = _serviceProvider.GetRequiredService<ApplicationDbContext>())
            //            {
            //                Book bookmodel = AutoMapper.Mapper.Map<AddEditBookViewModel, Book>(model);
            //                db.books.Update(bookmodel);
            //                db.SaveChanges();
            //            }
            //            return Json(new { status = "success", message = "کتاب ویرایش شد" });
            //        }
            //    }
            //}
            //model.BookGroups = _Context.bookGroups.Select(bg => new SelectListItem
            //{
            //    Text = bg.BbookGroupName,
            //    Value = bg.BookGroupId.ToString()
            //}).ToList();
            //model.Authers = _Context.authors.Select(a => new SelectListItem
            //{
            //    Text = a.AutherName,
            //    Value = a.AutherId.ToString()
            //}).ToList();
            //return Json(new { status = "error", message = "کتاب ویرایش شد" });


            if (ModelState.IsValid)
            {
                if (BookId == 0)
                {
                    using (var db = _serviceProvider.GetRequiredService<ApplicationDbContext>())
                    {
                        Book bookmodel1 = AutoMapper.Mapper.Map<AddEditBookViewModel, Book>(model);
                        db.books.Add(bookmodel1);
                        db.SaveChanges();
                    }
                    return PartialView("SuccessfullyResponse", RedirectUrl);
                }
                else
                {
                    using (var db = _serviceProvider.GetRequiredService<ApplicationDbContext>())
                    {
                        Book bookmodel1 = AutoMapper.Mapper.Map<AddEditBookViewModel, Book>(model);
                        db.books.Update(bookmodel1);
                        db.SaveChanges();
                    }
                    return PartialView("SuccessfullyResponse", RedirectUrl);
                }
            }
            return PartialView("_AddEditBook", model);
        }


        [HttpGet]
        public IActionResult Deletebook(int id)
        {
            var model = new Book();
            using (var db = _serviceProvider.GetRequiredService<ApplicationDbContext>())
            {
                model = db.books.Where(b => b.BookId == id).SingleOrDefault();
                if (model == null)
                {
                    return RedirectToAction("Index");
                }
            }
            return PartialView("_DeleteBook", model);
        }



        [HttpPost]
        public IActionResult Deletebook(int id,IFormCollection form)
        {
            using (var db = _serviceProvider.GetRequiredService<ApplicationDbContext>())
            {
                var model = _Context.books.Where(b => b.BookId == id).SingleOrDefault();



                if (model.BookImage == null)
                {
                    var normal_path = System.IO.Path.Combine(_AppEnvironment.WebRootPath, "Upload\\NormalImage\\") + model.BookImage;
                    if (System.IO.File.Exists(normal_path))
                    {
                        System.IO.File.Delete(normal_path);
                    }
                    var thumbnail_Image = System.IO.Path.Combine(_AppEnvironment.WebRootPath, "Upload\\thumbnailsImage\\") + model.BookImage;
                    if (System.IO.File.Exists(thumbnail_Image))
                    {
                        System.IO.File.Delete(thumbnail_Image);
                    }
                }
                db.books.Remove(model);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
        }
    }
}