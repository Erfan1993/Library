using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreLibraryProject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace CoreLibraryProject.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin")]
    public class AutherController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceProvider;

        public AutherController(ApplicationDbContext context, IServiceProvider serviceProvider)
        {
            _context = context;
            _iserviceProvider = serviceProvider;
        }


        [HttpGet]
        public async Task< IActionResult >Index()
        {
            //List<Auther> model = new List<Auther>();
            //model = _context.authors.Select(a => new Auther
            //{
            //    AutherId=a.AutherId,
            //    AutherName=a.AutherName,
            //    AutherDescription=a.AutherDescription
            //}).ToList();


            var model = _context.authors.Include(a => a.Books);

            return View(await model.ToListAsync());
           
        }

        [HttpGet]
        public IActionResult AddEditAuther(int Id)
        {
            var auther = new model();

            if (Id != 0)
            {
                using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
                {
                    auther = _context.authors.Where(a => a.AutherId == Id).SingleOrDefault();
                    if (auther  == null)
                    {
                        return RedirectToAction("Index");
                    }
                }
            }

            return PartialView("_AddEditAuther", auther);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddEditAuther(model model,int ID,string RedirectUrl)
        {

            if (ModelState.IsValid)
            {
                if (ID == 0)
                {
                    using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
                    {
                        db.authors.Add(model);
                        db.SaveChanges();
                    }
                    //return RedirectToAction("Index");
                    return PartialView("SuccessfullyResponse", RedirectUrl);
                }
                else
                {
                    using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
                    {
                        db.authors.Update(model);
                        db.SaveChanges();
                    }
                    return PartialView("SuccessfullyResponse", RedirectUrl);
                    //return RedirectToAction("Index");
                }
            }
            else
            {
                return PartialView("_AddEditAuther", model);
            }

        }

        public virtual ICollection<Book> books { get; set; }



        [HttpGet]
        public IActionResult DeleteAuther(int ID)
        {
            //var tblauthers = new author();
            //using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
            //{

            //    tblauthers = db.authors.Where(bg => bg.AutherId == ID).SingleOrDefault();
            //    if (tblauthers == null)
            //    {
            //        return RedirectToAction("Index");

            //    }
            //    else
            //    {
            //return PartialView("_DeleteAuther", tblauthers.BbookGroupName);
            //    }
            //}
            return PartialView("_DeleteAuther");
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteAuther(int id, string d)
        {
            using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
            {
                var tblauthers = db.authors.Where(a => a.AutherId == id).SingleOrDefault();

                db.authors.Remove(tblauthers);
                db.SaveChanges();
                return RedirectToAction("Index");

            }

        }



    }
}