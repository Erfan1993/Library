using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreLibraryProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace CoreLibraryProject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class BookGroupController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceProvider;

        public BookGroupController(ApplicationDbContext context, IServiceProvider serviceProvider)
        {
            _context = context;
            _iserviceProvider = serviceProvider;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {

            var model = _context.bookGroups.Include(b => b.books);
            return View(await model.ToListAsync());


            //List<BookGroup> model = new List<BookGroup>();
            //model = _context.bookGroups.Select(bg => new BookGroup
            //{
            //    BookGroupId = bg.BookGroupId,
            //    BbookGroupName = bg.BbookGroupName,
            //    Description = bg.Description


            //}).ToList();
            //return View(model);
        }
        [HttpGet]
        public IActionResult AddEditBooKGroup(int Id)
        {

            var model = new BookGroup();

            if (Id != 0)
            {
                using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
                {
                    model = _context.bookGroups.Where(a => a.BookGroupId == Id).SingleOrDefault();
                    if (model == null)
                    {
                        return RedirectToAction("Index");
                    }
                }
            }

            return PartialView("_AddEditBooKGroup", model);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddEditBooKGroup(BookGroup Model, int ID, string RedirectUrl)
        {
            if (ModelState.IsValid)
            {
                //if info was true
                if (ID == 0)
                {
                    //insert
                    using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
                    {
                        db.bookGroups.Add(Model);
                        db.SaveChanges();
                    }
                    //return RedirectToAction("Index");
                    return PartialView("SuccessfullyResponse", RedirectUrl);

                }
                else
                {
                    //update
                    using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
                    {
                        db.bookGroups.Update(Model);
                        db.SaveChanges();
                    }
                    return PartialView("SuccessfullyResponse", RedirectUrl);
                    //return RedirectToAction("Index");
                }


            }
            else
            {
                return PartialView("_AddEditBookGroup", Model);
            }
        }

        [HttpGet]
        public IActionResult DeleteBookGroup(int ID)
        {
            var tblBookgroup = new BookGroup();
            using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>()) {

                tblBookgroup = db.bookGroups.Where(bg => bg.BookGroupId == ID).SingleOrDefault();
                if (tblBookgroup == null)
                {
                    return RedirectToAction("Index");

                }
                else
                {
                    return PartialView("_deleteGroup", tblBookgroup.BbookGroupName);
                }
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteBookGroup(int id,string d)
        {
            using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
            {
                var tblbookgroup = db.bookGroups.Where(bg => bg.BookGroupId == id).SingleOrDefault();

                    db.bookGroups.Remove(tblbookgroup);
                    db.SaveChanges();
                    return RedirectToAction("Index");
               
            }

        }

    }
}