using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreLibraryProject.Models;
using CoreLibraryProject.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CoreLibraryProject.Areas.Admin.Controllers
{
    [Area("admin")]
    [Authorize(Roles = "Admin")]
    public class userController : Controller
    {
        private readonly UserManager<ApplicationUser> _UserManager;
        private readonly RoleManager<ApplicationRole> _RoleManager;
        public userController(UserManager<ApplicationUser> UserManager, RoleManager<ApplicationRole> RoleManager)
        {
            _UserManager = UserManager;
            _RoleManager = RoleManager;
        }


        [HttpGet]
        public IActionResult Index()
        {
            List<UserListViewModel> model = new List<UserListViewModel>();
            model = _UserManager.Users.Select(u => new UserListViewModel
            {
                ID = u.Id,
                Name = u.FirstName + " " + u.Family,
                Email = u.Email
            }).ToList();

            return View(model);
        }


        [HttpGet]
        public IActionResult AddUser()
        {
            UserViewModel model = new UserViewModel();
            model.ApplicationRoles = _RoleManager.Roles.Select(r => new SelectListItem
            {
                Text = r.Name,
                Value = r.Id
            }).ToList();

            return PartialView("_AddUser", model);
        }

        [HttpPost]
        public async Task<IActionResult> AddUser(UserViewModel model, string RedirectUrl)
        {

            if (ModelState.IsValid)
            {
                ApplicationUser User = new ApplicationUser()
                {
                    FirstName = model.FirstName,
                    Family = model.LastName,
                    PhoneNumber = model.PhoneNumber,
                    UserName = model.UserName,
                    Email = model.Email


                };

                IdentityResult result = await _UserManager.CreateAsync(User, model.Password);
                if (result.Succeeded)
                {
                    ApplicationRole approle = await _RoleManager.FindByIdAsync(model.ApplicationRoleId);
                    if (approle != null)
                    {
                        IdentityResult roleresult = await _UserManager.AddToRoleAsync(User, approle.Name);
                        if (roleresult.Succeeded)
                        {
                            return PartialView("SuccessfullyResponse", RedirectUrl);
                        }
                    }
                }

            }


            return PartialView("_AddUser", model);
        }


        [HttpGet]
        public async Task<IActionResult> EditUser(string Id)
        {
            EditUserViewModel model = new EditUserViewModel();
            model.ApplicationRoles = _RoleManager.Roles.Select(r => new SelectListItem
            {
                Text = r.Name,
                Value = r.Id

            }).ToList();
            //////////////////////



            if (!string.IsNullOrEmpty(Id))
            {
                ApplicationUser user = await _UserManager.FindByIdAsync(Id);
                if (user != null)
                {
                    model.FirstName = user.FirstName;
                    model.LastName = user.Family;
                    model.Email = user.Email;
                    model.ApplicationRoleId = _RoleManager.Roles.Single(r => r.Name ==
                    _UserManager.GetRolesAsync(user).Result.Single()).Id;
                }
            }



            return PartialView("_EditUser", model);


        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditUser(string Id, EditUserViewModel model, string RedirectUrl)
        {

            if (ModelState.IsValid)
            {
                ApplicationUser User = await _UserManager.FindByIdAsync(Id);
                if (User != null)
                {
                    User.FirstName = model.FirstName;
                    User.Family = model.LastName;
                    User.Email = model.Email;

                    string existingrole = _UserManager.GetRolesAsync(User).Result.Single();
                    string existingRoleid = _RoleManager.Roles.Single(r => r.Name == existingrole).Id;

                    IdentityResult reslt = await _UserManager.UpdateAsync(User);
                    if (reslt.Succeeded)
                    {
                        if (existingRoleid != model.ApplicationRoleId)
                        {
                            IdentityResult roleresult = await _UserManager.RemoveFromRoleAsync(User, existingrole);
                            if (roleresult.Succeeded)
                            {
                                ApplicationRole approle = await _RoleManager.FindByIdAsync(model.ApplicationRoleId);
                                if (approle != null)
                                {
                                    IdentityResult newrole = await _UserManager.AddToRoleAsync(User, approle.Name);
                                    if (newrole.Succeeded)
                                    {
                                        return PartialView("SuccessfullyResponse", RedirectUrl);
                                    }
                                }
                            }
                        }
                    }

                }

            }
            return PartialView("_EditUser", model);

        }


        [HttpGet]
        public async Task<IActionResult> Deleteuser(string id)
        {
            string name = null;
            if (!String.IsNullOrEmpty(id))
            {
                ApplicationUser applicationUser = await _UserManager.FindByIdAsync(id);
                if(applicationUser != null)
                {
                    name = applicationUser.FirstName + applicationUser.Family; 
                }
                
            }

          
            return PartialView("_DeleteUser", name);
        }


        [HttpPost]
        public async Task<IActionResult> Deleteuser(string id , IFormCollection form)
        {
            if (!String.IsNullOrEmpty(id))
            {
                ApplicationUser au = await _UserManager.FindByIdAsync(id);
                if (au != null)
                {
                    IdentityResult resultuser = await _UserManager.DeleteAsync(au);
                    if (resultuser.Succeeded)
                    {
                        return View("Index");
                        //return RedirectToAcction("Index");
                    }
                }
            }
            return View();
        }

    }
}
