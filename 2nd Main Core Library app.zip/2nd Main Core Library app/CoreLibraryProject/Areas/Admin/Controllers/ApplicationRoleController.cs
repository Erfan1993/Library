using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreLibraryProject.Models;
using CoreLibraryProject.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace CoreLibraryProject.Areas.Admin.Controllers
{
    [Area("admin")]
    [Authorize(Roles = "Admin")]

    public class ApplicationRoleController : Controller
    {
        private readonly UserManager<ApplicationUser> _UserManager;
        private readonly RoleManager<ApplicationRole> _RoleManager;

        public ApplicationRoleController(UserManager<ApplicationUser> UserManager, RoleManager<ApplicationRole> RoleManager)
        {
            _UserManager = UserManager;
            _RoleManager = RoleManager;
        }

        public IActionResult Index()
        {
            List<ApplicationRoleViewModel> model = new List<ApplicationRoleViewModel>();
            model = _RoleManager.Roles.Select(R => new ApplicationRoleViewModel
            {
                Id = R.Id,
                Name = R.Name,
                Description = R.Description,
                NumberOfUser = R.Users.Count
            }).ToList();

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> AddEditRole(String Id)
        {

            ApplicationRoleViewModel model = new ApplicationRoleViewModel();
            if (!string.IsNullOrEmpty(Id))// حالت ویرایش
            {
                // پیدا کردن نقش
                ApplicationRole applicationrole = await _RoleManager.FindByIdAsync(Id);
                if (applicationrole != null)
                {
                    model.Id = applicationrole.Id;
                    model.Name = applicationrole.Name;
                    model.Description = applicationrole.Description;
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            return PartialView("_AddEditApplicationRole", model);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddEditRole(string Id, ApplicationRoleViewModel model, string RedirectUrl)
        {
            if (ModelState.IsValid)
            {
                bool exist = !String.IsNullOrEmpty(Id);
                ApplicationRole applicationrle = exist ? await _RoleManager.FindByIdAsync(Id) :
                    new ApplicationRole
                    {

                    };
                applicationrle.Name = model.Name;
                applicationrle.Description = model.Description;

                IdentityResult Roleresult = exist ? await _RoleManager.UpdateAsync(applicationrle) :
                  await _RoleManager.CreateAsync(applicationrle);

                if (Roleresult.Succeeded)
                {
                    return PartialView("SuccessfullyResponse", RedirectUrl);
                }

            }
            return PartialView("_AddEditApplicationRole", model);
        }

        [HttpGet]
        public async Task<IActionResult> DeleteRole(string id)
        {

            string name = null;
            if (!String.IsNullOrEmpty(id))
            {
                ApplicationRole ar = await _RoleManager.FindByIdAsync(id);
                if (ar != null)
                {
                    name = ar.Name;
                }
            }
            return PartialView("_DeleteRole", name);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteRole(string id, IFormCollection form)
        {
            if (!String.IsNullOrEmpty(id))
            {
                ApplicationRole ar = await _RoleManager.FindByIdAsync(id);
                if (ar != null)
                {
                    IdentityResult identityResult = _RoleManager.DeleteAsync(ar).Result;
                    if (identityResult.Succeeded)
                    {
                        return RedirectToAction("Index");
                    }
                }
            }
            return View();
        }
    }
}