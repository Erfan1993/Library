﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CoreLibraryProject.Migrations
{
    public partial class tablebook : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "authors",
                columns: table => new
                {
                    AutherId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AutherDescription = table.Column<string>(nullable: true),
                    AutherName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_authors", x => x.AutherId);
                });

            migrationBuilder.CreateTable(
                name: "bookGroups",
                columns: table => new
                {
                    BookGroupId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    BbookGroupName = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_bookGroups", x => x.BookGroupId);
                });

            migrationBuilder.CreateTable(
                name: "books",
                columns: table => new
                {
                    BookId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AutherId = table.Column<int>(nullable: false),
                    BookDescription = table.Column<string>(nullable: true),
                    BookGroupIDs = table.Column<int>(nullable: false),
                    BookGroupId = table.Column<int>(nullable: true),
                    BookImage = table.Column<string>(nullable: true),
                    BookName = table.Column<string>(nullable: true),
                    BookPageCount = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_books", x => x.BookId);
                    table.ForeignKey(
                        name: "FK_books_authors_AutherId",
                        column: x => x.AutherId,
                        principalTable: "authors",
                        principalColumn: "AutherId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_books_bookGroups_BookGroupId",
                        column: x => x.BookGroupId,
                        principalTable: "bookGroups",
                        principalColumn: "BookGroupId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_books_AutherId",
                table: "books",
                column: "AutherId");

            migrationBuilder.CreateIndex(
                name: "IX_books_BookGroupId",
                table: "books",
                column: "BookGroupId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "books");

            migrationBuilder.DropTable(
                name: "authors");

            migrationBuilder.DropTable(
                name: "bookGroups");
        }
    }
}
