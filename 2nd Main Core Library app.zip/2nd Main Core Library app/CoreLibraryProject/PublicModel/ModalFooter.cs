﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreLibraryProject.PublicModel
{
    public class ModalFooter
    {
        public string SubmitButtonText { get; set; } = "Submit";

        public string CancelButtonText { get; set; } = "برگشت";

        public String SubmitButtonID { get; set; } = "Btn-Submit";
        public string CancelButtonID { get; set; } = "Btn-Cancel";

        public bool OnlyCancelButton { get; set; } 
    }
}
