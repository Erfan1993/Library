﻿(function ($) {
    function Auther() {
        var $this = this;

        function initilizeModel() {
            $("#modal-action-Auther").on('loaded.bs.modal', function (e) {

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }
        $this.init = function () {
            initilizeModel();
        }
    }
    $(function () {
        var self = new Auther();
        self.init();
    })
}(jQuery))
