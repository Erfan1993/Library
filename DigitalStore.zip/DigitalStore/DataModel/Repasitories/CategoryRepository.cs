﻿using DataLayer.Models;
using DataModel.Context;
using DataModel.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataModel.Repasitories
{
    public class CategoryRepository : ICategoryService
    {
        private DigitalDataContext _context;

        public CategoryRepository(DigitalDataContext context)
        {
            _context = context;
        }

        public bool CreateCategory(Category newCategory)
        {
            if (newCategory == null)
            {
                return false;
            }
            else
            {
                var result = _context.categories.Add(newCategory);
                return true;
            }
        }

        public bool DeleteCategory(int CategoryId)
        {
            if (CategoryId==0)
            {
                return false;
            }
            else
            {
                _context.categories.Remove(GetCategoryByID(CategoryId));
                return true;
            }
        }

        public List<Category> GetAllCategories()
        {
            return _context.categories.ToList();
        }

        public Category GetCategoryByID(int CategoryId)
        {
            return _context.categories.Find(CategoryId);
        }

        public Category GetCategoryByName(string CategoryName)
        {
            return _context.categories.FirstOrDefault(a => a.CategoryName == CategoryName);
        }

        public void Save()
        {
            _context.SaveChanges();
        }

        public bool UpdateCategory(Category InputCategory)
        {
            if (InputCategory == null)
            {
                return false;
            }
            else
            {
                var result = GetCategoryByID(InputCategory.CategoryID);
                result.CategoryName = InputCategory.CategoryName;
                _context.categories.Update(result);
                return true;
            }
        }
    }
}
