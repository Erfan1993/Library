﻿using DataLayer.Models;
using DataModel.Context;
using DataModel.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataModel.Repasitories
{
    public class AttributeValueRepository : IAttributeValueService
    {
        private DigitalDataContext _context;

        public AttributeValueRepository(DigitalDataContext context)
        {
            _context = context;
        }

        public void AddAttributes(List<AttributesValue> newAttribute)
        {
            _context.attributesValues.AddRange(newAttribute);
        }

        public List<AttributesValue> GetAllAttributeValueByProductID(int productID)
        {
            return _context.attributesValues.Where(a => a.ProductID == productID).ToList();
        }

        public void UpdateRange(List<AttributesValue> inputRange)
        {
            if (inputRange == null)
            {

            }
            else
            {
                _context.attributesValues.UpdateRange(inputRange);

            }
        }
    }
}
