﻿using DataModel.Context;
using DataModel.IdentityModels;
using DataModel.Services;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataModel.Repasitories
{
    public class RoleRepository : IRolesService
    {
        private readonly RoleManager<ApplicationRoles> _roleManager;
        private DigitalDataContext _context;

        public RoleRepository(
            RoleManager<ApplicationRoles> roleManager
            , DigitalDataContext context)
        {
            _roleManager = roleManager;
            _context = context;
        }

        public bool CreateRole(ApplicationRoles inputRole)
        {
            var model = _roleManager.CreateAsync(inputRole);
            if (model.Result.Succeeded)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Delete(string inputRoleId)
        {
            var result = FindRole(inputRoleId);
            if (result == null)
            {
                return false;
            }
            else
            {
                var res = _roleManager.DeleteAsync(result);
                if (res.Result.Succeeded)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool EditRole(ApplicationRoles inputRoleForChange)
        {
            var result = FindRole(inputRoleForChange.Id);
            //result.Id = inputRoleForChange.Id;
            result.Name = inputRoleForChange.Name;
            result.NormalizedName = inputRoleForChange.NormalizedName;

            var a = _roleManager.UpdateAsync(result);
            if (a.Result.Succeeded)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public ApplicationRoles FindRole(string InputRoleId)
        {
            if (InputRoleId == "")
            {
                return _context.ApplicationRoles.Find(InputRoleId);
            }
            else
            {
                return _context.ApplicationRoles.Find(InputRoleId);
            }
        }

        public List<ApplicationRoles> GetAllRoles()
        {
            return _context.ApplicationRoles.ToList();
        }
    }
}
