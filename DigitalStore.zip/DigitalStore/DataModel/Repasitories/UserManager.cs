﻿namespace DataModel.Repasitories
{
    internal class UserManager
    {
    }
}