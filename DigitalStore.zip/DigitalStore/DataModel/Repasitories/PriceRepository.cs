﻿
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class PriceRepository : IPriceService
    {
        private DigitalDataContext _context;

        public PriceRepository(DigitalDataContext context)
        {
            _context = context;
        }


        public void AddPrice(Price NewPrice)
        {
            _context.prices.Add(NewPrice);
        }

        public void DeletePrice(int ProductID)
        {
            var deleteQuery = _context.images.Where(a => a.ProductID == ProductID).ToList();
            _context.images.RemoveRange(deleteQuery);
        }

        public void EditPrice(Price NewPrice)
        {
            var model = _context.prices.FirstOrDefault(a => a.ProductID == NewPrice.ProductID);
            if (model != null)
            {
                model.ProductPrice = NewPrice.ProductPrice;
                _context.prices.Update(model);
            }
        }

        public List<Price> GetAllProductPrices(int ProductID)
        {
            return _context.prices.Where(a => a.ProductPrice == ProductID).ToList();
        }
        public Single GetCurrentPrice(int ProductID)
        {
            var s = _context.prices
                 .Include(a => a.ProductTbls)
                 .OrderBy(a => a.PriceDate)
                 .Where(a => a.ProductID == ProductID)
                 .FirstOrDefault();
            return s.ProductPrice;
        }
        public DateTime Now()
        {
            var date = DateTime.Now;
            return date;
        }
        public void PricePlusing(int Precent)
        {
            var l = _context.Set<Price>().Local.ToList();
            if (l != null)
            {
                _context.Entry(l).State = EntityState.Detached;
            }
            var q = l.Select(a => a.ProductPrice + Precent);
            _context.Entry(l).State = EntityState.Modified;

        }
        public List<Price> ProductPricebyID(int ProductId)
        {
            return _context.prices.Where(a => a.ProductID == ProductId).ToList();
        }
        public void save()
        {
            _context.SaveChanges();
        }

    }
}
