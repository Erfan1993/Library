﻿
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class OrderRepository : IOrderService
    {
        private DigitalDataContext _context;

        public OrderRepository(DigitalDataContext context)
        {
            _context = context;
        }

        public void AddOrdre(Order newOrder)
        {
            _context.Orders.Add(newOrder);
        }

        public void ComputeSumOrder(int id)
        {
            var order = _context.Orders.Find(id);
            var details = _context.orderDetails.Where(o => o.OrderID == order.OrderID).Select(a => a.Count * a.Price).Sum();
            order.Cost = details;
            _context.Orders.Update(order);
        }

        public void Delete(int id)
        {
            var model = GetOrderbyOrderID(id);
            _context.Orders.Remove(model);
        }

        public List<Order> GetAllOrders()
        {
            return _context.Orders.Where(a=>a.IsPay==true).ToList();
        }

        public Order GetOrderbyOrderID(int id)
        {
            return _context.Orders.Find(id);
        }

        public Order GetOrderByUserID(string UserId)
        {
            return _context.Orders
                .Include(a => a.OrderDetails)
                .Where(a => a.UserID == UserId && !a.IsPay).FirstOrDefault();
        }
        public Order GetOrders(string id)
        {
            return _context.Orders.SingleOrDefault(a => a.UserID == id && !a.IsPay);
        }

        public void paid(int orderid)
        {
            var model = _context.Orders.Find(orderid);
            model.IsPay = true;
            _context.Orders.Update(model);
        }

        public void RemoveFakeOrders()
        {
            var model = _context.Orders.Where(a => !a.IsPay && a.Date > DateTime.Now.AddMinutes(-10)).ToList();
            foreach (var item in model)
            {
                var orderdetails = _context.orderDetails.Where(a => a.OrderID == item.OrderID).ToList();
                foreach (var item2 in orderdetails)
                {
                    _context.Remove(item2);
                }
                _context.Remove(item);
            }
            _context.SaveChanges();
        }

        public void save()
        {
            _context.SaveChanges();
        }
    }
}
