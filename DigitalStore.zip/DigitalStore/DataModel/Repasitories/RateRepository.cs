﻿
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class RateRepository : IRateService
    {
        private DigitalDataContext _context;
        public RateRepository(DigitalDataContext context)
        {
            _context = context;
        }
        public int averageRate(int id)
        {
            var model = _context.rates.Where(a => a.ProductID == id).ToList();
            int count = model.Count;
            int sum = 0;
            foreach (var item in model)
            {
                sum = sum + item.Ratenumber;
            }
            if (sum == 0 || count == 0)
            {
                return 0;
            }
            else
            {
                return sum / count;
            }
        }
        public void rating(int id, int ratenumber)
        {
            Rate model = new Rate();
            if ((id != 0) || (ratenumber != 0))
            {
                model.ProductID = id;
                model.Ratenumber = ratenumber;
                _context.rates.Add(model);
            }
        }
    }
}
