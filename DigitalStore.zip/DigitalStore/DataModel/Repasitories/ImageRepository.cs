﻿
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class ImageRepository : IImageService
    {
        private readonly DigitalDataContext _context;
        public ImageRepository(DigitalDataContext context)
        {
            _context = context;
        }
        public bool AddImage(Image NewImages)
        {
            if (NewImages == null)
            {
                return false;
            }
            else
            {

                _context.images.Add(NewImages);
                return true;
            }
        }

        public bool DeleteImage(int ProductID)
        {
            var deleteQuery = _context.images.Include(a => a.ProductTbls).Where(a => a.ProductTbls.ProductID == ProductID).ToList();
            if (deleteQuery == null)
            {
                return false;
            }
            else
            {
                _context.images.RemoveRange(deleteQuery);
                return true;
            }


            //db.Entry(customer).State = EntityState.Deleted;


        }

        public void EditImage(Image imageUpdate)
        {
            //var edit = _context.images.Where(a => a.ProductID == imageUpdate.ProductID).ToList();
            var l = _context.Set<Image>().Local.FirstOrDefault(a => a.ProductID == imageUpdate.ProductID);
            if (l != null)
            {
                _context.Entry(l).State = EntityState.Detached;
            }
            _context.Entry(l).State = EntityState.Modified;

            //return _context.images.Where(a => a.ProductID == imageUpdate.ProductID).ToList();
        }
        public Image GetImageByProductID(int ProductID)
        {
            return _context.images.Include(a => a.ProductTbls).Where(a => a.ProductTbls.ProductID == ProductID).FirstOrDefault();
            //return _context.images.Where(a => a.ProductID == ProductID).ToList();
        }

        public void save()
        {
            _context.SaveChanges();
            
        }
    }
}
