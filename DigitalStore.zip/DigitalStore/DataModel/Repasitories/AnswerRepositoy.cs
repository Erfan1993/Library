﻿
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class AnswerRepositoy : IAnswerService
    {
        private DigitalDataContext _context;
        public AnswerRepositoy(DigitalDataContext context)
        {
            _context = context;
        }

        public void AddAnswer(int questionid, string answer, string username, string userid,int productID)
        {
            var model = new Answer();
            model.AnswerTitle = answer;
            model.QuestionID = questionid;
            model.UserID = userid;
            model.UserName = username;
            model.ProductID = productID;
           _context.Answers.Add(model);
        }

        public void AddAnswerToQuestion(int id, string Answer,int ProductID)
        {
            var model = new Answer();
            model.QuestionID = id;
            model.AnswerTitle = Answer;
            model.ProductID = ProductID;
            _context.Answers.Add(model);
        }

        public List<Answer> GetAnswersByProductID(int productID)
        {
            return _context.Answers.Where(a => a.ProductID == productID).ToList();
        }

        public void Save()
        {
            _context.SaveChanges();
        }
    }
}
