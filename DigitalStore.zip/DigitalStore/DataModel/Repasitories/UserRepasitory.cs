﻿using DataModel.Context;
using DataModel.IdentityModels;
using DataModel.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DataModel.Repasitories
{
    public class UserRepasitory : IUserService
    {
        private DigitalDataContext _context;
        private readonly UserManager<ApplicationUsers> _userManager;
        private readonly SignInManager<ApplicationUsers> _signInManager;
        public UserRepasitory(
            DigitalDataContext context
            , UserManager<ApplicationUsers> userManager
            , SignInManager<ApplicationUsers> signInManager)
        {
            _context = context;
            _userManager = userManager;
            _signInManager = signInManager;
        }
        public bool Login(string UserName, string Password, bool RememberMe)
        {
            var res = _signInManager.PasswordSignInAsync(UserName, Password, RememberMe, lockoutOnFailure: false);
            if (res.Result.Succeeded)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool Logout()
        {
            var a = _signInManager.SignOutAsync();
            if (a.IsCompleted)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool RegisterUser(ApplicationUsers InputModel, string Password, string ConfirmPassword)
        {
            var a = _userManager.CreateAsync(InputModel, Password);
            if (a.Result.Succeeded)
            {
                return true;
            }
            else
            {
                return true;
            }
        }
        public bool AddToRole(ApplicationUsers inputUser, string RoleName)
        {
            var roleresult = _userManager.AddToRoleAsync(inputUser, RoleName);
            if (roleresult.Result.Succeeded)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
