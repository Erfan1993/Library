﻿using DataLayer.Models;
using DataModel.Context;
using DataModel.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataModel.Repasitories
{
    public class ProductRepository : IProductService
    {
        private DigitalDataContext _context;
        public ProductRepository(DigitalDataContext context)
        {
            _context = context;
        }
        public bool AddProduct(Product NewProduct)
        {
            //int price = 10;
            if (NewProduct == null)
            {
                return false;
            }
            _context.products.Add(NewProduct);
            //_context.Add(price);
            //    if (Convert.ToBoolean(_context.SaveChanges()))
            //    {
            //        return true;
            //    }
            return true;
        }
        public List<Product> GetAllProducts()
        {
            return _context.products
                 .Include(a => a.CategoryTbls)
                 .Include(a => a.AttributesValueTbls)
                 .Include(a => a.ImagesTbls)
                 .Include(a => a.Price)
                 .ToList();
        }
        public Product GetProductByID(int id)
        {
            return _context.products
                 .Include(a => a.AttributesValueTbls)
                 .Include(a => a.CategoryTbls)
                 .Include(a => a.ImagesTbls)
                 .FirstOrDefault(a => a.ProductID == id);
            //return GetAllProducts().FirstOrDefault(a => a.ProductID == id);
        }
        public List<Product> GetProductByCategoryName(string categoryName)
        {

            //return _context.products
            //        .Where(a => a.CategoryTbls.CategoryName == "Digital")
            //        .Take(6);
            List<Product> product = new List<Product>();

            product = _context.products
                .Include(a => a.CategoryTbls)
                .Include(a => a.Price)
                .Include(a => a.ImagesTbls)
                .Where(a => a.CategoryTbls.CategoryName == categoryName)
                .ToList();


            //var query = from p in _context.products
            //            join pr in _context.prices on p.ProductID equals pr.ProductID
            //            join img in _context.images on p.ProductID equals img.ProductID
            //            join cat in _context.categories on p.CategoryID equals cat.CategoryID
            //            select new
            //            {
            //                p.ProductID,
            //                p.ProductName,
            //                pr.ProductPrice,
            //                img.ImageUrl
            //            };

            //return query;
            return product;
        }
        public void save()
        {
            _context.SaveChanges();
        }
        public void DeleteProduct(int id)
        {
            var model = GetProductByID(id);
            _context.products.Remove(model);
        }
        public void Edit(Product newproduct)
        {
            var up = _context.products.Find(newproduct.ProductID);
            if (up != null)
            {
                up.ProductID = newproduct.ProductID;
                up.ProductName = newproduct.ProductName;
                up.TechnicalDetail = newproduct.TechnicalDetail;
                up.CategoryID = newproduct.CategoryID;
                _context.Update(up);
            }
        }
        public List<Product> SearchProduct(string ProductName, int CategoryID, int minprice, int maxprice)
        {
            var model = _context.products
                .Include(a => a.CategoryTbls)
                .Include(a => a.Price)
                .Include(a => a.AttributesValueTbls).ToList();
            var result = model;
            if (ProductName != null)
            {
                result = model.Where(a => a.ProductName == ProductName).ToList();
                model = result;
            }
            if (CategoryID != 0)
            {
                result = model.Where(b => b.CategoryTbls.CategoryID == CategoryID).ToList();
                model = result;
            }
            if (minprice > 0)
            {
                result = model.Where(c => c.Price.ProductPrice == minprice).ToList();
            }
            return result;
        }
        public string GetProductNamebyId(int id)
        {
            return _context.products.Where(a => a.ProductID == id).Select(a => a.ProductName).FirstOrDefault();
        }
        public List<Product> GetProductsByCategoryId(int id)
        {
            return _context.products
                .Include(a => a.CategoryTbls)
                .Include(a => a.ImagesTbls)
                .Include(a => a.Price).Where(a => a.CategoryID == id).ToList();

        }
    }
}