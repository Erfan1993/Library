﻿
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class CompareRepository : ICompareService
    {
        private DigitalDataContext _context;

        public CompareRepository(DigitalDataContext context)
        {
            _context = context;
        }
        public void Add(int id,string UserID)
        {
            var model = new CompareModel();
            model.ProductID = id;
            model.UserID = UserID;
            _context.Compares.Add(model);
        }
        public List<int> returnproducts(string UserID)
        {
           return _context.Compares.Where(a => a.UserID == UserID).Select(s=>s.ProductID).ToList();
        }
        public void Save()
        {
            _context.SaveChanges();
        }
    }
}
