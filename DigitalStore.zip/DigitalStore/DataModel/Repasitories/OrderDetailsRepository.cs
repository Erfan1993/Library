﻿
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class OrderDetailsRepository : IOrderDetailsService
    {
        private DigitalDataContext _context;

        public OrderDetailsRepository(DigitalDataContext context)
        {
            _context = context;
        }
        public void addOrderDetails(OrderDetails neworderDetails)
        {
            _context.orderDetails.Add(neworderDetails);
        }
        public OrderDetails GetOrderDetails(int productID, int ordreId)
        {
            return _context.orderDetails.SingleOrDefault(o => o.OrderID == ordreId && o.ProductID == productID);
        }

        public List<OrderDetails> GetOrderDetailsByOrderID(int id)
        {
            return _context.orderDetails.Where(a => a.OrderID == id).ToList();
        }

        public int ProductCount(string id)
        {
            var model = _context.Orders
                .Where(a => a.UserID == id).FirstOrDefault();

            if (model == null)
            {
                return 0;
            }

            return _context.orderDetails.Where(t => t.OrderID == model.OrderID).Sum(f => f.Count);
        }

        public void UpdateOrderDetails(OrderDetails orderDetails)
        {
            _context.orderDetails.Update(orderDetails);
        }
    }
}
