﻿using DataLayer.Models;
using DataModel.Context;
using DataModel.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataModel.Repasitories
{
    public class AttributeKeyRepository : IAttributeKeyService
    {
        private DigitalDataContext _context;

        public AttributeKeyRepository(DigitalDataContext context)
        {
            _context = context;
        }
        public bool CreateAttribute(AttributesKey newAttirbute)
        {
            if (newAttirbute != null)
            {
                var res = _context.attributesKeys.Add(newAttirbute);
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteAttribute(int id)
        {
            if (id!=0)
            {
                var model = GetAttributeById(id);
                _context.attributesKeys.Remove(model);
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<AttributesKey> GetAllAttributeByCategoryId(int id)
        {
            return _context.attributesKeys.Where(a => a.CategoryID == id).ToList();
        }

        public List<AttributesKey> GetAllAttributes()
        {
            return _context.attributesKeys.ToList();
        }

        public AttributesKey GetAttributeById(int id)
        {
            return _context.attributesKeys.Find(id);
        }

        public bool isActive(int id)
        {
            if (id == 0)
            {
                return false;
            }
            else
            {
                int res = _context.attributesValues.Where(a => a.AttributesKeyID == id).Count();
                if (res == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public void Save()
        {
            _context.SaveChanges();
        }

        public bool UpdateAttribute(AttributesKey newAttribute)
        {
            if (newAttribute == null)
            {
                return false;
            }
            else
            {
                var model = _context.attributesKeys.Find(newAttribute.AttributeKeyID);
                model.CategoryID = newAttribute.CategoryID;
                model.Title = newAttribute.Title;
                _context.attributesKeys.Update(model);
                return true;
            }
        }
    }
}
