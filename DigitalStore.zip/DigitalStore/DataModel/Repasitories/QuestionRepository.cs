﻿
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class QuestionRepository : IQuestionService
    {
        private DigitalDataContext _context;
        public QuestionRepository(DigitalDataContext context)
        {
            _context = context;
        }
        public void AddQuestion(string Question, string username, string userid,int productID)
        {
            var model = new Question();
            model.ProductID = productID;
            model.UserID = userid;
            model.UserName = username;
            model.QuestionTitle = Question;
            _context.questions.Add(model);
        }

        public void changeAsAnswered(int id)
        {
            var model = GetQuestionById(id);
            model.IsAnswered = true;
            _context.questions.Update(model);

        }

        public bool DeleteQuestion(int id)
        {
            var model = GetQuestionById(id);
            _context.questions.Remove(model);
            return true;
        }
        public List<Question> GetAllUnAnswerQuestions()
        {
            return _context.questions.Where(a => a.IsAnswered == false).ToList();
        }
        public Question GetQuestionById(int id)
        {
            return _context.questions.Find(id);
        }
        public List<Question> GetQuestionsByProductID(int productId)
        {
           return _context.questions.Include(a => a.Answers).Where(a => a.ProductID == productId).ToList();
        }
        public void save()
        {
            _context.SaveChanges();
        }
    }
}
