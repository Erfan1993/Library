﻿
using DataModel.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace DataLayer.Repositories
{
    public class GenericRepository<TEntity> where TEntity : class
    {
        private DigitalDataContext _context;
        private DbSet<TEntity> _DbSet;
        public GenericRepository(DigitalDataContext context)
        {
            _context = context;
            _DbSet = _context.Set<TEntity>();
        }

        public virtual IEnumerable<TEntity> Get
            (Expression<Func<TEntity, bool>> where = null, Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderby = null, string Includes = "")
        {
            IQueryable<TEntity> query = _DbSet;

            if (where != null)
            {
                query = query.Where(where);
            }
            if (orderby != null)
            {
                query = orderby(query);
            }
            if (Includes == "")
            {
                foreach (string include in Includes.Split(","))
                {
                    query = query.Include(include);
                }
            }
            return query.ToList();
        }


        public virtual TEntity GetByID(object id)
        {
            return _DbSet.Find(id);
        }
        public virtual void Insert(TEntity New)
        {
            _DbSet.Add(New);
        }
        public virtual void Update(TEntity entity)
        {
            _DbSet.Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;
        }
        public virtual void Delete(TEntity entity)
        {
            if (_context.Entry(entity).State == EntityState.Detached)
            {
                _DbSet.Attach(entity);
            }
            _DbSet.Remove(entity);
        }
        public virtual void Delete(object ID)
        {
            var entity = _DbSet.Find(ID);
            Delete(entity);
        }
        public void save()
        {
            _context.SaveChanges();
        }

    }
}
