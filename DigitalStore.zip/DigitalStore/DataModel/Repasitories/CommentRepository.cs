﻿
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class CommentRepository : ICommentService
    {
        private DigitalDataContext _context;
        public CommentRepository(DigitalDataContext context)
        {
            _context = context;
        }

        public void AddComment(string UserName, string UserID, string Comment, int ProductID)
        {
            var model = new Comment();
            model.ProductID = ProductID;
            model.ProductComment = Comment;
            model.UserID = UserID;
            model.UserName = UserName;
            _context.comments.Add(model);
        }

        public void DeleteComment(int id)
        {
            var model = GetCommentByID(id);
            _context.comments.Remove(model);
        }

        public Comment GetCommentByID(int id)
        {
            return _context.comments.Find(id);
        }

        public List<Comment> GetCommentsByProductID(int ProductID)
        {
            return _context.comments.Where(a => a.ProductID == ProductID).ToList();
        }

        public bool MarkAsRead(int id)
        {
            var model = GetCommentByID(id);
            model.IsRead = true;
            _context.comments.Update(model);
            return true;
        }

        public void save()
        {
            _context.SaveChanges();
        }

        public List<Comment> UnReadComments()
        {
            var model = _context.comments.Where(a => a.IsRead == false).ToList();
            return model;
        }
        
    }
}
