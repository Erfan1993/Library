﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataLayer.Models
{
    public class CompareModel
    {
        [Key]
        public int ID { get; set; }
        public int ProductID { get; set; }
        public string UserID { get; set; }
    }
}
