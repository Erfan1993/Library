﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
namespace DataLayer.Models
{
    public class Comment
    {
        [Key]
        public int CommentID { get; set; }
        public string ProductComment { get; set; }

        public bool IsRead { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }

        [ForeignKey("ProductID")]
        public int ProductID { get; set; }
        public  Product ProductTbls { get; set; }
    }
}
