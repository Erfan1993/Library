﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Models
{
    public class Basket
    {
        public int ID { get; set; }
        public int ProductID { get; set; }
        public int Count { get; set; }
    }
}
