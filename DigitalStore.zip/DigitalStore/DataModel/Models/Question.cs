﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
    public class Question
    {
        [Key]
        public int QuestionID { get; set; }
        //public string AnswerQuestion { get; set; }
        public string QuestionTitle { get; set; }
        public bool IsAnswered { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }

        [ForeignKey("AnswerID")]
        public int AnswerID { get; set; }
        public IEnumerable<Answer> Answers{ get; set; }

        [ForeignKey("ProductID")]
        public int ProductID { get; set; }
        public Product ProductTbls { get; set; }
    }
}

