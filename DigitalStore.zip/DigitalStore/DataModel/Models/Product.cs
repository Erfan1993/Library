﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
    public class Product
    {
        [Key]
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string TechnicalDetail { get; set; }
        public virtual IEnumerable<AttributesValue> AttributesValueTbls { get; set; }

        
        [ForeignKey("Category")]
        public int CategoryID { get; set; }
        public Category CategoryTbls { get; set; }

        public IEnumerable<Image> ImagesTbls { get; set; }
        public Price Price{ get; set; }
    }
}
