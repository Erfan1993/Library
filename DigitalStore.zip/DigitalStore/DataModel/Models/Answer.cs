﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
    public class Answer
    {
        [Key]
        public int AnswerId { get; set; }
        public string AnswerTitle { get; set; }
        [ForeignKey("QuestionID")]
        public int QuestionID { get; set; }
        [ForeignKey("ProductID")]
        public int ProductID { get; set; }
        public string UserID { get; set; }
        public  string UserName { get; set; }
        
    }
}
