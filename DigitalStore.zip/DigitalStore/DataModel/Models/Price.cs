﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
   public class Price
    {
        [Key]
        public int PriceID { get; set; }
        public Single ProductPrice { get; set; }
        public DateTime PriceDate{ get; set; }

        [ForeignKey("ProductID")]
        public int ProductID { get; set; }
        public Product ProductTbls { get; set; }
    }
}

