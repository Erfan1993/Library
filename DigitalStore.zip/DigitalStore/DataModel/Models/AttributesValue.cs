﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
    public class AttributesValue
    {
        [Key]
        public int AttributeValueID { get; set; }
        public string Value { get; set; }

        [ForeignKey("ProductID")]
        public int ProductID { get; set; }
        //public Product Productbls { get; set; }

        [ForeignKey("AttributesKeyID")]
        public int AttributesKeyID { get; set; }

        //public AttributesKey AttributesKeyTbls { get; set; }

    }
}
