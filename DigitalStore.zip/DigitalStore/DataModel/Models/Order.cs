﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataLayer.Models
{
    public class Order
    {
        [Key]
        public int OrderID { get; set; }
        public string UserID { get; set; }
        public DateTime Date { get; set; }
        public Single Cost { get; set; }
        public bool IsPay { get; set; }

        public List<OrderDetails> OrderDetails { get; set; }
    }
}
