﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IOrderDetailsService
    {
        void addOrderDetails(OrderDetails neworderDetails);
        OrderDetails GetOrderDetails(int productID, int ordreId);
        void UpdateOrderDetails(OrderDetails orderDetails);
        int ProductCount(string id);
        List<OrderDetails> GetOrderDetailsByOrderID(int id);
    }
}
