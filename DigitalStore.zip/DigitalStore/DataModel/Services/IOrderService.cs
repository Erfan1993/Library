﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IOrderService
    {
        Order GetOrders(string id);
        void AddOrdre(Order newOrder);
        void save();
        void ComputeSumOrder(int id);
        Order GetOrderByUserID(string UserId);
        Order GetOrderbyOrderID(int id);
        void paid(int orderid);
        List<Order> GetAllOrders();
        void Delete(int id);
        void RemoveFakeOrders();

    }
}
