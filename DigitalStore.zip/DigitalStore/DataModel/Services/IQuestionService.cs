﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IQuestionService
    {
        List<Question> GetQuestionsByProductID(int productId);
        void AddQuestion(string Question,string username,string userid,int productID);

        List<Question> GetAllUnAnswerQuestions();
        bool DeleteQuestion(int id);
        Question GetQuestionById(int id);
        void save();

        void changeAsAnswered(int id);
    }
}
