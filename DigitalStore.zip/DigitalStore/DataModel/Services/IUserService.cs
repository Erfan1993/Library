﻿using DataModel.IdentityModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataModel.Services
{
    public interface IUserService
    {
        bool RegisterUser(ApplicationUsers InputModel,string Password, string ConfirmPassword);
        bool Login(string UserName,string Password, bool RememberMe);
        bool Logout();
        bool AddToRole(ApplicationUsers inputUser,string RoleName);

    }
}
