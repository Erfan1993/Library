﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataModel.Services
{
    public interface ICategoryService
    {
        bool CreateCategory(Category newCategory);
        Category GetCategoryByID(int CategoryId);
        Category GetCategoryByName(string CategoryName);
        List<Category> GetAllCategories();
        bool UpdateCategory(Category InputCategory);
        bool DeleteCategory(int CategoryId);
        void Save();
    }
}
