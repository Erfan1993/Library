﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface ICompareService
    {
        void Add(int id,string UserID);
        List<int> returnproducts(string UserID);
        void Save();
    }
}
