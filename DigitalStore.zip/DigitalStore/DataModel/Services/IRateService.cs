﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IRateService
    {
        int averageRate(int id);
        void rating(int id, int ratenumber);
    }
}
