﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IImageService
    {
        Image GetImageByProductID(int ProductID);
        bool AddImage(Image NewImages);
        bool DeleteImage(int ProductID);
        void EditImage(Image imageUpdate);
        void save();
    }
}
