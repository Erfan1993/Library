﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataModel.Services
{
    public interface IProductService
    {
        bool AddProduct(Product NewProduct);
        List<Product> GetAllProducts();
        Product GetProductByID(int id);
        List<Product> GetProductByCategoryName(string categoryName);
        void save();
        void DeleteProduct(int id);
        void Edit(Product newproduct);
        string GetProductNamebyId(int id);
        List<Product> SearchProduct(string ProductName, int CategoryID, int minprice, int maxprice);
        List<Product> GetProductsByCategoryId(int id);
    }
}
