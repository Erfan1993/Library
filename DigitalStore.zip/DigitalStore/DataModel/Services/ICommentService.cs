﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface ICommentService
    {
        List<Comment> GetCommentsByProductID(int ProductID);
        void AddComment(string UserName, string UserID, string Comment, int ProductID);
        void save();
        List<Comment> UnReadComments();
        void DeleteComment(int id);
        Comment GetCommentByID(int id);
        bool MarkAsRead(int id);
    }
}
