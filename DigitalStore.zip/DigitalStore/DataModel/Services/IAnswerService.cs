﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IAnswerService
    {
        List<Answer> GetAnswersByProductID(int productID);
        void AddAnswer(int questionid, string answer, string username, string userid,int productID);
        void AddAnswerToQuestion(int id, string Answer, int productID);
        void Save();
    }
}
