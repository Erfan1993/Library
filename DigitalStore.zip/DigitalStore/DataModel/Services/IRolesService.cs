﻿using DataModel.IdentityModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataModel.Services
{
    public interface IRolesService
    {
        bool CreateRole(ApplicationRoles inputRole);
        List<ApplicationRoles> GetAllRoles();
        bool EditRole(ApplicationRoles inputRoleForChange);
        ApplicationRoles FindRole(string InputRoleId);
        bool Delete(string inputRoleId);
    }
}
