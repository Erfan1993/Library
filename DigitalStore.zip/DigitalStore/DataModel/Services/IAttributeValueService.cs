﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataModel.Services
{
    public interface IAttributeValueService
    {
        void AddAttributes(List<AttributesValue> newAttribute);
        List<AttributesValue> GetAllAttributeValueByProductID(int productID);
        void UpdateRange(List<AttributesValue> inputRange);
        //bool CreateAttributeValue(AttributesValue newattributesValue);
        //bool Delete(int id);
        //bool Update(AttributesValue newattributesValue);
        //List<AttributesValue> GetAllattributesValue();
        //AttributesValue GetAttributeByID(int id);
        //AttributesValue GetAttributeValueByAttributeKeyID(int id);
        //List<AttributesValue> GetAttributeByProductID(int id);
    }
}
