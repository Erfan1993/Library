﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataModel.Services
{
    public interface IAttributeKeyService
    {
        bool CreateAttribute(AttributesKey newAttirbute);
        bool DeleteAttribute(int id);
        List<AttributesKey> GetAllAttributes();
        AttributesKey GetAttributeById(int id);
        bool UpdateAttribute(AttributesKey newAttribute);
        List<AttributesKey> GetAllAttributeByCategoryId(int id);
        void Save();
        bool isActive(int id);
    }
}
