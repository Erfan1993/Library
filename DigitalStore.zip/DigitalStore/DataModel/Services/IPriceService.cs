﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IPriceService
    {
        DateTime Now();
        Single GetCurrentPrice(int ProductID);
        void AddPrice(Price NewPrice);
        void DeletePrice(int ProductID);
        void EditPrice(Price NewPrice);
        List<Price> GetAllProductPrices(int ProductID);
        void PricePlusing(int Precent);
        void save();

        List<Price> ProductPricebyID(int ProductId);
    }
}
