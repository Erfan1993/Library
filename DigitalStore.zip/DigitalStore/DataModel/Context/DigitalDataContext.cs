﻿using DataLayer.Models;
using DataModel.IdentityModels;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataModel.Context
{
    public class DigitalDataContext : IdentityDbContext<ApplicationUsers, ApplicationRoles, string>
    {
        public DigitalDataContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<ApplicationUsers> ApplicationUsers { get; set; }
        public DbSet<ApplicationRoles> ApplicationRoles { get; set; }
        public DbSet<AttributesKey> attributesKeys { get; set; }
        public DbSet<AttributesValue> attributesValues { get; set; }
        public DbSet<Category> categories { get; set; }
        public DbSet<Comment> comments { get; set; }
        public DbSet<Answer> Answers { get; set; }
        public DbSet<Image> images { get; set; }
        public DbSet<Price> prices { get; set; }
        public DbSet<Product> products { get; set; }
        public DbSet<Question> questions { get; set; }
        public DbSet<Rate> rates { get; set; }
        public DbSet<CompareModel> Compares { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetails> orderDetails { get; set; }
    }
}
