﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataLayer.Repositories;
using DataLayer.Services;
using DataModel.Context;
using DataModel.IdentityModels;
using DataModel.Repasitories;
using DataModel.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace DigitalStore
{
    public class Startup
    {
        private IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
            services.AddSingleton(_configuration);

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.DefaultSignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
            }).AddCookie(options =>
            {
                options.LoginPath = "/Account/Login";
                options.LogoutPath = "/Account/Logoff";
                options.ExpireTimeSpan = TimeSpan.FromMinutes(43200);
            });


            services.AddDbContext<DigitalDataContext>(options =>
                options.UseSqlServer(_configuration.GetConnectionString("DefaultConnection")));

            services.AddIdentity<ApplicationUsers, ApplicationRoles>()
                .AddEntityFrameworkStores<DigitalDataContext>()
                .AddDefaultTokenProviders();

            services.AddScoped<IUserService, UserRepasitory>();
            services.AddScoped<IRolesService, RoleRepository>();
            services.AddScoped<ICategoryService, CategoryRepository>();
            services.AddScoped<IAttributeKeyService, AttributeKeyRepository>();
            services.AddScoped<IProductService, ProductRepository>();
            services.AddScoped<IAttributeValueService, AttributeValueRepository>();

            services.AddScoped<IImageService, ImageRepository>();
            services.AddScoped<IPriceService, PriceRepository>();
            services.AddScoped<ICategoryService, CategoryRepository>();
            services.AddScoped<ICommentService, CommentRepository>();
            services.AddScoped<IQuestionService, QuestionRepository>();
            services.AddScoped<IAnswerService, AnswerRepositoy>();
            services.AddScoped<IRateService, RateRepository>();
            services.AddScoped<ICompareService, CompareRepository>();
            services.AddScoped<IOrderService, OrderRepository>();
            services.AddScoped<IOrderDetailsService, OrderDetailsRepository>();

        }
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseIdentity();
            app.UseStaticFiles();
            app.UseFileServer();
            app.UseMvc(DefaultRoute);
        }
        private void DefaultRoute(IRouteBuilder obj)
        {
            obj.MapRoute(
                name: "DefaultRoute",
                template: "{Controller=Home}/{Action=Index}/{id?}"
                );
        }
    }
}
