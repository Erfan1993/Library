﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using DataModel.IdentityModels;
using DataModel.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Utility;
using ViewModels.AccountViewModel;
using ViewModels.AccountViewModels;

namespace DigitalStore.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUsers> _usermanager;
        private readonly SignInManager<ApplicationUsers> _signInManager;
        private IUserService _userService;
        private IRolesService _rolesService;

        public AccountController(
              IUserService userService
            , IRolesService rolesService
            , SignInManager<ApplicationUsers> signInManager
            , UserManager<ApplicationUsers> userManager)
        {
            _userService = userService;
            _rolesService = rolesService;
            _signInManager = signInManager;
            _usermanager = userManager;
        }
        //////////Authentication///////////////////////////////////////////////////////////////////////
        [HttpGet]
        public IActionResult Login()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        //public IActionResult login(UserLoginViewModel inputModel)
        //{
            public async Task<IActionResult> Login(UserLoginViewModel model, IFormCollection form)
            {
                //string urlToPost = "https://www.google.com/recaptcha/api/siteverify";
                //string secretKey = "6LcI9rIUAAAAADEW-pHPQAfVhVExQYU4qmYiLnsB"; // change this
                //string gRecaptchaResponse = form["g-recaptcha-response"];

                //var postData = "secret=" + secretKey + "&response=" + gRecaptchaResponse;

                //// send post data
                //HttpWebRequest request = (HttpWebRequest)WebRequest.Create(urlToPost);
                //request.Method = "POST";
                //request.ContentLength = postData.Length;
                //request.ContentType = "application/x-www-form-urlencoded";

                //using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                //{
                //    streamWriter.Write(postData);
                //}

                //// receive the response now
                //string result = string.Empty;
                //using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                //{
                //    using (var reader = new StreamReader(response.GetResponseStream()))
                //    {
                //        result = reader.ReadToEnd();
                //    }
                //}

                //// validate the response from Google reCaptcha
                //var captChaesponse = JsonConvert.DeserializeObject<ReCaptchaResponse>(result);
                //if (!captChaesponse.Success)
                //{
                //    ViewBag.Message = "Sorry, please validate the reCAPTCHA";
                //    return View();
                //}
                if (ModelState.IsValid)
                {
                    var loginresult =
                        await _signInManager
                        .PasswordSignInAsync(model.UserName, model.Password, model.RememberMe, lockoutOnFailure: false);
                    if (loginresult.Succeeded)
                    {
                    var usert = User.Identity.IsAuthenticated;
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Invalid Login Information");
                    }
                }
                return View();
            //}
            //if (ModelState.IsValid)
            //{
            //       var result = _userService.Login(inputModel.UserName, inputModel.Password, inputModel.RememberMe);
            //        if (result==true)
            //        {
            //            return RedirectToAction("Index", "Home");
            //        }
            //        else
            //        {
            //        return View("_ExeptionPage", "Login Was Not Complete Because Wrong Information");
            //    }
            //}
            //else
            //{
            //    return View("_ExeptionPage","Wrong Login Information You Entered");
            //}
        }
        public IActionResult Logout()
        {
            _userService.Logout();
            return RedirectToAction("Index", "Home");
        }
        //////////Authentication///////////////////////////////////////////////////////////////////////

        //////////Users///////////////////////////////////////////////////////////////////////
        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(UserRegisterViewModel inputModel)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUsers
                {
                    Email = inputModel.EmailAddress,
                    Family = inputModel.Family,
                    Name = inputModel.Name,
                    NationCode = inputModel.NationCode,
                    PhoneNumber = inputModel.PhoneNumber,
                    UserName = inputModel.UserName
                };
                var result = _userService.RegisterUser(user, inputModel.Password, inputModel.ConfirmPassword);
                if (result == true)
                {
                    _userService.AddToRole(user, "Admin");
                    return RedirectToAction("Login", "Account");
                }
                else
                {
                    return View("_ExeptionPage", "You Must Insert Correct Information");
                }
            }
            else
            {
                return View("_ExeptionPage", "Wrong Information You Entered");
            }
        }
        public IActionResult DeleteAccount()
        {
            return View();
        }
        //////////Users///////////////////////////////////////////////////////////////////////

        //////////Roles///////////////////////////////////////////////////////////////////////
        [HttpGet]
        public IActionResult RoleList()
        {
            var model = _rolesService.GetAllRoles();
            List<RolesViewModel> outputmodel = new List<RolesViewModel>();
            foreach (var item in model)
            {
                RolesViewModel m = new RolesViewModel();
                m.RoleID = item.Id;
                m.RoleName = item.Name;
                m.Role = item.NormalizedName;
                outputmodel.Add(m);
            }
            return View(outputmodel);
        }

        [HttpGet]
        public IActionResult CreateRole()
        {
            return View();
        }

        [HttpGet]
        public IActionResult EditRole(string Id)
        {
            var model = _rolesService.FindRole(Id);
            RolesViewModel outputmodel = new RolesViewModel();
            outputmodel.RoleID = model.Id;
            outputmodel.Role = model.NormalizedName;
            outputmodel.RoleName = model.Name;
            return View(outputmodel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateEditRole(RolesViewModel inputRole)
        {
            if (inputRole.RoleID == null)
            {
                ApplicationRoles model = new ApplicationRoles
                {
                    Name = inputRole.RoleName,
                    NormalizedName = inputRole.Role
                };
                bool res = _rolesService.CreateRole(model);
                if (res == true)
                {
                    return RedirectToAction("RoleList", "Account");
                }
                else
                {
                    //error 
                }
            }
            else if (inputRole.RoleID != null)
            {
                ApplicationRoles model = new ApplicationRoles
                {
                    Id = inputRole.RoleID,
                    Name = inputRole.RoleName,
                    NormalizedName = inputRole.Role
                };
                bool result = _rolesService.EditRole(model);
                if (result == true)
                {
                    return RedirectToAction("RoleList", "Account");
                }
                else
                {
                    return RedirectToAction("RoleList", "Account");
                }

            }
            return RedirectToAction("RoleList", "Account");
        }

        [HttpGet]
        public IActionResult DeleteRole(string Id)
        {
            var model = _rolesService.FindRole(Id);
            RolesViewModel outputmodel = new RolesViewModel();
            outputmodel.RoleID = model.Id;
            outputmodel.Role = model.NormalizedName;
            outputmodel.RoleName = model.Name;
            return View(outputmodel);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteRole(string Id, IFormCollection form)
        {
            bool result = _rolesService.Delete(Id);
            if (result == true)
            {
                return RedirectToAction("RoleList", "Account");
            }
            else
            {
                //Redirect to error Page
                return RedirectToAction("RoleList", "Account");
            }
        }
        //////////Roles///////////////////////////////////////////////////////////////////////
    }
}