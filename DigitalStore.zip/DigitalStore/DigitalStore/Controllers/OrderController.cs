﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Services;
using Microsoft.AspNetCore.Mvc;
using ViewModels.BasketViewModels;
using ViewModels.OrderViewModels;
using ZarinpalSandbox;

namespace DigitalStore.Controllers
{
    public class OrderController : Controller
    {
        private IOrderService _orderService;
        private IOrderDetailsService _orderDetailsService;
        private IPriceService _priceService;
        private IProductService _productService;
        private IImageService _imageService;

        public OrderController(
            IOrderService orderService
            , IOrderDetailsService orderDetailsService
            , IPriceService priceService
            , IProductService productService
            , IImageService imageService)
        {
            _orderService = orderService;
            _orderDetailsService = orderDetailsService;
            _priceService = priceService;
            _productService = productService;
            _imageService = imageService;
        }
        public IActionResult Index()
        {
            return View();
        }
        //________________________________________________________________________________________________
        public IActionResult AddToBasket(int id)
        {
            var order = new Order();
            var orderdetails = new OrderDetails();
            string username = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var getorder = _orderService.GetOrders(username);
            if (getorder == null)
            {
                order.Cost = 0;
                order.IsPay = false;
                order.UserID = username;
                order.Date = DateTime.Now;
                _orderService.AddOrdre(order);

                orderdetails.Count = 1;
                orderdetails.OrderID = order.OrderID;
                orderdetails.Price = _priceService.GetCurrentPrice(id);
                orderdetails.ProductID = id;
                _orderDetailsService.addOrderDetails(orderdetails);
                _orderService.save();
                _orderService.ComputeSumOrder(orderdetails.OrderID);
            }
            else
            {
                var details = _orderDetailsService.GetOrderDetails(id, getorder.OrderID);
                if (details == null)
                {
                    OrderDetails om = new OrderDetails();
                    om.OrderID = getorder.OrderID;
                    om.ProductID = id;
                    om.Count = 1;
                    om.Price = _priceService.GetCurrentPrice(id);
                    _orderDetailsService.addOrderDetails(om);
                }
                else
                {
                    details.Count += 1;
                    _orderDetailsService.UpdateOrderDetails(details);
                }
                _orderService.save();
                _orderService.ComputeSumOrder(getorder.OrderID);
            }
            _orderService.save();

            return RedirectToAction("ShowProduct", "Product", new { id = id });
        }
        //________________________________________________________________________________________________
        public IActionResult Showbasket()
        {
            string username = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var restiltmodel = new BasketListViewModel();

            var model = _orderService.GetOrderByUserID(username);

            restiltmodel.Items = model.OrderDetails.Select(a => new BasketViewModel
            {
                Count = a.Count,
                ProductId = a.ProductID,
                Image = _imageService.GetImageByProductID(a.ProductID).ImageUrl,
                Price = _priceService.GetCurrentPrice(a.ProductID),
                ProductName = _productService.GetProductNamebyId(a.ProductID)
            }).ToList();
            restiltmodel.OrderId = model.OrderID;
            restiltmodel.UserID = model.UserID;
            restiltmodel.Cost = model.Cost;


            return View(restiltmodel);
        }
        //________________________________________________________________________________________________
        public IActionResult Payment()
        {
            string UserID = User.FindFirstValue(ClaimTypes.NameIdentifier);
            string UserEmail = User.FindFirstValue(ClaimTypes.Email);
            string UserPhone = User.FindFirstValue(ClaimTypes.MobilePhone);
            var PayCost = _orderService.GetOrderByUserID(UserID);
            if (PayCost == null)
            {
                return NotFound();
            }
            var payment = new Payment((int)PayCost.Cost);
            var res = payment.PaymentRequest(
                $"پرداخت شماره فاکتور {PayCost.OrderID} "
                , "https://localhost:44383/Order/OnlinePayment/" + PayCost.OrderID
                //, UserEmail
                //, UserPhone);
                , "erefsf@yahoo.com"
                , "09183340718");

            if (res.Result.Status == 100)
            {
                return Redirect("https://sandbox.zarinpal.com/pg/StartPay/" + res.Result.Authority);
            }
            else
            {
                return BadRequest();
            }
        }
        //________________________________________________________________________________________________
        public IActionResult OnlinePayment(int id)
        {
            if (HttpContext.Request.Query["Status"] != "" &&
                HttpContext.Request.Query["Status"].ToString().ToLower() == "ok" &&
                HttpContext.Request.Query["Authority"] != "")
            {
                string authority = HttpContext.Request.Query["Authority"].ToString();
                var code = _orderService.GetOrderbyOrderID(id);
                var paymetn = new Payment((int)code.Cost);
                var res = paymetn.Verification(authority).Result;
                if (res.Status == 100)
                {
                    _orderService.paid(id);
                    _orderService.save();
                    ViewBag.code = res.RefId;
                    return View("OnlinePayment");
                }
            }
            return NotFound();
        }
        //________________________________________________________________________________________________
        public IActionResult Delete(int id)
        {
            _orderService.Delete(id);
            _orderService.save();
            return View("Reports", "Manager");
        }
        //________________________________________________________________________________________________
        public IActionResult ShowOrderDetail(int id)
        {
            List<OrderDetailsViewModel> restultmodel = new List<OrderDetailsViewModel>();
            var model = _orderDetailsService.GetOrderDetailsByOrderID(id);
            foreach (var item in model)
            {
                var m = new OrderDetailsViewModel();
                m.Count = item.Count;
                m.Price = item.Price;
                m.ProductName = _productService.GetProductNamebyId(item.ProductID);
                restultmodel.Add(m);
            }
            return View(restultmodel);
        }
    }
}