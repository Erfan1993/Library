﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataModel.Services;
using Microsoft.AspNetCore.Mvc;
using ViewModels.HomeViewModels;

namespace DigitalStore.Controllers
{
    public class HomeController : Controller
    {
        private IProductService _productService;

        public HomeController(IProductService productService) 
        {
            _productService = productService;
        }
        public IActionResult Index()
        {
            ListMainPageViewModel list = new ListMainPageViewModel();
            list.DigitalProducts = _productService.GetProductByCategoryName("Digital")
                .Select(a => new MainPageViewModel
                {
                    ID = a.ProductID,
                    Name = a.ProductName,
                    price = a.Price.ProductPrice,
                    Image = a.ImagesTbls.Select(b => b.ImageUrl).FirstOrDefault(),
                    CategoryID = a.CategoryID
                }).ToList();

            return View(list);
        }




    }
}