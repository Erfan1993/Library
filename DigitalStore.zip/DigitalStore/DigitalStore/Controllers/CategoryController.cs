﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataLayer.Models;
using DataModel.Services;
using Microsoft.AspNetCore.Mvc;
using ViewModels.AttributeKeyViewModels;
using ViewModels.CategoryViewModels;

namespace DigitalStore.Controllers
{
    public class CategoryController : Controller
    {
        private ICategoryService _categoryService;
        private IAttributeKeyService _attributeKeyService;

        public CategoryController(
            ICategoryService categoryService
            , IAttributeKeyService attributeKeyService)
        {
            _categoryService = categoryService;
            _attributeKeyService = attributeKeyService;
        }
        public IActionResult CategoryIndex()
        {
            List<CategoryViewModel> outputModel = new List<CategoryViewModel>();
            var model = _categoryService.GetAllCategories();
            outputModel = model.Select(res => new CategoryViewModel
            {
                CategoryId = res.CategoryID,
                CategoryName = res.CategoryName,
                AttributesCount = _attributeKeyService.GetAllAttributeByCategoryId(res.CategoryID).Count,
                ProductCount = 0
            }).ToList();

            return View(outputModel);
        }

        [HttpGet]
        public IActionResult CreateCategory()
        {

            return View();
        }

        public IActionResult EditCategory(int id)
        {
            var result = _categoryService.GetCategoryByID(id);
            var outputmodel = new CategoryViewModel();
            outputmodel.CategoryId = result.CategoryID;
            outputmodel.CategoryName = result.CategoryName;
            return View(outputmodel);
        }

        [HttpPost]
        public IActionResult CreateEditCategory(CategoryViewModel InputModel)
        {
            var createmodel = new Category();

            if (InputModel.CategoryId != 0)
            {
                createmodel.CategoryID = InputModel.CategoryId;
                createmodel.CategoryName = InputModel.CategoryName;
                bool result = _categoryService.UpdateCategory(createmodel);
                _categoryService.Save();
                if (result == true)
                {
                    return RedirectToAction("CategoryIndex", "Category");
                }
                else
                {
                    return View("_ExeptionPage", "Wrong information for Create");
                }
            }
            else
            {
                createmodel.CategoryName = InputModel.CategoryName;
                bool result = _categoryService.CreateCategory(createmodel);
                _categoryService.Save();
                if (result == true)
                {
                    return RedirectToAction("CategoryIndex", "Category");
                }
                else
                {
                    return View("_ExeptionPage", "Wrong information for Create");
                }
            }

        }

        public IActionResult DeleteCategory(int id)
        {
            if (ModelState.IsValid)
            {

                bool result = _categoryService.DeleteCategory(id);
                _categoryService.Save();
                if (result == true)
                {
                    return RedirectToAction("CategoryIndex", "Category");
                }
                else
                {
                    return View("_ExeptionPage", "Wrong information for Create");
                }
            }
            else
            {
                return View("_ExeptionPage", "Wrong information for Create");
            }
        }
        //-------------------------------------------------------------------------------------------

        public IActionResult ShowAttribute(int id)
        {
            var model = _attributeKeyService.GetAllAttributeByCategoryId(id);
            List<AttributeKeyViewModel> attributes = new List<AttributeKeyViewModel>();

            attributes = model.Select(a => new AttributeKeyViewModel {
                AttributeID = a.AttributeKeyID,
                AttributeName = a.Title,
                CategoryID = a.CategoryID,
                Status = _attributeKeyService.isActive(a.AttributeKeyID)
            }).ToList();

            return View(attributes);
        }

        [HttpGet]
        public IActionResult CreateAttribute(int id)
        {
            var outpot = new AttributeKeyViewModel { CategoryID = id };
            return View(outpot);
        }

        [HttpGet]
        public IActionResult EditAttribute(int id)
        {
            var model = _attributeKeyService.GetAttributeById(id);
            var res = new AttributeKeyViewModel
            {
                CategoryID = model.CategoryID,
                AttributeID = model.AttributeKeyID,
                AttributeName = model.Title
            };
            return View(res);
        }

        [HttpPost]
        public IActionResult CreateEditAttribute(AttributeKeyViewModel inputAttributekey)
        {
            if (inputAttributekey.AttributeID == 0)
            {
                AttributesKey attribute = new AttributesKey
                {
                    CategoryID = inputAttributekey.CategoryID,
                    Title = inputAttributekey.AttributeName
                };
                bool res = _attributeKeyService.CreateAttribute(attribute);
                _attributeKeyService.Save();
                if (res == true)
                {
                    return RedirectToAction("ShowAttribute", "Category", new { id = inputAttributekey.CategoryID });
                }
                else
                {
                    return View("_ExeptionPage", "Wrong information for Create");
                }
            }
            else
            {
                AttributesKey attribute = new AttributesKey
                {
                    CategoryID = inputAttributekey.CategoryID,
                    Title = inputAttributekey.AttributeName,
                    AttributeKeyID = inputAttributekey.AttributeID
                };
                bool res = _attributeKeyService.UpdateAttribute(attribute);
                _attributeKeyService.Save();
                if (res == true)
                {
                    return RedirectToAction("ShowAttribute", "Category", new { id = inputAttributekey.CategoryID });
                }
                else
                {
                    return View("_ExeptionPage", "Wrong information for Create");
                }
            }
        }

        public IActionResult DeleteAttribute(int id)
        {
            _attributeKeyService.DeleteAttribute(id);
            _attributeKeyService.Save();
            return RedirectToAction("CategoryIndex", "Category");
        }
    }
}