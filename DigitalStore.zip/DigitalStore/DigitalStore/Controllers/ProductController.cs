﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DataLayer.Models;
using DataLayer.Services;
using DataModel.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ViewModels.AttributeKeyViewModels;
using ViewModels.AttributeValueViewModels;
using ViewModels.ProductViewModels;
using ViewModels.PublicViewModels;

namespace DigitalStore.Controllers
{
    public class ProductController : Controller
    {
        private IAttributeValueService _attributeValueService;
        private IProductService _productService;
        private IImageService _imageService;
        private ICategoryService _categoryService;
        private IPriceService _priceService;
        private IAttributeKeyService _attributesKeyService;
        private IRateService _rateService;
        private ICommentService _commentService;
        private IAnswerService _answerService;
        private IQuestionService _questionService;
        private ICompareService _compareService;


        private IServiceProvider _serviceProvider;
        private IHostingEnvironment _AppEnvironment;


        public ProductController(
              IProductService productService
            , IHostingEnvironment AppEnvironment
            , IServiceProvider serviceProvider
            , IImageService imageService
            , ICategoryService categoryService
            , IPriceService priceService
            , IAttributeKeyService attributesKeyService
            , IAttributeValueService attributeValueService
            , ICommentService commentService
            , IAnswerService answerService
            , IQuestionService questionService
            , IRateService rateService
            , ICompareService compareService)
        {
            _serviceProvider = serviceProvider;
            _AppEnvironment = AppEnvironment;

            _rateService = rateService;
            _attributesKeyService = attributesKeyService;
            _categoryService = categoryService;
            _priceService = priceService;
            _imageService = imageService;
            _productService = productService;
            _attributeValueService = attributeValueService;
            _answerService = answerService;
            _questionService = questionService;
            _commentService = commentService;
            _compareService = compareService;


            _AppEnvironment = AppEnvironment;
            _serviceProvider = serviceProvider;
        }

        public IActionResult CreateProduct()
        {
            var models = new ProductViewModel();
            models.Categories = _categoryService.GetAllCategories()
                .Select(ct => new SelectListItem
                {
                    Text = ct.CategoryName,
                    Value = ct.CategoryID.ToString()
                }).ToList();
            return View(models);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddAttributes(ProductViewModel model)
        {
            if (model.CategoryID == 0)
            {
                return RedirectToAction("CreateProduct", "Product");
            }
            model.KeyListsVal = _attributesKeyService.GetAllAttributeByCategoryId(model.CategoryID).Select(at => new AttributeKeyValViewModel
            {
                attKeyID = at.AttributeKeyID,
                attKeyTitle = at.Title
            }).ToList();
            var price = new Price();
            var img = new Image();
            Product product = new Product();
            var Imagemodel = model.Image;
            if (Imagemodel != null && Imagemodel.Length > 0)
            {
                var uploads = Path.Combine(_AppEnvironment.WebRootPath, @"NormalImage\");
                if (Imagemodel.Length > 0)
                {
                    var fileName = Guid.NewGuid().ToString().Replace("-", "") + Path.GetExtension(Imagemodel.FileName);
                    using (var fileStream = new FileStream(Path.Combine(uploads, fileName), FileMode.Create))
                    {
                        await Imagemodel.CopyToAsync(fileStream);
                        img.ImageUrl = fileName;
                    }
                }
            }
            int catid = model.CategoryID;
            product.ProductName = model.ProductName;
            product.TechnicalDetail = model.TechnicalDetails;
            product.CategoryID = catid;
            _productService.AddProduct(product);
            img.ProductID = product.ProductID;
            _imageService.AddImage(img);
            model.ProductID = product.ProductID;
            price.ProductID = product.ProductID;
            price.ProductPrice = model.Price;
            _priceService.AddPrice(price);
            _productService.save();
            model.ProductID = product.ProductID;
            return View(model);
        }
        [HttpPost]
        public IActionResult SaveToDB(ProductViewModel model)
        {
            Product p = new Product() { ProductID = model.ProductID };

            var attributes = new List<AttributesValue>();
            foreach (var item in model.KeyListsVal)
            {
                AttributesKey att = new AttributesKey() { AttributeKeyID = item.attKeyID };

                var m = new AttributesValue();

                m.AttributesKeyID = item.attKeyID;
                m.Value = item.attVal;
                m.ProductID = model.ProductID;
                attributes.Add(m);
            }

            _attributeValueService.AddAttributes(attributes);
            _productService.save();

            return RedirectToAction("GetProductlist", "Product");
        }
        //________________________________________________________________________________________________
        [HttpGet]
        public IActionResult GetProductlist(int Pageid)
        {
            List<ProductListViewModel> model = new List<ProductListViewModel>();
            var m = _productService.GetAllProducts();
            foreach (var item in m)
            {
                var cm = new ProductListViewModel();

                cm.Category = _categoryService.GetAllCategories()
                    .FirstOrDefault(a => a.CategoryID == item.CategoryID)
                    .CategoryName;

                cm.Price = _priceService.GetCurrentPrice(item.ProductID);
                cm.Image = item.ImagesTbls.Select(a => a.ImageUrl).FirstOrDefault();
                cm.Rate = _rateService.averageRate(item.ProductID);
                cm.ProductID = item.ProductID;
                cm.ProductName = item.ProductName;
                model.Add(cm);
            }

            if (Pageid <= 0)
            {
                Pageid = 1;
            }
            int pagecount = 3;

            int skipitem = (Pageid - 1) * pagecount;

            int totalPage = (int)(model.Count + pagecount - 1) / pagecount;

            var mainmodel = model.OrderBy(a => a.ProductID).Skip(skipitem).Take(3).ToList();

            if (Pageid >= totalPage)
            {
                Pageid = 0;
            }
            ViewBag.PageID = Pageid;
            ViewBag.PageCount = totalPage;

            return View(mainmodel);
        }
        //________________________________________________________________________________________________
        [HttpGet]
        public IActionResult DeleteProduct(int id)
        {
            _productService.DeleteProduct(id);
            _productService.save();
            return RedirectToAction("GetProductlist", "Product");
        }
        //________________________________________________________________________________________________
        public IActionResult EditProduct(int id)
        {
            ProductEditViewModel m = new ProductEditViewModel();
            var model = _productService.GetProductByID(id);
            m.ProductID = id;
            m.CategoryID = model.CategoryID;
            m.Price = _priceService.GetCurrentPrice(id);
            m.ProductName = model.ProductName;
            m.TechnicalDetails = model.TechnicalDetail;
            //m.Image = _imageService.GetImageByProductID(id).ImageUrl;

            m.AttributesKey = _attributesKeyService.GetAllAttributeByCategoryId(model.CategoryID)
                .Select(atk => new AttributeKeyViewModel
                {
                    AttributeID = atk.AttributeKeyID,
                    AttributeName = atk.Title
                }).ToList();

            m.AttributeValue = _attributeValueService.GetAllAttributeValueByProductID(id)
                .Select(at => new AttrinuteValueViewModel
                {
                    AttKeyID = at.AttributesKeyID,
                    AttValID = at.AttributeValueID,
                    AttValTitle = at.Value
                }).ToList();
            return View(m);
        }
        //________________________________________________________________________________________________
        [HttpPost]
        public IActionResult EditProduct(ProductEditViewModel model)
        {
            Product product = new Product();
            Price price = new Price();
            Image image = new Image();
            //-------------------------------------------------------------------
            product.ProductID = model.ProductID;
            product.ProductName = model.ProductName;
            product.TechnicalDetail = model.TechnicalDetails;
            product.CategoryID = model.CategoryID;

            _productService.Edit(product);
            //-------------------------------------------------------------------
            price.ProductPrice = model.Price;
            price.ProductID = model.ProductID;

            _priceService.EditPrice(price);
            ////-------------------------------------------------------------------
            //image.ProductID = model.ProductID;
            //image.ImageUrl = model.Image;
            //_imageService.EditImage(image);
            //-----------------------------------------------------------------------

            var attval = new List<AttributesValue>();
            foreach (var item in model.AttributeValue)
            {
                var m = new AttributesValue();
                m.AttributesKeyID = item.AttKeyID;
                m.AttributeValueID = item.AttValID;
                m.Value = item.AttValTitle;
                m.ProductID = model.ProductID;
                attval.Add(m);
            }

            _attributeValueService.UpdateRange(attval);

            _productService.save();

            return RedirectToAction("GetProductlist", "Product");
        }
        //________________________________________________________________________________________________
        public IActionResult GetProduct()
        {


            return View();
        }
        //________________________________________________________________________________________________
        [HttpGet]
        public IActionResult ShowProduct(int id)
        {
            if (id == 0)
            {
                return RedirectToAction("Index", "Home");
            }
            var model = _productService.GetProductByID(id);

            var result = new ShowSingleProductvViewModel();
            result.ProductID = model.ProductID;
            result.ProductName = model.ProductName;
            result.TechnicalDetails = model.TechnicalDetail;
            result.CategoryName = model.CategoryTbls.CategoryName;

            result.Price = _priceService.GetCurrentPrice(model.ProductID);

            //result.Rate = _rateService.averageRate(model.ProductID);

            result.AttrinutesKey = _attributesKeyService.GetAllAttributeByCategoryId(model.CategoryID)
                .Select(atk => new AttributeKeyViewModel
                {
                    AttributeID = atk.AttributeKeyID,
                    AttributeName = atk.Title
                }).ToList();

            result.attributeValue = _attributeValueService.GetAllAttributeValueByProductID(model.ProductID)
                .Select(atv => new AttrinuteValueViewModel
                {
                    AttKeyID = atv.AttributesKeyID,
                    AttValID = atv.AttributeValueID,
                    AttValTitle = atv.Value
                }).ToList();

            result.ImageURL = _imageService.GetImageByProductID(model.ProductID).ImageUrl;

            //result.Questions = _questionService.GetQuestionsByProductID(model.ProductID);

            //result.Answers = _answerService.GetAnswersByProductID(model.ProductID);

            //result.Comments = _commentService.GetCommentsByProductID(model.ProductID);

            return View(result);
        }
        //________________________________________________________________________________________________
        public IActionResult GetComments(int id)
        {
            var model = _commentService.GetCommentsByProductID(id);
            var res = new List<CommentViewModel>();
            if (model != null)
            {
                foreach (var item in model)
                {
                    CommentViewModel m = new CommentViewModel();
                    m.CommentTitle = item.ProductComment;
                    m.UserID = item.UserID;
                    m.UserName = item.UserName;
                    m.ProductID = id;
                    res.Add(m);
                }
                ViewBag.id = id;
                return PartialView("_GetComments", res);
            }
            else
            {
                ViewBag.id = id;
                return PartialView("_GetComments", id);
            }

        }
        //________________________________________________________________________________________________
        [Authorize]
        public IActionResult AddComment(string Comment, int id)
        {
            string UserName = User.FindFirstValue(ClaimTypes.Name);
            string UserID = User.FindFirstValue(ClaimTypes.NameIdentifier);
            _commentService.AddComment(UserName, UserID, Comment, id);
            _commentService.save();
            return RedirectToAction("ShowProduct", "Product", new { id = id });
        }
        //________________________________________________________________________________________________
        public IActionResult GetQuestions(int id)
        {
            var resultmodel = new AnswerQuestionViewModel();
            var modelQ = _questionService.GetQuestionsByProductID(id);
            var modelA = _answerService.GetAnswersByProductID(id);

            resultmodel.ProductID = id;

            resultmodel.Questions = modelQ.Select(q => new QuestionsViewModels
            {
                QuestionID = q.QuestionID,
                QuestionTitle = q.QuestionTitle,
                UserName = q.UserName,
                IsAnswred = q.IsAnswered
            }).ToList();

            resultmodel.Answers = modelA.Select(a => new AnswerViewModels
            {
                AnswerID = a.AnswerId,
                AnswerTitle = a.AnswerTitle,
                QuestionID = a.QuestionID,
                UserName = a.UserName
            }).ToList();

            return PartialView("_GetQuestions", resultmodel);
        }
        //________________________________________________________________________________________________
        public IActionResult getuserId()
        {
            var t = User.Identity.IsAuthenticated;
            var a = User.Identity.Name;
            var userid = this.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var useri = this.User.FindFirstValue(ClaimTypes.Name);
            return View();
        }
        //_________________________________________________________________________________________________
        [Authorize]
        public IActionResult AddToCompare(int id)
        {
            if (User.Identity.IsAuthenticated)
            {
                string UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                _compareService.Add(id, UserId);
                _compareService.Save();
                return RedirectToAction("ShowProduct", "Product", id);
            }
            return Redirect("/Account/Login");
        }
        //_________________________________________________________________________________________________
        [Authorize]
        public IActionResult GetCompareProducts()
        {
            List<CompareViewModels> resultmodel = new List<CompareViewModels>();
            string UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var model = _compareService.returnproducts(UserId);

            for (int i = 0; i < model.Count; i++)
            {
                CompareViewModels rm = new CompareViewModels();
                var m = _productService.GetProductByID(model[i]);
                rm.ProductId = m.ProductID;
                rm.ProductName = m.ProductName;
                rm.ImageUrl = _imageService.GetImageByProductID(rm.ProductId).ImageUrl;
                rm.Price = _priceService.GetCurrentPrice(rm.ProductId);

                resultmodel.Add(rm);
            }
            return View(resultmodel);
        }
        //________________________________________________________________________________________________
        public IActionResult AddQuestion(int ProductID, string Qtext)
        {
            string Username = User.FindFirstValue(ClaimTypes.Name);
            string userid = User.FindFirstValue(ClaimTypes.NameIdentifier);
            _questionService.AddQuestion(Qtext, Username, userid, ProductID);
            _productService.save();
            return RedirectToAction("ShowProduct", "Product", new { id = ProductID });
        }
        //_________________________________________________________________________________________________
        [HttpGet]
        public IActionResult SearchProduct(string ProductName, int CategoryID, int minprice, int maxprice)
        {
            var model = _productService.SearchProduct(ProductName, CategoryID, minprice, maxprice)
                .Take(10)
                .ToList();

            var output = new List<ProductListViewModel>();

            foreach (var item in model)
            {
                var m = new ProductListViewModel();
                m.ProductID = item.ProductID;
                m.ProductName = item.ProductName;
                m.Price = _priceService.GetCurrentPrice(item.ProductID);
                m.Category = item.CategoryTbls.CategoryName;
                m.Image = _imageService.GetImageByProductID(item.ProductID).ImageUrl;
                output.Add(m);
            }

            return View(output);
        }
        //_________________________________________________________________________________________________
    }
}
