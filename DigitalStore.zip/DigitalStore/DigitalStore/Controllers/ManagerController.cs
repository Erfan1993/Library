﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataLayer.Services;
using DataModel.IdentityModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ViewModels.OrderViewModels;
using ViewModels.PublicViewModels;

namespace DigitalStore.Controllers
{
    public class ManagerController : Controller
    {
        private readonly UserManager<ApplicationUsers> _userManager;

        private IOrderService _orderService;
        private IOrderDetailsService _orderDetailsService;
        private ICommentService _commentService;
        private IQuestionService _questionService;
        private IAnswerService _answerService;

        public ManagerController(
            IOrderDetailsService orderDetailsService
            , IOrderService orderService
            , UserManager<ApplicationUsers> userManager
            , ICommentService commentService
            , IQuestionService questionService
            , IAnswerService answerService)
        {
            _orderDetailsService = orderDetailsService;
            _orderService = orderService;
            _userManager = userManager;
            _questionService = questionService;
            _commentService = commentService;
            _answerService = answerService;

            //StiLicense.LoadFromString("6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHl2AD0gPVknKsaW0un+3PuM6TTcPMUAWEURKXNso0e5OJN40hxJjK5JbrxU+NrJ3E0OUAve6MDSIxK3504G4vSTqZezogz9ehm+xS8zUyh3tFhCWSvIoPFEEuqZTyO744uk+ezyGDj7C5jJQQjndNuSYeM+UdsAZVREEuyNFHLm7gD9OuR2dWjf8ldIO6Goh3h52+uMZxbUNal/0uomgpx5NklQZwVfjTBOg0xKBLJqZTDKbdtUrnFeTZLQXPhrQA5D+hCvqsj+DE0n6uAvCB2kNOvqlDealr9mE3y978bJuoq1l4UNE3EzDk+UqlPo8KwL1XM+o1oxqZAZWsRmNv4Rr2EXqg/RNUQId47/4JO0ymIF5V4UMeQcPXs9DicCBJO2qz1Y+MIpmMDbSETtJWksDF5ns6+B0R7BsNPX+rw8nvVtKI1OTJ2GmcYBeRkIyCB7f8VefTSOkq5ZeZkI8loPcLsR4fC4TXjJu2loGgy4avJVXk32bt4FFp9ikWocI9OQ7CakMKyAF6Zx7dJF1nZw");
        }

        public async Task<IActionResult> Reports()
        {
            var model = _orderService.GetAllOrders();
            List<OrderViewModels> orders = new List<OrderViewModels>();
            foreach (var item in model)
            {
                var m = new OrderViewModels();
                m.Cost = item.Cost;
                m.Date = item.Date;
                m.OrderId = item.OrderID;
                var name = await _userManager.FindByIdAsync(item.UserID);
                m.UserName = name.Email;
                orders.Add(m);
            }
            return View(orders);
        }

        public IActionResult DeleteOrder()
        {
            return View();
        }

        //public IActionResult Print()
        //{
        //    StiReport report = new StiReport();
        //    report.Load(StiNetCoreHelper.MapPath(this, $"wwwroot/Reports/Report.mrt"));

        //    var model = _orderService.GetAllOrders();

        //    report.RegData("DT", model);
        //    return StiNetCoreViewer.GetReportResult(this, report);
        //    //return View();
        //}

        //public IActionResult PrintPage()
        //{

        //    return View("PrintPage");
        //}
        //public IActionResult ViewerEvent()
        //{
        //    return StiNetCoreViewer.ViewerEventResult(this);
        //}

        [HttpGet]
        public IActionResult CheckComments()
        {
            var model = _commentService.UnReadComments();
            var output = new List<CommentViewModel>();

            foreach (var item in model)
            {
                var m = new CommentViewModel();
                m.UserName = item.UserName;
                m.Id = item.CommentID;
                m.CommentTitle = item.ProductComment;
                output.Add(m);
            }
            return View(output);
        }
        //_______________________________________________________________________________________
        public IActionResult DeleteComments(int id)
        {
            _commentService.DeleteComment(id);
            _commentService.save();
            return RedirectToAction("CheckComments", "Manager");
        }
        //_______________________________________________________________________________________
        public IActionResult MarkAsRead(int id)
        {
            var model = _commentService.MarkAsRead(id);
            _commentService.save();
            return RedirectToAction("CheckComments", "Manager");
        }
        //_______________________________________________________________________________________
        [HttpGet]
        public IActionResult ShowQuestions()
        {
            var model = _questionService.GetAllUnAnswerQuestions();

            var output = new List<QuestionsViewModels>();

            foreach (var item in model)
            {
                var m = new QuestionsViewModels();
                m.QuestionID = item.QuestionID;
                m.UserName = item.UserName;
                m.QuestionTitle = item.QuestionTitle;
                output.Add(m);
            }
            return View(output);
        }

        [HttpGet]
        public IActionResult AnswerToQuestion(int id)
        {
            var model = _questionService.GetQuestionById(id);

            var output = new AnswerViewModels();
            output.QuestionID = id;
            output.AnswerTitle = model.QuestionTitle;
            output.UserName = model.UserName;
            output.ProductID = model.ProductID;
            return View(output);
        }

        [HttpPost]
        public IActionResult AnswerToQuestion(int id,string text,int ProductID)
        {
            _answerService.AddAnswerToQuestion(id, text, ProductID);
            _questionService.changeAsAnswered(id);
            _questionService.save();
            return RedirectToAction("ShowQuestions", "Manager");
        }

        public IActionResult DeleteQuestion(int id)
        {
            _questionService.DeleteQuestion(id);
            _questionService.save();
            return RedirectToAction("ShowQuestions", "Manager");
        }
    }
}