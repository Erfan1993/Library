﻿using DataLayer.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalStore.Components
{
    public class CommentComponent : ViewComponent
    {
        private ICommentService _commentService;

        public CommentComponent(ICommentService commentService)
        {
            _commentService = commentService;
        }
        [Authorize]
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var counter = _commentService.UnReadComments().Count;
            if (counter == 0)
            {
                return View("/Views/Shared/_CommentCounter.cshtml", 0);
            }
            return View("/Views/Shared/_CommentCounter.cshtml", counter);
        }
    }
}
