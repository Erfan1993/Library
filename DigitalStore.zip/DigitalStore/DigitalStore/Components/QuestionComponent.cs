﻿using DataLayer.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DigitalStore.Components
{
    public class QuestionComponent : ViewComponent
    {
        private IQuestionService _QuestionService;

        public QuestionComponent(IQuestionService questionService)
        {
            _QuestionService = questionService;
        }
        [Authorize]
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var counter = _QuestionService.GetAllUnAnswerQuestions().Count;
            if (counter == 0)
            {
                return View("/Views/Shared/_QuestionCounter.cshtml", 0);
            }
            return View("/Views/Shared/_QuestionCounter.cshtml", counter);
        }
    }
}
