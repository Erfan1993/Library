﻿using DataLayer.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DigitalStore.Components
{
    public class BasketComponent :ViewComponent 
    {
        private IOrderService _orderService;
        private IOrderDetailsService _orderDetailsService;

        public BasketComponent(
            IOrderDetailsService orderDetailsService
            , IOrderService orderService)
        {
            _orderDetailsService = orderDetailsService;
            _orderService = orderService;
        }
        [Authorize]
        public async Task<IViewComponentResult> InvokeAsync()

        {
            string Id = HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int count;
            count = _orderDetailsService.ProductCount(Id);
            if (count==0 )
            {
                return View("/Views/Shared/_BasketCount.cshtml", 0);
            }
            return View("/Views/Shared/_BasketCount.cshtml", count);
            
        }
    }
}
