﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.OrderViewModels
{
    public class OrderDetailsViewModel
    {

        public string ProductName { get; set; }
        public Single Price { get; set; }
        public int  Count { get; set; }

    }
}
