﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.OrderViewModels
{
    public class OrderViewModels
    {
        public int OrderId { get; set; }
        public string UserName { get; set; }
        public Single Cost { get; set; }
        public DateTime Date { get; set; }
    }
}
