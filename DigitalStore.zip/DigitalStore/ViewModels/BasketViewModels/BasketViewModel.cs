﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.BasketViewModels
{
    public class BasketViewModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int Count { get; set; }
        public string Image { get; set; }
        public Single Price { get; set; }
    }
}
