﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.BasketViewModels
{
    public class BasketListViewModel
    {
        public List<BasketViewModel> Items { get; set; }
        public Single Cost { get; set; }
        public string UserID { get; set; }
        public int OrderId { get; set; }
    }
}
