﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.PublicViewModels
{
    public class CommentViewModel
    {
        public int Id { get; set; }
        public string CommentTitle { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }
        public int ProductID { get; set; }
    }
}
