﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.PublicViewModels
{
    public class QuestionsViewModels
    {
        public int QuestionID { get; set; }
        public string QuestionTitle { get; set; }
        public bool IsAnswred { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }
        public int ProductID { get; set; }
    }
}
