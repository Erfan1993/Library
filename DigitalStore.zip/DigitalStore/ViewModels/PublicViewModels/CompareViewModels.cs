﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.PublicViewModels
{
   public class CompareViewModels
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public Single Price { get; set; }
        public string ImageUrl { get; set; }
    }
}
