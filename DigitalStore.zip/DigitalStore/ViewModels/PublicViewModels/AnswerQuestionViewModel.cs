﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.PublicViewModels
{
    public class AnswerQuestionViewModel
    {
        public List<AnswerViewModels> Answers { get; set; }
        public List<QuestionsViewModels> Questions { get; set; }
        public int ProductID { get; set; }
    }
}
