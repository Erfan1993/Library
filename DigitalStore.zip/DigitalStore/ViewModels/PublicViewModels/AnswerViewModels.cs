﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.PublicViewModels
{
    public class AnswerViewModels
    {
        public int AnswerID { get; set; }
        public int QuestionID { get; set; }
        public string AnswerTitle { get; set; }
        public int ProductID { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }
    }
}
