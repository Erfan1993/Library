﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.CategoryViewModels
{
    public class CategoryViewModel
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public int ProductCount { get; set; }
        public int AttributesCount { get; set; }
    }
}
