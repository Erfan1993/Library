﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ViewModels.AccountViewModel
{
    public class UserRegisterViewModel
    {
        [Required(ErrorMessage = "Enter Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Enter Family")]
        public string Family { get; set; }
        [Required(ErrorMessage = "Enter UserName")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Enter EmailAddress")]
        [EmailAddress]
        public string EmailAddress { get; set; }
        [Required(ErrorMessage = "Enter PhoneNumber")]
        public string PhoneNumber { get; set; }
        [Required(ErrorMessage = "Enter Password")]
        public string Password { get; set; }
        [Compare("Password", ErrorMessage = "Password must be match")]
        [Required(ErrorMessage = "Enter ConfirmPassword")]
        public string ConfirmPassword { get; set; }
        [Required(ErrorMessage = "Enter NationCode")]
        public int NationCode { get; set; }
    }
}
