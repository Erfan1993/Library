﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ViewModels.AccountViewModels
{
    public class RolesViewModel
    {
        [Required]
        public string RoleID { get; set; }
        [Required]
        public string RoleName { get; set; }
        [Required]
        public string Role { get; set; }
    }
}
