﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.HomeViewModels
{
    public class ListMainPageViewModel
    {
        public List<MainPageViewModel> DigitalProducts { get; set; }
        public List<MainPageViewModel> TopRankingProducts { get; set; }
        public List<MainPageViewModel> LastSellProducts { get; set; }
    }
}
