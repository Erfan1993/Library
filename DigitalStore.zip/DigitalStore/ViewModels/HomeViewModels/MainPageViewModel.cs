﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.HomeViewModels
{
    public class MainPageViewModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public Single price { get; set; }
        public string Image { get; set; }
        public int CategoryID { get; set; }
    }
}
