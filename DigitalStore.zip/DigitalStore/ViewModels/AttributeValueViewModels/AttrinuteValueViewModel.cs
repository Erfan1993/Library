﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.AttributeValueViewModels
{
    public class AttrinuteValueViewModel
    {
        public int AttValID { get; set; }
        public string AttValTitle { get; set; }
        public int AttKeyID { get; set; }
    }
}
