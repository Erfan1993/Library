﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.AttributeKeyViewModels
{
    public class AttributeKeyViewModel
    {
        public int AttributeID { get; set; }
        public string AttributeName { get; set; }
        public int CategoryID { get; set; }
        public bool Status { get; set; }
    }
}
