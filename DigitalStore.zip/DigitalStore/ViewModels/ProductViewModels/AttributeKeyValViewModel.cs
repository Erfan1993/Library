﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels.ProductViewModels
{
    public class AttributeKeyValViewModel
    {
        public int attKeyID { get; set; }
        public string attKeyTitle { get; set; }
        public string attVal { get; set; }
        public int ProductID { get; set; }
    }
}
