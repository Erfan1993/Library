﻿using System;
using System.Collections.Generic;
using System.Text;
using ViewModels.AttributeKeyViewModels;
using ViewModels.AttributeValueViewModels;

namespace ViewModels.ProductViewModels
{
   public class ShowSingleProductvViewModel
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string ImageURL { get; set; }
        public string CategoryName { get; set; }
        public int Rate { get; set; }
        public Single Price { get; set; }
        public string TechnicalDetails { get; set; }
        public List<AttrinuteValueViewModel> attributeValue { get; set; }
        public List<AttributeKeyViewModel> AttrinutesKey { get; set; }
        //public List<Comments> Comments { get; set; }
        //public List<Question> Questions { get; set; }
        //public List<Answer> Answers { get; set; }
    }
}
