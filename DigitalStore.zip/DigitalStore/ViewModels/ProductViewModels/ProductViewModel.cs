﻿using DataLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using ViewModels.ProductViewModels;

namespace ViewModels.ProductViewModels
{ 
    public class ProductViewModel
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string TechnicalDetails { get; set; }
        public int CategoryID { get; set; }
        public Single Price { get; set; }
        public IFormFile Image { get; set; }
        public List<SelectListItem> Categories{ get; set; }
        public List<AttributeKeyValViewModel> KeyListsVal { get; set; }
        public List<Image> Images { get; set; }
    }
}
