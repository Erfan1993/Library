﻿
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using ViewModels.AttributeKeyViewModels;
using ViewModels.AttributeValueViewModels;

namespace ViewModels.ProductViewModels
{
    public class ProductEditViewModel
    {
        public int CategoryID { get; set; }
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string TechnicalDetails { get; set; }
        public IFormFile Image { get; set; }
        public Single Price { get; set; }
        public List<AttrinuteValueViewModel> AttributeValue { get; set; }
        public List<AttributeKeyViewModel> AttributesKey { get; set; }
    }
}

