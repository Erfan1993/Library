﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataLayer.AplicationContext;
using DataLayer.IdentityModels;
using DataLayer.Repositories;
using DataLayer.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Cloob
{
    public class Startup
    {
        private IConfiguration Configuration;
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddMvc();
            services.AddSingleton(Configuration);

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.DefaultSignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
            }).AddCookie(options =>
            {
                options.LoginPath = "/Account/Login";
                options.LogoutPath = "/Account/Logoff";
                options.ExpireTimeSpan = TimeSpan.FromMinutes(43200);
            });



            services.AddSingleton(Configuration);
            services.AddDbContext<CloobDbContext>(option =>
                     option.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            services.AddIdentity<UserModel, RoleModel>()
                .AddEntityFrameworkStores<CloobDbContext>()
                .AddDefaultTokenProviders();

            services.AddMvc();



            services.AddScoped<IAccountService, AccountRepository>();
            services.AddScoped<IUserService, UserRepository>();
            services.AddScoped<IGalleryService, GalleryRepository>();
            services.AddScoped<IPostService, PostRepository>();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseIdentity();
            app.UseFileServer();
            app.UseStaticFiles();
            app.UseMvc(configureRoutes);

        }

        private void configureRoutes(IRouteBuilder obj)
        {
            obj.MapRoute(
                name: "DefaultRoute",
                template: "{Controller=Account}/{Action=Login}/{id?}"
                );
        }
    }
}
