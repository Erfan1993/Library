﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DataLayer.IdentityModels;
using DataLayer.Models;
using DataLayer.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Hosting;
using ViewModelLayer;
using ViewModelLayer.GalleryViewModels;
using ViewModelLayer.PostsViewModels;
using ViewModelLayer.PublicViewModels;
using ViewModelLayer.UserViewModels;

namespace Cloob.Controllers
{
    public class UsersController : Controller
    {
        private IUserService _UserService;
        private IGalleryService _galleryService;
        private IPostService _PostService;
        private HostingEnvironment _AppEnvironment;
        public UsersController(IUserService userService
            , HostingEnvironment hosting
            , IGalleryService gallery
            , IPostService postService)
        {
            _UserService = userService;
            _AppEnvironment = hosting;
            _galleryService = gallery;
            _PostService = postService;
        }
        public IActionResult Index()
        {
            var model = _PostService.GetAllPost().Take(10);


            var res = new UserIndexViewModels();

            res.PostsList = model.Select(a => new PostViewModel
            {
                PostID = a.PostID,
                UserID = a.UserID,
                UserName = a.UserName,
                Comments = a.CommentList.Count,
                Title = a.Title,
                ImageUrl = a.Url,
                like = a.Like,
                DisLike = a.DisLike
            }).ToList();

            return View(res);
        }
        public IActionResult UserPanel()
        {
            return View();
        }
        [HttpGet]
        [Authorize]
        public IActionResult ChangeProfile()
        {
            var model = new EditProfileViewModel();
            string res = _UserService.ImageYrl(User.FindFirstValue(ClaimTypes.NameIdentifier));

            model.ImageUrl = res;
            return PartialView("_ChangeProfile", model);
        }
        [HttpPost]
        public async Task<IActionResult> ChangeProfile(EditProfileViewModel model)
        {
            string url;
            var Imagemodel = model.ProfileImage;
            if (Imagemodel != null && Imagemodel.Length > 0)
            {
                var uploads = Path.Combine(_AppEnvironment.WebRootPath, @"Image\");
                if (Imagemodel.Length > 0)
                {
                    var fileName = Guid.NewGuid().ToString().Replace("-", "") + Path.GetExtension(Imagemodel.FileName);
                    using (var fileStream = new FileStream(Path.Combine(uploads, fileName), FileMode.Create))
                    {
                        await Imagemodel.CopyToAsync(fileStream);
                        url = fileName;
                        _UserService.ChangePhoto(User.FindFirstValue(ClaimTypes.NameIdentifier), url);
                        _UserService.Save();
                    }
                }
            }


            return RedirectToAction("UserPanel", "Users");
            //return PartialView("_ChangeProfile");
        }
        [HttpGet]
        public IActionResult PersonalInfo()
        {
            var model = new PersonalInfoViewModels();

            var modelinfo = _UserService.GetPersonalInfo(User.FindFirstValue(ClaimTypes.NameIdentifier));

            model.CityNameChanger = _UserService.GetAllCities().Select(
                a => new SelectListItem
                {
                    Value = a.CityID.ToString(),
                    Text = a.CityName
                }).ToList();

            model.Name = modelinfo.Name;
            model.Family = modelinfo.Family;
            model.TellNumber = modelinfo.PhoneNumber;
            model.BirthDay = modelinfo.BirthDay;
            model.CityName = modelinfo.Cities.CityName.ToString();

            return PartialView("_PersonalInfo", model);
        }
        [HttpPost]
        public IActionResult EditPersonalInfo(PersonalInfoViewModels inputmodel)
        {
            var city = new CityModel()
            {
                CityID = inputmodel.CityCode
            };
            UserModel outputmodel = new UserModel()
            {
                Name = inputmodel.Name,
                Family = inputmodel.Family,
                PhoneNumber = inputmodel.TellNumber,
                BirthDay = inputmodel.BirthDay,

            };

            _UserService.ChangePersonalInfo(outputmodel, User.FindFirstValue(ClaimTypes.NameIdentifier));

            _UserService.Save();

            return RedirectToAction("UserPanel", "Users");
        }
        [HttpGet]
        public IActionResult Privacy()
        {
            var model = _UserService.GetPrivacy(User.FindFirstValue(ClaimTypes.NameIdentifier));

            PrivacyViewModels result = new PrivacyViewModels()
            {
                IsFreindsLastSeenVisibility = model.IsFriendsListVisibility,
                IsGalleryVisibility = model.IsGalleryVisibility,
                IsLastSeenVisibility = model.IsLastSeenVisibility
            };
            return PartialView("_Privacy", result);
        }
        [HttpPost]
        public IActionResult Privacy(PrivacyViewModels inmodel)
        {
            UserModel userModel = new UserModel()
            {
                IsFriendsListVisibility = inmodel.IsFreindsLastSeenVisibility,
                IsGalleryVisibility = inmodel.IsGalleryVisibility,
                IsLastSeenVisibility = inmodel.IsLastSeenVisibility,
                Id = User.FindFirstValue(ClaimTypes.NameIdentifier)
            };

            _UserService.ChangePrivacy(userModel);
            _UserService.Save();
            return View();
        }
        [HttpGet]
        public IActionResult Gallery()
        {
            List<GalleryViewModel> models = new List<GalleryViewModel>();

            models = _galleryService.GetGallery(User.FindFirstValue(ClaimTypes.NameIdentifier)).Select(
                a => new GalleryViewModel
                {
                    ImageUrl = a.ImageURL,
                    GalleryID = a.GalleryID
                }).ToList();

            return PartialView("_Gallery", models);
        }
        public async Task<IActionResult> AddImageToGallery(IFormFile Image)
        {

            string url;
            var Imagemodel = Image;
            if (Imagemodel != null && Imagemodel.Length > 0)
            {
                var uploads = Path.Combine(_AppEnvironment.WebRootPath, @"Image\");
                if (Imagemodel.Length > 0)
                {
                    var fileName = Guid.NewGuid().ToString().Replace("-", "") + Path.GetExtension(Imagemodel.FileName);
                    using (var fileStream = new FileStream(Path.Combine(uploads, fileName), FileMode.Create))
                    {
                        await Imagemodel.CopyToAsync(fileStream);
                        url = fileName;
                        _galleryService.AddImage(User.FindFirstValue(ClaimTypes.NameIdentifier), url);
                    }
                }
            }

            _galleryService.Save();

            return View();
        }
        public IActionResult DeleteIamage(int Id)
        {
            _galleryService.DeleteImage(Id);
            _galleryService.Save();
            return View();
        }
        public IActionResult ShowProfile(string ID)
        {
            ProfileViewModel profile = new ProfileViewModel();

            var personal = _UserService.GetUserByUserID(ID);
            var gallery = _galleryService.GetGallery(ID);
            var posts = _PostService.GetUserPosts(ID).Take(5);

            profile.Galleries = gallery.Select(a => new GalleryViewModel
            {
                GalleryID = a.GalleryID,
                ImageUrl = a.ImageURL
            }).ToList();

            PersonalInfoViewModels p = new PersonalInfoViewModels()
            {
                BirthDay = personal.BirthDay,
                Family = personal.Family,
                Name = personal.Name
            };
            profile.Personal = p;

            profile.Post = posts.Select(o => new PostViewModel
            {
                Title = o.Title,
                ImageUrl = o.Url,
                PostID = o.PostID,
                Comments = o.CommentList.Count,
                like = o.Like,
                DisLike = o.DisLike
            }).ToList();

            PrivacyViewModels privacy = new PrivacyViewModels()
            {
                IsFreindsLastSeenVisibility = personal.IsFriendsListVisibility,
                IsGalleryVisibility = personal.IsGalleryVisibility,
                IsLastSeenVisibility = personal.IsLastSeenVisibility
            };
            profile.Privacy = privacy;

            return View(profile);
        }
        public IActionResult ShowFreinds(string UserId)
        {
            return View();
        }

    }
}