﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DataLayer.Models;
using DataLayer.Services;
using Microsoft.AspNetCore.Hosting.Internal;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ViewModelLayer.PostsViewModels;

namespace Cloob.Controllers
{
    public class PostController : Controller
    {
        private IPostService _PostService;
        private HostingEnvironment _AppEnvironment;
        public PostController(IPostService postService
            , HostingEnvironment AppEnvironment)
        {
            _PostService = postService;
            _AppEnvironment = AppEnvironment;
        }
        [HttpGet]
        public IActionResult CreatePost()
        {
            return PartialView("_CreatePost");
        }
        [HttpPost]
        public async Task<IActionResult> CreatePost(PostViewModel inputpost, IFormFile ImageUrl)
        {
            string url;
            var Imagemodel = ImageUrl;
            if (Imagemodel != null && Imagemodel.Length > 0)
            {
                var uploads = Path.Combine(_AppEnvironment.WebRootPath, @"Image\");
                if (Imagemodel.Length > 0)
                {
                    var fileName = Guid.NewGuid().ToString().Replace("-", "") + Path.GetExtension(Imagemodel.FileName);
                    using (var fileStream = new FileStream(Path.Combine(uploads, fileName), FileMode.Create))
                    {
                        await Imagemodel.CopyToAsync(fileStream);
                        url = fileName;

                        PostModel CreatePost = new PostModel()
                        {
                            Title = inputpost.Title,
                            Url = url,
                            UserID = User.FindFirstValue(ClaimTypes.NameIdentifier),
                            UserName = User.FindFirstValue(ClaimTypes.Name)
                        };
                        _PostService.Add(CreatePost);
                        _PostService.Save();
                    }
                }
            }
            return View();
        }
        public IActionResult Like(int id)
        {
            _PostService.Like(id);
            _PostService.Save();
            return RedirectToAction("Index", "Users");
        }
        public IActionResult DisLike(int id)
        {
            _PostService.DisLike(id);
            _PostService.Save();
            return RedirectToAction("Index", "Users");
        }
        public IActionResult ShowComments(int Id)
        {
            var model = _PostService.GetPostByID(Id);

            PostViewModel post = new PostViewModel()
            {
                PostID = model.PostID,
                UserID = model.UserID,
                Title = model.Title,
                UserName = model.UserName,
                ImageUrl = model.Url,
                like = model.Like,
                DisLike = model.DisLike
            };

            List<CommentsViewModel> comments = new List<CommentsViewModel>();

            comments = model.CommentList.Select(a => new CommentsViewModel
            {
                CommentID = a.ID,
                CommentTitle = a.CommentTitle,
                PostID = a.PostID,
                UserID = a.UserID,
                UserName = a.UserName
            }).ToList();

            ShowPostViewModel show = new ShowPostViewModel();
            show.Comments = comments;
            show.Post = post;
            return View(show);
        }
        public IActionResult AddComment(string Comments, int PostID)
        {
            CommentModel model = new CommentModel()
            {
                CommentTitle = Comments,
                PostID = PostID,
                UserID = User.FindFirstValue(ClaimTypes.NameIdentifier),
                UserName = User.FindFirstValue(ClaimTypes.Name)
            };

            _PostService.AddComment(model);
            _PostService.Save();
            return RedirectToAction("ShowComments", "Post", new { id = PostID });
        }
        public IActionResult ReportPost(int ID)
        {
            _PostService.ReportPost(ID, ReportType.ReportPosts, User.FindFirstValue(ClaimTypes.NameIdentifier));
            _PostService.Save();
            return View("");
        }
    }
}