﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DataLayer.IdentityModels;
using DataLayer.Repositories;
using DataLayer.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using ViewModelLayer.AccountViewModels;

namespace Cloob.Controllers
{
    public class AccountController : Controller
    {
        private IAccountService _AccountService;
        private IUserService _UserService;
        public AccountController(IAccountService accountService, IUserService userService)
        {
            _AccountService = accountService;
            _UserService = userService;
        }
        [HttpGet]
        public IActionResult Login()
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("index", "Users");
            }
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = _AccountService.Login(model.UserName, model.Password, model.RememberMe);

                var t = User.Identity.IsAuthenticated;

                if (result == true)
                {
                    return RedirectToAction("Index", "Users");
                }
                else
                {
                    return View("_ExeptionPage", "Login Was Not Complete Because Wrong Information");
                }
            }
            return RedirectToAction("Index", "Users");
        }
        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(SiginViewModel inputModel)
        {
            if (ModelState.IsValid)
            {
                var user = new UserModel
                {
                    Email = inputModel.EmailAddress,
                    Family = inputModel.Family,
                    Name = inputModel.Name,
                    PhoneNumber = inputModel.PhoneNumber,
                    UserName = inputModel.UserName,
                    ProfileImage = "UserFace.jpg"
                };
                var result = _AccountService.RegisterUser(user, inputModel.Password, inputModel.ConfirmPassword);
                if (result == true)
                {
                    _AccountService.AddToRole(user, "User");
                    _AccountService.Save();
                    return RedirectToAction("Login", "Account");
                }
                else
                {
                    return View("_ExeptionPage", "You Must Insert Correct Information");
                }
            }
            else
            {
                return View("_ExeptionPage", "Wrong Information You Entered");
            }
        }
        [HttpGet]
        public IActionResult LogOut()
        {
            _UserService.SaveLastSeen(User.FindFirstValue(ClaimTypes.NameIdentifier));
            _UserService.Save();
            _AccountService.Logout();
            return RedirectToAction("Login", "Account");
        }
        [HttpGet]
        public IActionResult ChangePassword()
        {
            return PartialView("_ChangePassword");
        }
        [HttpPost]
        public IActionResult ChangePassword(string Password, string ConfirmPassword)
        {
            if (Password == ConfirmPassword)
            {
                _AccountService.ChangePassword(User.FindFirstValue(ClaimTypes.NameIdentifier), ConfirmPassword);
                _AccountService.Save();
            }
            else
            {
                return RedirectToAction("");
            }

            return RedirectToAction("Login", "Account");
        }

        [HttpGet]
        public IActionResult DeleteAccount()
        {
            return PartialView("_DeleteAccount");
        }

        [HttpPost]
        public IActionResult DeleteAccount(string Description)
        {
            _AccountService.DeleteAccount(
                Description,
                DataLayer.Models.ReportType.DeleteAccount,
                User.FindFirstValue(ClaimTypes.NameIdentifier));

            _AccountService.Save();

            _AccountService.Logout();
            return RedirectToAction("Login", "Account");
        }


    }
}