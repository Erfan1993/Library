﻿using DataLayer.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Cloob.Components
{
    public class ProfileComponent : ViewComponent
    {
        private IUserService _account;
        public ProfileComponent(IUserService account)
        {
            _account = account;
        }
        public async Task<string> InvokeAsync()
        {
            return  _account.ImageYrl(HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier));
        }
    }
}
