﻿using DataLayer.IdentityModels;
using DataLayer.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.AplicationContext
{
    public class CloobDbContext : IdentityDbContext<UserModel, RoleModel, string>
    {
        public CloobDbContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<UserModel> UserModels { get; set; }
        public DbSet<RoleModel> RoleModels { get; set; }
        public DbSet<CommentModel> Comments { get; set; }
        public DbSet<PostModel> PostModels { get; set; }
        public DbSet<CityModel> CityModels{ get; set; }
        public DbSet<FriendShipModel> FriendShipModels{ get; set; }
        public DbSet<ReportLoggerModel> reportsLogger{ get; set; }
        public DbSet<GalleryModel> GalleryModels{ get; set; }
        
    }
}
