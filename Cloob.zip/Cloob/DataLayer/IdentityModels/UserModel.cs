﻿using DataLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.IdentityModels
{
    public class UserModel : IdentityUser
    {
        public string Name { get; set; }
        public string Family { get; set; }
        public string Bio { get; set; }
        public string AboutMe { get; set; }
        public string ProfileImage { get; set; }
        public string NickName { get; set; }
        public string Gender { get; set; }
        public DateTime BirthDay { get; set; }
        public DateTime lastSeen { get; set; }

        public bool IsLastSeenVisibility { get; set; }
        public bool IsFriendsListVisibility { get; set; }
        public bool IsGalleryVisibility { get; set; }


        public CityModel Cities { get; set; }
        public List<CommentModel> Comments { get; set; }
        public List<PostModel> Posts { get; set; }
        public List<FriendShipModel> FriendsList { get; set; }
        public List<GalleryModel> Galleries { get; set; }
    }
}
