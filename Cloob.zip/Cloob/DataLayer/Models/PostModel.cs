﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
    public class PostModel
    {
        [Key]
        public int PostID { get; set; }
        public List<CommentModel> CommentList { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string Url { get; set; }
        public string Title { get; set; }
        public int Like { get; set; }
        public int DisLike { get; set; }
        public bool IsReported { get; set; }

    }
}
