﻿using DataLayer.IdentityModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
   public class GalleryModel
    {
        [Key]
        public int GalleryID { get; set; }
        [ForeignKey("UserID")]
        public string UserID { get; set; }
        public string ImageURL { get; set; }
        public int Like { get; set; }
        public int DisLike { get; set; }
    }
}
