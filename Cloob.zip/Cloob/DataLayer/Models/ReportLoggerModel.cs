﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataLayer.Models
{
    public class ReportLoggerModel
    {
        [Key]
        public int ID { get; set; }
        public string Desciptions { get; set; }
        public string UserID { get; set; }
        public string ReportedID { get; set; }
        public ReportType Report { get; set; }
    }

    public enum ReportType
    {
        DeleteAccount,
        ReportPosts,
        ReportUsers
    }
}
