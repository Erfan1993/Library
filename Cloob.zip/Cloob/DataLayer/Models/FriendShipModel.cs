﻿using DataLayer.IdentityModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
   public class FriendShipModel
    {
        [Key]
        public int FriendShipID { get; set; }

        [ForeignKey("FriendFrom")]
        public string FriendFrom { get; set; }

        [ForeignKey("FriendTo")]
        public string FriendTo { get; set; }
        public bool IsAccepted { get; set; }
    }
}
