﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataLayer.Models
{
    public class CommentModel
    {
        [Key]
        public int ID { get; set; }
        public string CommentTitle { get; set; }

        [ForeignKey("UserID")]
        public string UserID { get; set; }
        public string UserName { get; set; }

        public int PostID { get; set; }
    }
}
