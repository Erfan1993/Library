﻿using DataLayer.IdentityModels;
using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IAccountService
    {

        

        bool RegisterUser(UserModel InputModel, string Password, string ConfirmPassword);
        bool Login(string UserName, string Password, bool RememberMe);
        bool Logout();
        bool AddToRole(UserModel inputUser, string RoleName);

        bool CreateRole(RoleModel inputRole);
        List<RoleModel> GetAllRoles();
        bool EditRole(RoleModel inputRoleForChange);
        RoleModel FindRole(string InputRoleId);
        bool Delete(string inputRoleId);
        string GetserNamebyUserID(string UserId);
        void ChangePassword(string UserID, string Password);

        void DeleteAccount(string Desciption, ReportType type,string UserID);
        void Save();
    }
}
