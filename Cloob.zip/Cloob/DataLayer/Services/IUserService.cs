﻿using DataLayer.IdentityModels;
using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IUserService
    {
        void SaveLastSeen(string UserID);
        string ImageYrl(string UserID);
        void ChangePhoto(string UserID, string ImageUrl);
        List<CityModel> GetAllCities();
        UserModel GetPersonalInfo(string UserID);
        void ChangePersonalInfo(UserModel InputuserModel, string UserID);
        UserModel GetUserByUserID(string UserID);
        void Save();

        UserModel GetPrivacy(string UserID);
        void ChangePrivacy(UserModel userModel);
    }
}
