﻿using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IGalleryService
    {
        List<GalleryModel> GetGallery(string UserID);
        void AddImage(string UserID, string ImageUrl);
        void DeleteImage(int id);
        void Save();
    }
}
