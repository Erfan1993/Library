﻿using DataLayer.IdentityModels;
using DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Services
{
    public interface IPostService
    {
        void Add(PostModel InputModel);
        List<PostModel> GetAllPost();
        PostModel GetPostByID(int ID);
        List<CommentModel> GetAllComments(int id);
        void AddComment(CommentModel commentModel);
        void Like(int ID);
        void DisLike(int ID);
        void Save();
        void ReportPost(int id, ReportType type, string UserID);
        List<PostModel> GetUserPosts(string UserID);

    }
}
