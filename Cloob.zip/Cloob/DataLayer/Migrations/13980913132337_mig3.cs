﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class mig3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_CityModels_CitiesCityID",
                table: "AspNetUsers");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_CitiesCityID",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "CitiesCityID",
                table: "AspNetUsers");

            migrationBuilder.AddColumn<int>(
                name: "CityID",
                table: "AspNetUsers",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_CityID",
                table: "AspNetUsers",
                column: "CityID");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_CityModels_CityID",
                table: "AspNetUsers",
                column: "CityID",
                principalTable: "CityModels",
                principalColumn: "CityID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_CityModels_CityID",
                table: "AspNetUsers");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_CityID",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "CityID",
                table: "AspNetUsers");

            migrationBuilder.AddColumn<int>(
                name: "CitiesCityID",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_CitiesCityID",
                table: "AspNetUsers",
                column: "CitiesCityID");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_CityModels_CitiesCityID",
                table: "AspNetUsers",
                column: "CitiesCityID",
                principalTable: "CityModels",
                principalColumn: "CityID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
