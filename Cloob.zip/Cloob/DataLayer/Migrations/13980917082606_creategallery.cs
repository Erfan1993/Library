﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class creategallery : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_GalleryModel_AspNetUsers_UserModelId",
                table: "GalleryModel");

            migrationBuilder.DropPrimaryKey(
                name: "PK_GalleryModel",
                table: "GalleryModel");

            migrationBuilder.RenameTable(
                name: "GalleryModel",
                newName: "GalleryModels");

            migrationBuilder.RenameIndex(
                name: "IX_GalleryModel_UserModelId",
                table: "GalleryModels",
                newName: "IX_GalleryModels_UserModelId");

            migrationBuilder.AddColumn<int>(
                name: "DisLike",
                table: "GalleryModels",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Like",
                table: "GalleryModels",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_GalleryModels",
                table: "GalleryModels",
                column: "GalleryID");

            migrationBuilder.AddForeignKey(
                name: "FK_GalleryModels_AspNetUsers_UserModelId",
                table: "GalleryModels",
                column: "UserModelId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_GalleryModels_AspNetUsers_UserModelId",
                table: "GalleryModels");

            migrationBuilder.DropPrimaryKey(
                name: "PK_GalleryModels",
                table: "GalleryModels");

            migrationBuilder.DropColumn(
                name: "DisLike",
                table: "GalleryModels");

            migrationBuilder.DropColumn(
                name: "Like",
                table: "GalleryModels");

            migrationBuilder.RenameTable(
                name: "GalleryModels",
                newName: "GalleryModel");

            migrationBuilder.RenameIndex(
                name: "IX_GalleryModels_UserModelId",
                table: "GalleryModel",
                newName: "IX_GalleryModel_UserModelId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_GalleryModel",
                table: "GalleryModel",
                column: "GalleryID");

            migrationBuilder.AddForeignKey(
                name: "FK_GalleryModel_AspNetUsers_UserModelId",
                table: "GalleryModel",
                column: "UserModelId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
