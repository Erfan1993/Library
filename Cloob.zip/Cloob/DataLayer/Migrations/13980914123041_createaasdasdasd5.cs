﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    public partial class createaasdasdasd5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ReportedID",
                table: "reportsLogger",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UserID",
                table: "reportsLogger",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ReportedID",
                table: "reportsLogger");

            migrationBuilder.DropColumn(
                name: "UserID",
                table: "reportsLogger");
        }
    }
}
