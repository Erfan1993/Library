﻿using DataLayer.AplicationContext;
using DataLayer.IdentityModels;
using DataLayer.Models;
using DataLayer.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class PostRepository : IPostService
    {
        private CloobDbContext _Context;
        public PostRepository(CloobDbContext context)
        {
            _Context = context;
        }
        public void Add(PostModel InputModel)
        {
            _Context.PostModels.Add(InputModel);
        }
        public void DisLike(int ID)
        {
            var model = _Context.PostModels.FirstOrDefault(a => a.PostID == ID);
            model.Like = model.Like - 1;
            _Context.PostModels.Update(model);
        }
        public void Like(int ID)
        {
            var model = _Context.PostModels.FirstOrDefault(a => a.PostID == ID);
            model.Like = model.Like + 1;
            _Context.PostModels.Update(model);
        }
        public List<PostModel> GetAllPost()
        {
            return _Context.PostModels
                 .Include(a => a.CommentList)
                 .ToList();
        }
        public PostModel GetPostByID(int ID)
        {
            return _Context.PostModels.Include(a => a.CommentList).FirstOrDefault(a => a.PostID == ID);
        }
        public void Save()
        {
            _Context.SaveChanges();
        }
        public List<CommentModel> GetAllComments(int id)
        {
            throw new NotImplementedException();
        }
        public void AddComment(CommentModel commentModel)
        {
            _Context.Comments.Add(commentModel);
        }
        public void ReportPost(int id, ReportType type, string UserID)
        {
            ReportLoggerModel model = new ReportLoggerModel();
            model.ReportedID = id.ToString();
            model.UserID = UserID;
            model.Report = type;
            _Context.reportsLogger.Add(model);

        }
        public List<PostModel> GetUserPosts(string UserID)
        {
            return _Context.PostModels.Include(a=>a.CommentList).Where(a => a.UserID == UserID).ToList();
        }
    }
}
