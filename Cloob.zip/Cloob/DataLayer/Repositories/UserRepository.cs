﻿using DataLayer.AplicationContext;
using DataLayer.IdentityModels;
using DataLayer.Models;
using DataLayer.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class UserRepository : IUserService
    {
        private CloobDbContext _context;
        public UserRepository(CloobDbContext context)
        {
            _context = context;
        }
        public void ChangePersonalInfo(UserModel InputuserModel, string UserID)
        {
            var model = GetUserByUserID(UserID);
            model.Name = InputuserModel.Name;
            model.Family = InputuserModel.Family;
            model.PhoneNumber = InputuserModel.PhoneNumber;
            model.BirthDay = InputuserModel.BirthDay;
            //model.CityID = InputuserModel.CityID;

            _context.UserModels.Update(model);
        }
        public UserModel GetPersonalInfo(string UserID)
        {
            var model = _context.UserModels.Include(a => a.Cities).Where(a => a.Id == UserID)
                .Select(a => new UserModel
                {
                    Name = a.Name,
                    Family = a.Family,
                    PhoneNumber = a.PhoneNumber,
                    BirthDay = a.BirthDay,
                    Cities = a.Cities
                })
                .FirstOrDefault();
            return model;
        }
        public void ChangePhoto(string UserID, string ImageUrl)
        {
            var model = _context.UserModels.Find(UserID);
            model.ProfileImage = ImageUrl;
            _context.UserModels.Update(model);
        }
        public List<CityModel> GetAllCities()
        {
            return _context.CityModels.ToList();
        }
        public UserModel GetUserByUserID(string UserID)
        {
            return _context.UserModels.Include(a => a.Cities).Where(a => a.Id == UserID).FirstOrDefault();
        }
        public string ImageYrl(string UserID)
        {
            var model = _context.UserModels.Where(a => a.Id == UserID).FirstOrDefault().ProfileImage.ToString();
            if (model == null)
            {
                return "No Photo";
            }
            else
            {
                return model;
            }
        }
        public void Save()
        {
            _context.SaveChanges();
        }
        public void SaveLastSeen(string UserID)
        {
            var model = _context.UserModels.Find(UserID);
            model.lastSeen = DateTime.Now;
            _context.Update(model);
        }
        public UserModel GetPrivacy(string UserID)
        {
            return _context.UserModels.Where(a => a.Id == UserID).FirstOrDefault();
        }
        public void ChangePrivacy(UserModel userModel)
        {
            UserModel model = new UserModel();
            model = _context.UserModels.Find(userModel.Id);

            model.IsFriendsListVisibility = userModel.IsFriendsListVisibility;
            model.IsLastSeenVisibility = userModel.IsLastSeenVisibility;
            model.IsGalleryVisibility = userModel.IsGalleryVisibility;

            _context.UserModels.Update(model);
        }
    }
}
