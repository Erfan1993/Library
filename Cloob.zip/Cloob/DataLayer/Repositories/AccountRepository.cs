﻿using DataLayer.AplicationContext;
using DataLayer.IdentityModels;
using DataLayer.Models;
using DataLayer.Services;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class AccountRepository : IAccountService
    {
        private readonly CloobDbContext _context;

        private UserManager<UserModel> _userManager;
        private SignInManager<UserModel> _SignInManager;
        private RoleManager<RoleModel> _RoleManager;

        public AccountRepository
            (
            SignInManager<UserModel> signInManager,
            UserManager<UserModel> userManager,
            RoleManager<RoleModel> roleManager,
            CloobDbContext context
            )
        {
            _userManager = userManager;
            _SignInManager = signInManager;
            _RoleManager = roleManager;
            _context = context;
        }

        public bool AddToRole(UserModel inputUser, string RoleName)
        {
            var roleresult = _userManager.AddToRoleAsync(inputUser, RoleName);
            if (roleresult.Result.Succeeded)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool CreateRole(RoleModel inputRole)
        {
            var model = _RoleManager.CreateAsync(inputRole);
            if (model.Result.Succeeded)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool Delete(string inputRoleId)
        {
            var result = FindRole(inputRoleId);
            if (result == null)
            {
                return false;
            }
            else
            {
                var res = _RoleManager.DeleteAsync(result);
                if (res.Result.Succeeded)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public bool EditRole(RoleModel inputRoleForChange)
        {
            var result = FindRole(inputRoleForChange.Id);
            //result.Id = inputRoleForChange.Id;
            result.Name = inputRoleForChange.Name;
            result.NormalizedName = inputRoleForChange.NormalizedName;

            var a = _RoleManager.UpdateAsync(result);
            if (a.Result.Succeeded)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public RoleModel FindRole(string InputRoleId)
        {
            if (InputRoleId == "")
            {
                return _context.RoleModels.Find(InputRoleId);
            }
            else
            {
                return _context.RoleModels.Find(InputRoleId);
            }

        }
        public List<RoleModel> GetAllRoles()
        {
            return _context.RoleModels.ToList();

        }
        public bool Login(string UserName, string Password, bool RememberMe)
        {
            var res = _SignInManager.PasswordSignInAsync(UserName, Password, RememberMe, lockoutOnFailure: false);
            if (res.Result.Succeeded)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool Logout()
        {
            var a = _SignInManager.SignOutAsync();
            if (a.IsCompleted)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool RegisterUser(UserModel InputModel, string Password, string ConfirmPassword)
        {
            if (Password == ConfirmPassword)
            {
                InputModel.IsFriendsListVisibility = true;
                InputModel.IsGalleryVisibility = true;
                InputModel.IsLastSeenVisibility = true;
                
                var a = _userManager.CreateAsync(InputModel, Password);

                if (a.Result.Succeeded)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        public string GetserNamebyUserID(string UserId)
        {
            return _context.UserModels.Where(a => a.Id == UserId).Select(b => b.UserName).FirstOrDefault();
        }
        public void Save()
        {
            _context.SaveChanges();
        }
        public void ChangePassword(string UserID, string Password)
        {
            UserModel user = new UserModel();
            user = _context.UserModels.Find(UserID);

            string pass = _userManager.PasswordHasher.HashPassword(user, Password);

            user.PasswordHash = pass;

            _context.UserModels.Update(user);


        }
        public void DeleteAccount(string Desciption, ReportType type, string UserID)
        {
            var model = _context.UserModels.Find(UserID);
            _context.UserModels.Remove(model);

            var report = new ReportLoggerModel();
            report.Desciptions = Desciption;
            report.Report = type;
            report.UserID = UserID;

            _context.reportsLogger.Add(report);

        }
    }
}
