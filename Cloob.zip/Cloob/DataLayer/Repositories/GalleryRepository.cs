﻿using DataLayer.AplicationContext;
using DataLayer.Models;
using DataLayer.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer.Repositories
{
    public class GalleryRepository : IGalleryService
    {
        private CloobDbContext _context;
        public GalleryRepository(CloobDbContext context)
        {
            _context = context;
        }

        public void AddImage(string UserID, string ImageUrl)
        {
            GalleryModel model = new GalleryModel();
            model.ImageURL = ImageUrl;
            model.UserID = UserID;
            _context.GalleryModels.Add(model);
        }

        public void DeleteImage(int id)
        {
            var model = _context.GalleryModels.Find(id);
            _context.GalleryModels.Remove(model);
        }

        public List<GalleryModel> GetGallery(string UserID)
        {
            return _context.GalleryModels.Where(a => a.UserID == UserID).ToList();
        }

        public void Save()
        {
            _context.SaveChanges();
        }
    }
}
