﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModelLayer.UserViewModels
{
    public class FriendViewModels
    {
        public string UserName { get; set; }
        public string UserID { get; set; }
        public string FreindImage { get; set; }

    }
}
