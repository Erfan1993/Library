﻿using DataLayer.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModelLayer.UserViewModels
{
    public class PersonalInfoViewModels
    {
        public string Name { get; set; }
        public string Family { get; set; }
        public DateTime BirthDay { get; set; }
        public string TellNumber { get; set; }
        public string CityName { get; set; }
        public int CityCode{ get; set; }
        public List<SelectListItem> CityNameChanger{ get; set; }
    }
}
