﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModelLayer.UserViewModels
{
    public class EditProfileViewModel
    {
        public int ID { get; set; }
        public IFormFile ProfileImage{ get; set; }
        public string ImageUrl { get; set; }
    }
}
