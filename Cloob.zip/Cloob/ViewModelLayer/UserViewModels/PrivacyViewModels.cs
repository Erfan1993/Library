﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModelLayer.UserViewModels
{
    public class PrivacyViewModels
    {
        public bool IsLastSeenVisibility { get; set; }
        public bool IsFreindsLastSeenVisibility { get; set; }
        public bool IsGalleryVisibility { get; set; }
    }
}
