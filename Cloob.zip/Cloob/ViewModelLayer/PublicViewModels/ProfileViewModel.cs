﻿using System;
using System.Collections.Generic;
using System.Text;
using ViewModelLayer.GalleryViewModels;
using ViewModelLayer.PostsViewModels;
using ViewModelLayer.UserViewModels;

namespace ViewModelLayer.PublicViewModels
{
    public class ProfileViewModel
    {
        public PrivacyViewModels Privacy { get; set; }
        public List<PostViewModel> Post { get; set; }
        public PersonalInfoViewModels Personal { get; set; }
        public List<GalleryViewModel> Galleries { get; set; }
        public List<FriendViewModels> Friends { get; set; }
    }
}
