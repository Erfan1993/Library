﻿using System;
using System.Collections.Generic;
using System.Text;
using ViewModelLayer.PostsViewModels;
using ViewModelLayer.UserViewModels;

namespace ViewModelLayer.PublicViewModels
{
    public class UserIndexViewModels
    {
        public List<FriendViewModels> FriendsList { get; set; }
        public List<PostViewModel> PostsList { get; set; }

    }
}
