﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModelLayer.GalleryViewModels
{
    public class GalleryViewModel
    {
        public int GalleryID { get; set; }
        public string UserID { get; set; }
        public string ImageUrl { get; set; }
        public int Like { get; set; }
        public int DisLike { get; set; }
    }
}
