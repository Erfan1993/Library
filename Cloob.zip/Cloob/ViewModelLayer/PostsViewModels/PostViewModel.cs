﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModelLayer.PostsViewModels
{
    public class PostViewModel
    {
        public int PostID { get; set; }
        public string Title { get; set; }
        public string ImageUrl { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string UserImage { get; set; }
        public int like { get; set; }
        public int DisLike { get; set; }
        public int Comments { get; set; }
    }
}
