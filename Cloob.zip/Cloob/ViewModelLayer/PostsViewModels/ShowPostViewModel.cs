﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModelLayer.PostsViewModels
{
   public class ShowPostViewModel
    {
        public List<CommentsViewModel> Comments { get; set; }
        public PostViewModel Post { get; set; }
    }
}
