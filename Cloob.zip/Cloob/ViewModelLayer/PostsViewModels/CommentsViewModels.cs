﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModelLayer.PostsViewModels
{
   public class CommentsViewModel
    {
        public int CommentID { get; set; }
        public string CommentTitle { get; set; }
        public string UserID { get; set; }
        public string  UserName { get; set; }
        public int PostID { get; set; }
    }
}
