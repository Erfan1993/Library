﻿using HISNet;
using Microsoft.Owin.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace H.I.S
{
    public class ChatRunner
    {
        IDisposable SignalrServer = null;
        HisNetwork hisNet = new HisNetwork();
        ClientMethods client = new ClientMethods();
        ChatModel Chat = new ChatModel();
        public bool isServer { get; set; } = false;

        public ChatRunner()
        {

        }

        public async void Start()
        {

            var asd = MyTools.FUserNamePersian;
            try
            {

                if (hisNet.InternetChecker() == false)
                {
                    MessageBox.Show("برای عملکرد بهتر، بهتر است اینترنت خود را وصل کنید");
                }
                string serverIP = hisNet.CheckServerIPAddress();
                string UserUrl = "Http://";

                int port = hisNet.PortChecker();
                if (port == 0)
                {
                    MessageBox.Show("هیچ شماره پورتی انتخاب نشده است ");
                    return;
                }
                if (port == -1)
                {
                    MessageBox.Show("شماره پورت را چک کنید ، پورت انتخاب شده در حال استفاده می باشد و ممکن است در عملکرد برنامه تداخل ایجاد کند");
                }
                //Server
                if (hisNet.IMServer() == true)
                {
                    isServer = true;
                    UserUrl += serverIP + ":" + port.ToString();
                    UserUrl = UserUrl.Trim();
                    UserUrl = UserUrl.Replace(" ", "");

                    SignalrServer = WebApp.Start<Startup>(UserUrl);
                    MessageBox.Show($"سرور چت توسط شما{UserUrl} ساخته شد.");
                }
                //Client
                if (hisNet.PingOnServer(hisNet.CheckServerIPAddress()) == true)
                {
                    UserUrl = "";
                    UserUrl = "Http://";
                    UserUrl += serverIP + ":" + port.ToString() + "/Signalr";
                    UserUrl = UserUrl.Trim();
                    UserUrl = UserUrl.Replace(" ", "");
                    ChatUser user1 = new ChatUser();
                    user1.SystemID = MyTools.FID_User.ToString();
                    user1.UserName = MyTools.FUserNamePersian.ToString();
                    Chat.Sender = user1;

                    Chat.ServerUrl = UserUrl;

                    await Connector(Chat);
                }
                else
                {
                    MessageBox.Show("آدرس IP  سرور را بررسی کنید");
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message.ToString());
            }
        }

        public async Task<bool> Connector(ChatModel chat)
        {
            try
            {
                string str = await client.ConnectToServer(Chat);
                Task.Delay(100);
                if (str == "Connected")
                {
                    MessageBox.Show("شمار به سرور چت وصل شدید");
                    return true;
                }
                MessageBox.Show("در اتصال به سرور مشکلی رخ داده است");

            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message.ToString());
                MessageBox.Show("هنوز سروری برای چت ساخته نشده است یا دسترسی به سرور ندارید");
            }
            return false;
        }

        public void Disconnect(string sysid)
        {
            client.DisConnected(sysid);
        }

        public void StopServer()
        {
            client.ServerStop();
        }


    }
}
