﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HISNet
{
    public static class CallChatMethods
    {
        public const string Send = "Send";
        public const string LeftGroup = "LeftGroup";
        public const string JoinGroup = "JoinGroup";
        public const string StopServer = "StopServer";
        public const string SetUserName = "SetUserName";
        public const string GetAllUsers = "GetAllUsers";
        public const string DisConnected = "DisConnected";
        public const string PrivateMessage = "PrivateMessage";
        public const string SendToAllMessage = "SendToAllMessage";

        //public const string SetUserName = "Send";
    }


    public enum MessageModeEnum : int
    {
        ToAll = 1,
        Private = 2,
    }

}
