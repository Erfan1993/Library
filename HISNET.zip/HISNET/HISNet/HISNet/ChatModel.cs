﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HISNet
{
    public class ChatModel
    {
        public ChatUser Sender { get; set; }
        public string Message { get; set; }
        public ChatUser Reciver { get; set; }
        public string ServerUrl { get; set; }
        public GroupModel Group { get; set; }
        public MessageModeEnum MessageMode { get; set; }
    }
}
