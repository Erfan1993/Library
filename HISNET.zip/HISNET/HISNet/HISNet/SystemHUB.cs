﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using Microsoft.AspNet.SignalR;
using System.ComponentModel;
using System.Windows.Forms;

namespace HISNet
{
    public delegate void ClientConnectionEventHandler(string clientId);
    public delegate void ClientNameChangedEventHandler(string clientId, string newName);
    public delegate void ClientGroupEventHandler(string clientId, string groupName);
    public delegate void MessageReceivedEventHandler(string senderClientId, string message);



    public class SystemHUB : Hub
    {
        public static ConcurrentDictionary<string, string> _users = new ConcurrentDictionary<string, string>();

        public static List<ChatUser> users { get; set; } = new List<ChatUser>();

        public static event ClientConnectionEventHandler ClientConnected;

        public static event ClientConnectionEventHandler ClientDisconnected;

        public static event ClientNameChangedEventHandler ClientNameChanged;

        public static event ClientGroupEventHandler ClientJoinedToGroup;

        public static event ClientGroupEventHandler ClientLeftGroup;

        public static event MessageReceivedEventHandler MessageReceived;

        static ChatEvents events;

        public SystemHUB()
        {
            if (events == null)
            {
                events = new ChatEvents();
            }
        }

        public static void ClearState()
        {
            users.Clear();
        }

        public override Task OnReconnected()
        {
            //var context = GlobalHost.ConnectionManager.GetHubContext<SystemHUB>();
            return base.OnReconnected();
        }

        public async Task<List<ChatUser>> GetAllUsers()
        {
            var result = users.ToList();
            return result;
        }

        public override Task OnConnected()
        {
            users.Add(new ChatUser { ID = Context.ConnectionId, UserName = Context.ConnectionId });
            string useid = Context.ConnectionId;
            ClientConnected?.Invoke(useid);


            return base.OnConnected();
        }

        public override Task OnDisconnected(bool stopCalled)
        {
            var hubContext = GlobalHost.ConnectionManager.GetHubContext<SystemHUB>();

            string res = users.FirstOrDefault(a => a.ID == Context.ConnectionId).UserName;

            hubContext.Clients.All.SingleNotify($"کاربر {res} آفلاین شد");

            users.Remove(users.Where(a => a.ID == Context.ConnectionId).FirstOrDefault());
            
            ClientDisconnected?.Invoke(Context.ConnectionId);

            return null;
            //return base.OnConnected();
        }

        //public async Task

        public void StartServer(string ServerAddress)
        {
            //if (ServerAddress == "")
            //{
            //    //MessageBox.Show("enter a Address to Connect");
            //    return "You Should set a Server address";
            //}

            //_signalR = WebApp.Start<Startup>(ServerAddress);

            //_signalR = WebApp.Start<Startup>(new StartOptions
            //{
            //    Port = 9956,
            //    ServerFactory = "Microsoft.Owin.Host.HttpListener"
            //});

            //try
            //{
            //    //Start SignalR server with the give URL address
            //    //Final server address will be "URL/signalr"
            //    //Startup.Configuration is called automatically


            //    using (Microsoft.Owin.Hosting.WebApp.Start<Startup>(ServerAddress))
            //    {
            //        Console.Beep();
            //    }


            //    //_signalR = WebApp.Start<Startup>(ServerAddress);
            //    return $"Server started at:{ServerAddress}";
            //}
            //catch (Exception ex)
            //{
            //    return ex.Message.ToString();
            //}
        }

        public void StopServer()
        {
            SystemHUB.users.Clear();

            SystemHUB.ClearState();

            //if (_signalR != null)
            //{
            //    _signalR.Dispose();
            //    _signalR = null;
            //}
        }

        public string PrivateMessage(ChatModel chat)
        {
            try
            {
                chat.MessageMode = MessageModeEnum.Private;
                var hubContext = GlobalHost.ConnectionManager.GetHubContext<SystemHUB>();

                hubContext.Clients.Client(chat.Reciver.ID).AddMessageNotify(chat);

                return "Message Recived";
            }
            catch (Exception err)
            {
                return err.Message.ToString();
            }
        }

        public string SendGroupMessage(ChatModel chat)
        {
            try
            {
                var hubContext = GlobalHost.ConnectionManager.GetHubContext<SystemHUB>();

                hubContext.Clients.Group(chat.Group.GroupName).addMessage(chat);

                return "Message Recived";
            }
            catch (Exception err)
            {
                return err.Message.ToString();
            }
        }

        public string SendToAllMessage(ChatModel chat)
        {
            try
            {
                chat.MessageMode = MessageModeEnum.ToAll;
                var hubContext = GlobalHost.ConnectionManager.GetHubContext<SystemHUB>();

                hubContext.Clients.All.AddMessageNotify(chat);

                return "Message Recived";
            }
            catch (Exception err)
            {
                return err.Message.ToString();
            }
        }

        public void SetUserName(string Name, string SystemID)
        {
            var result = users.Where(a => a.ID == Context.ConnectionId).FirstOrDefault();
            var temp = result;
            users.Remove(result);
            temp.UserName = Name;
            temp.SystemID = SystemID;
            users.Add(temp);

            var hubContext = GlobalHost.ConnectionManager.GetHubContext<SystemHUB>();

            hubContext.Clients.All.SingleNotify(Name);

            //ClientNameChanged?.Invoke(Context.ConnectionId, Name);
        }

        public async Task JoinGroup(string groupName)
        {
            await Groups.Add(Context.ConnectionId, groupName);

            ClientJoinedToGroup?.Invoke(Context.ConnectionId, groupName);
        }

        public async Task LeaveGroup(string groupName)
        {
            await Groups.Remove(Context.ConnectionId, groupName);

            ClientLeftGroup?.Invoke(Context.ConnectionId, groupName);
        }

        public void Send(string msg)
        {
            Clients.All.addMessage(_users[Context.ConnectionId], msg);

            MessageReceived?.Invoke(Context.ConnectionId, msg);
        }
    }
}
