﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HISNet
{
  public  class GroupModel
    {
        public int ID { get; set; }
        public string GroupName { get; set; }
    }
}
