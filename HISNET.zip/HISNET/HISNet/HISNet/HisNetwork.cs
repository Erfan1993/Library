﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;


namespace HISNet
{
    public class HisNetwork
    {

        private static string server1 = "192.168.1.1";

        private static string server2 = "192.168.2.1";

        public bool InternetChecker()
        {
            string Google = "www.google.com.mx";
            if (PingOnServer(Google))
            {
                return true;
            }
            return false;
        }

        public string GetIPAdress()
        {
            string hostName = Dns.GetHostName();
            Console.WriteLine(hostName);
            string myIP = Dns.GetHostByName(hostName).AddressList[0].ToString();
            return myIP;
        }

        public IPAddress GetingGetWayIPAddress()
        {
            return NetworkInterface
                .GetAllNetworkInterfaces()
                .Where(n => n.OperationalStatus == OperationalStatus.Up)
                .Where(n => n.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                .SelectMany(n => n.GetIPProperties()?.GatewayAddresses)
                .Select(g => g?.Address)
                .Where(a => a != null)
                .FirstOrDefault();
        }

        public string CheckServerIPAddress()
        {
            string fileName = @"C:\HISSettings\ServerIp.txt";
            string[] lines = File.ReadAllLines(fileName);
            if (lines.Length > 0)
            {
                return lines[0].Trim();
            }
            else
            {
                if (PingOnServer(server1))
                {
                    return server1;
                }
                if (PingOnServer(server2))
                {
                    return server2;
                }
            }
            return null;
        }

        public int PortChecker(int port = 0)
        {
            if (port == 0)
            {
                string fileName = @"C:\HISSettings\ServerIp.txt";
                string[] lines = File.ReadAllLines(fileName);
                if (lines.Length > 0)
                {
                    port = Convert.ToInt32(lines[1]);
                }
                if (port == 0)
                {
                    return 0;
                }
                return port;
            }

            bool isAvailable = true;
            IPGlobalProperties ipGlobalProperties = IPGlobalProperties.GetIPGlobalProperties();
            TcpConnectionInformation[] tcpConnInfoArray = ipGlobalProperties.GetActiveTcpConnections();

            foreach (TcpConnectionInformation tcpi in tcpConnInfoArray)
            {
                if (tcpi.LocalEndPoint.Port == port)
                {
                    isAvailable = false;
                    break;
                }
            }

            if (isAvailable == true)
            {
                return port;
            }
            if (isAvailable == false)
            {
                return port = -1;
            }
            return port;
        }

        public bool PingOnServer(string ServerIP)
        {
            int counter = 0;
            for (int i = 1; i <= 4; i++)
            {
                Ping p1 = new Ping();
                PingReply PR = p1.Send(ServerIP);
                if (PR.Status.ToString() == "Success")
                {
                    counter++;
                }
            }
            if (counter == 4)
            {
                return true;
            }
            return false;
        }

        public bool IMServer()
        {
            var result = GetIPAdress();
            if (result == server1 || result == server2 || result == CheckServerIPAddress())
            {
                return true;
            }
            return false;

        }

    }
}
