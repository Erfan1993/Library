﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.AspNet.SignalR.Client;

namespace HISNet
{
    public class ClientMethods
    {
        HubConnection _signalRConnection;

        static IHubProxy _hubProxy;

        public ClientMethods()
        {

        }
        private void HubConnection_StateChanged(StateChange obj)
        {
            if (obj.NewState == Microsoft.AspNet.SignalR.Client.ConnectionState.Connected)
                writeToLog("Connected");
            else if (obj.NewState == Microsoft.AspNet.SignalR.Client.ConnectionState.Disconnected)
                writeToLog("Disconnected");
        }
        public string Server()
        {
            if (_signalRConnection != null)
            {
                _signalRConnection.Stop();
                _signalRConnection.Dispose();
                _signalRConnection = null;
                return "Client is Dissconnet";
            }
            return "client was Disconneted Before";
        }

        public delegate void MessageNotify(ChatModel chat);

        public static event MessageNotify Message;

        public async Task<string> ConnectToServer(ChatModel chat)
        {

            _signalRConnection = new HubConnection(chat.ServerUrl);
            _signalRConnection.StateChanged += HubConnection_StateChanged;



            _hubProxy = _signalRConnection.CreateHubProxy("SystemHUB");

            _hubProxy.On<string>("SingleNotify", (message) => { MessageBox.Show($"کاربر {message} متصل شد"); });

            _hubProxy.On<ChatModel>("AddMessageNotify", (inchat) => { Message?.Invoke(inchat);  });

            _hubProxy.On<string, string>("AddMessage", (name, message) => { Message?.Invoke(chat); });

            try
            {

                await _signalRConnection.Start();

                await _hubProxy.Invoke(CallChatMethods.SetUserName, chat.Sender.UserName, chat.Sender.SystemID);
                //await _hubProxy.Invoke(CallChatMethods.SetUserName, chat.Sender.UserName, chat.Sender.SystemID);
                Task.Delay(500);

                return "Connected";
            }
            catch (Exception ex)
            {
                return writeToLog($"Error:{ex.Message}");
            }
        }
        public async Task<List<ChatUser>> GetAllUsers()
        {
            List<ChatUser> result = new List<ChatUser>();
            return await _hubProxy.Invoke<List<ChatUser>>("GetAllUsers");
        }
        public string writeToLog(string str)
        {
            return str;
        }
        public void Send(ChatModel chat)
        {
            _hubProxy.Invoke("Send", chat);
        }
        public void JoinGroup(ChatModel chat)
        {
            _hubProxy.Invoke(CallChatMethods.JoinGroup, chat);
        }
        public void LeftGroup(ChatModel chat)
        {
            _hubProxy.Invoke(CallChatMethods.LeftGroup, chat);
        }
        public void SetUserName(ChatModel chat)
        {
            _hubProxy.Invoke(CallChatMethods.SetUserName, chat);
        }
        public void PrivateMessage(ChatModel chat)
        {
            _hubProxy.Invoke(CallChatMethods.PrivateMessage, chat);
        }
        public void SendToAllMessage(ChatModel chat)
        {
            _hubProxy.Invoke(CallChatMethods.SendToAllMessage, chat);
        }
        public void DisConnected(string systemID)
        {
            _hubProxy.Invoke(CallChatMethods.DisConnected, systemID);

            if (_signalRConnection != null)
            {
                _signalRConnection.Stop();
                _signalRConnection.Dispose();
                _signalRConnection = null;
                MessageBox.Show("Client is Dissconnet");
            }
            MessageBox.Show("client was Disconneted Before");

            _signalRConnection.Stop();
        }

        public void ServerStop()
        {
            _hubProxy.Invoke(CallChatMethods.StopServer);
        }
    }
}
