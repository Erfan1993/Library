﻿using Owin;
using System;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using System.Threading.Tasks;

[assembly: OwinStartup(typeof(HISNet.Startup))]

namespace HISNet
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.UseCors(CorsOptions.AllowAll);
            ////Find and reigster SignalR hubs
            app.MapSignalR();
        }
    }
}
