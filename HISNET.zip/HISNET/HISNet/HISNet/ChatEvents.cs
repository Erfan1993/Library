﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HISNet
{
    public class ChatEvents
    {

        ////private IDisposable _signalR;
        //private BindingList<ClientSettings> _clients = new BindingList<ClientSettings>();
        //private BindingList<string> _groups = new BindingList<string>();

        public ChatEvents()
        {
            SystemHUB.ClientConnected += SystemHUB_ClientConnected;
            SystemHUB.ClientDisconnected += SimpleHub_ClientDisconnected;
            SystemHUB.ClientNameChanged += SystemHUB_ClientNameChanged;
            SystemHUB.ClientJoinedToGroup += SystemHUB_ClientJoinedToGroup;
            SystemHUB.ClientLeftGroup += SystemHUB_ClientLeftGroup;
            SystemHUB.MessageReceived += SystemHUB_MessageReceived;
        }

        private void SystemHUB_MessageReceived(string senderClientId, string message)
        {
            //string clientName = _clients.FirstOrDefault(x => x.Id == senderClientId)?.Name;
            MessageBox.Show("Warning");
            //writeToLog($"{clientName}:{message}", _clients);
        }

        private void SystemHUB_ClientLeftGroup(string clientId, string groupName)
        {
            throw new NotImplementedException();
        }

        private void SystemHUB_ClientJoinedToGroup(string clientId, string groupName)
        {
            //var group = _groups.FirstOrDefault(x => x == groupName);
            //if (group == null)
            //    _groups.Add(groupName);
        }

        private void SystemHUB_ClientNameChanged(string clientId, string newName)
        {
            var client = SystemHUB.users.FirstOrDefault(x => x.ID == clientId);
            if (client != null)
                client.UserName = newName;
        }

        private void SystemHUB_ClientConnected(string clientId)
        {
            
        }

        private void SimpleHub_ClientDisconnected(string clientId)
        {
            var result = SystemHUB.users.FirstOrDefault(a => a.ID == clientId);
            //MessageBox.Show(result.UserName + " " + result.ID + "کاربر از سرور چت خارج شد");
        }

        public void writeToLog(string str, BindingList<ClientSettings> lient)
        {

        }

    }
}
