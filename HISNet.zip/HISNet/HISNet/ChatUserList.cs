﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HISNet
{
    public static class ChatUserList
    {
        public static List<ChatUser> _Users { get; set; }

        public static void Clear()
        {
            _Users = null;
        }
    }
}
