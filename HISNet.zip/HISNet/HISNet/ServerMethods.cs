﻿using Microsoft.AspNet.SignalR;
using Microsoft.Owin.Hosting;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 
namespace HISNet
{
    public class ServerMethods
    {
        private IDisposable _signalR;
        private BindingList<ClientSettings> _clients;
        private BindingList<string> _groups;

        public ServerMethods()
        {
            _clients = new BindingList<ClientSettings>();
            _groups = new BindingList<string>();
        }

        public ServerMethods(BindingList<ClientSettings> bindlist, BindingList<string> groupname)
        {
            _clients = bindlist;
            _groups = groupname;
        }

        public string StartServer(string ServerAddress)
        {
            if (ServerAddress == "")
            {
                //MessageBox.Show("enter a Address to Connect");
                return "You Should set a Server address";
            }
            _signalR = WebApp.Start<Startup>(new StartOptions
            {
                Port = 9956,
                ServerFactory = "Microsoft.Owin.Host.HttpListener"
            });

            try
            {
                //Start SignalR server with the give URL address
                //Final server address will be "URL/signalr"
                //Startup.Configuration is called automatically


                using (Microsoft.Owin.Hosting.WebApp.Start< Startup>(ServerAddress))
                {
                    Console.Beep();
                }


                //_signalR = WebApp.Start<Startup>(ServerAddress);
                return $"Server started at:{ServerAddress}";
            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
            }
        }

        public void StopServer()
        {
            _clients.Clear();
            _groups.Clear();

            SystemHUB.ClearState();

            if (_signalR != null)
            {
                _signalR.Dispose();
                _signalR = null;
            }
        }

        public string SendPrivateMessage(ChatModel chat)
        {
            try
            {
                var hubContext = GlobalHost.ConnectionManager.GetHubContext<SystemHUB>();

                hubContext.Clients.Client(chat.ReciverId).addMessage("SERVER2", chat.Message);

                return "Message Recived";
            }
            catch (Exception err)
            {
                return err.Message.ToString();
            }
        }

        public string SendGroupMessage(ChatModel chat)
        {
            try
            {
                var hubContext = GlobalHost.ConnectionManager.GetHubContext<SystemHUB>();

                hubContext.Clients.Group(chat.GroupName).addMessage(chat.SenderUserName, chat.Message);

                return "Message Recived";
            }
            catch (Exception err)
            {
                return err.Message.ToString();
            }
        }

        public string SendToAllMessage(ChatModel chat)
        {
            try
            {
                var hubContext = GlobalHost.ConnectionManager.GetHubContext<SystemHUB>();

                hubContext.Clients.All.addMessage(chat.SenderUserName, chat.Message);

                return "Message Recived";
            }
            catch (Exception err)
            {
                return err.Message.ToString();
            }
        }


    }
}
