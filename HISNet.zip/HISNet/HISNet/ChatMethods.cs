﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HISNet
{
    public static class CallChatMethods
    {
        public const string Send = "Send";
        public const string JoinGroup = "JoinGroup";
        public const string LeftGroup = "LeftGroup";
        public const string SetUserName = "SetUserName";
        //public const string SetUserName = "Send";




    }
}
