﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR.Client;

namespace HISNet
{
    public class ClientMethods
    {
        HubConnection _signalRConnection;
        //Proxy object for a hub hosted on the SignalR server
        IHubProxy _hubProxy;

        public ClientMethods()
        {

        }


        public string ClientStop()
        {
            if (_signalRConnection != null)
            {
                _signalRConnection.Stop();
                _signalRConnection.Dispose();
                _signalRConnection = null;
                return "Client is Dissconnet";
            }
            return "client was Disconneted Before";
        }

        public async Task<string> ConnectToServer(ChatModel chat)
        {
            _signalRConnection = new HubConnection(chat.ServerUrl);
            _signalRConnection.StateChanged += HubConnection_StateChanged;

            //Get a proxy object that will be used to interact with the specific hub on the server
            //Ther may be many hubs hosted on the server, so provide the type name for the hub
            _hubProxy = _signalRConnection.CreateHubProxy("SystemHUB");

            //Reigster to the "AddMessage" callback method of the hub
            //This method is invoked by the hub
            _hubProxy.On<string, string>("AddMessage", (name, message) => writeToLog($"{name}:{message}"));


            try
            {
                //Connect to the server
                await _signalRConnection.Start();

                //Send user name for this client, so we won't need to send it with every message
                await _hubProxy.Invoke("SetUserName", chat.SenderUserName);
                return "You connected to server";
            }
            catch (Exception ex)
            {
                writeToLog($"Error:{ex.Message}");
                return "You are not Connected to server";
            }
        }


        private void HubConnection_StateChanged(StateChange obj)
        {
            if (obj.NewState == Microsoft.AspNet.SignalR.Client.ConnectionState.Connected)
                writeToLog("Connected");
            else if (obj.NewState == Microsoft.AspNet.SignalR.Client.ConnectionState.Disconnected)
                writeToLog("Disconnected");
        }



        public void writeToLog(string str)
        {
        }


        public void Send(ChatModel chat)
        {
            _hubProxy.Invoke(ChatMethods.Send, chat);
        }
        public void JoinGroup(ChatModel chat)
        {
            _hubProxy.Invoke(ChatMethods.JoinGroup, chat);
        }
        public void LeftGroup(ChatModel chat)
        {
            _hubProxy.Invoke(ChatMethods.LeftGroup, chat);
        }

        public void SetUserName(ChatModel chat)
        {
            _hubProxy.Invoke(ChatMethods.SetUserName, chat);
        }

    }
}
