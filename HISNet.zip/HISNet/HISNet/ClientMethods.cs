﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNet.SignalR.Client;

namespace HISNet
{
    public class ClientMethods
    {
        HubConnection _signalRConnection;
        //Proxy object for a hub hosted on the SignalR server
        IHubProxy _hubProxy;

        public ClientMethods()
        {

        }

        private void HubConnection_StateChanged(StateChange obj)
        {
            if (obj.NewState == Microsoft.AspNet.SignalR.Client.ConnectionState.Connected)
                writeToLog("Connected");
            else if (obj.NewState == Microsoft.AspNet.SignalR.Client.ConnectionState.Disconnected)
                writeToLog("Disconnected");
        }

        public string ClientStop()
        {
            if (_signalRConnection != null)
            {
                _signalRConnection.Stop();
                _signalRConnection.Dispose();
                _signalRConnection = null;
                return "Client is Dissconnet";
            }
            return "client was Disconneted Before";
        }


        public void Test()
        {
            _hubProxy.Invoke("GetAllUsers","Name");
        }

        public async Task<string> ConnectToServer(ChatModel chat)
        {
            _signalRConnection = new HubConnection(chat.ServerUrl);
            _signalRConnection.StateChanged += HubConnection_StateChanged;

            _hubProxy = _signalRConnection.CreateHubProxy("SystemHUB");


            _hubProxy.On<string, string>("AddMessage", (name, message) => writeToLog($"{name}:{message}"));

            try
            {
                //Connect to the server
                await _signalRConnection.Start();

                await _hubProxy.Invoke(CallChatMethods.SetUserName, chat.SenderUserName);
                await _hubProxy.Invoke("aaaa");



                //await _hubProxy.Invoke(CallChatMethods.LeftGroup, chat.SenderUserName);

                //await _hubProxy.Invoke("AddUserTolist", "UserName=eeee1", "ID=10");

                


                return "Connected";
            }
            catch (Exception ex)
            {
                return writeToLog($"Error:{ex.Message}");
            }
        }

        public string writeToLog(string str)
        {
            return str;
        }

        #region Client Mthods
        public void Send(ChatModel chat)
        {
            _hubProxy.Invoke("Send", chat);
        }
        public void JoinGroup(ChatModel chat)
        {
            _hubProxy.Invoke(CallChatMethods.JoinGroup, chat);
        }
        public void LeftGroup(ChatModel chat)
        {
            _hubProxy.Invoke(CallChatMethods.LeftGroup, chat);
        }
        public void SetUserName(ChatModel chat)
        {
            _hubProxy.Invoke(CallChatMethods.SetUserName, chat);
        }
        #endregion 
    }
}
