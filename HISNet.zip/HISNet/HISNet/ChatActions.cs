﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HISNet
{
    public class ChatActions
    {

        private IDisposable _signalR;
        private BindingList<ClientSettings> _clients = new BindingList<ClientSettings>();
        private BindingList<string> _groups = new BindingList<string>();


        //MainForm form = new MainForm();



        public ChatActions()
        {
            SystemHUB.ClientConnected += SystemHUB_ClientConnected;
            SystemHUB.ClientDisconnected += SimpleHub_ClientDisconnected;
            SystemHUB.ClientNameChanged += SystemHUB_ClientNameChanged;
            SystemHUB.ClientJoinedToGroup += SystemHUB_ClientJoinedToGroup;
            SystemHUB.ClientLeftGroup += SystemHUB_ClientLeftGroup;
            SystemHUB.MessageReceived += SystemHUB_MessageReceived;

        }



        private void SystemHUB_MessageReceived(string senderClientId, string message)
        {
            string clientName = _clients.FirstOrDefault(x => x.Id == senderClientId)?.Name;
            writeToLog($"{clientName}:{message}", _clients);
        }

        private void SystemHUB_ClientLeftGroup(string clientId, string groupName)
        {
            throw new NotImplementedException();
        }

        private void SystemHUB_ClientJoinedToGroup(string clientId, string groupName)
        {
            var group = _groups.FirstOrDefault(x => x == groupName);
            if (group == null)
                _groups.Add(groupName);
        }

        private void SystemHUB_ClientNameChanged(string clientId, string newName)
        {
            var client = _clients.FirstOrDefault(x => x.Id == clientId);
            if (client != null)
                client.Name = newName;
        }

        public void mymehtod()
        {
            var hubContext = GlobalHost.ConnectionManager.GetHubContext<SystemHUB>();
            hubContext.Clients.Client("sd").addMessage("SERVER2", "asdas");
        }


        private void SystemHUB_ClientConnected(string clientId)
        {
            _clients.Add(new ClientSettings() { Id = clientId, Name = clientId });

            writeToLog($"Client {clientId.ToString()} is Connected", _clients);
        }

        private void SimpleHub_ClientDisconnected(string clientId)
        {
            var result = _clients.FirstOrDefault(a => a.Id == clientId);

            _clients.Remove(result);

            writeToLog($"Client is Offnow {result.Name.ToString()}", _clients);
        }

        public void writeToLog(string str, BindingList<ClientSettings> lient)
        {

        }
    }
}
