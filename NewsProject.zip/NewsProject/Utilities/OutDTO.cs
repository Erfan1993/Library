﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities
{
    public class OutDTO<T>
    {
        public List<T> DTO { get; set; }
        public int Status { get; set; }
        public string ErrorMessage { get; set; }
    }
}
