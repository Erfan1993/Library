﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities
{
    public class CommentsDTO
    {
        public int ID { get; set; }
        public int NewsID { get; set; }
        public string CommentText { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public DateTime CreatedTime { get; set; }

        public NewsDTO News { get; set; }
    }
}
