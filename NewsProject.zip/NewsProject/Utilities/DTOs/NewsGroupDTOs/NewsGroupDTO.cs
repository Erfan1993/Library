﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utilities
{
    public class NewsGroupDTO
    {
        public int ID { get; set; }
        public string GroupTitle { get; set; }
        public IEnumerable<NewsDTO> NewsDTOs { get; set; }
    }
}
