﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DataLayer;
using Microsoft.AspNetCore.Mvc;
using Utilities;

namespace NewsProject.Controllers
{
    [ApiController]
    [Route("api/[Controller]/[Action]")]
    public class NewsController : Controller
    {
        private INewsGroupService _newsGroupService;
        private readonly IMapper _mapper;
        private INewsService _newsService;
        private ICommentService _commentService;

        public NewsController(INewsGroupService newsgroupService, IMapper mapper, INewsService news, ICommentService comment)
        {
            _commentService = comment;
            _mapper = mapper;
            _newsService = news;
            _newsGroupService = newsgroupService;
        }
        [HttpGet]
        public IActionResult ShowNews(int id)
        {
            if (id > 0)
            {
                var res = _newsService.FindNewsByID(id);
                var result = _mapper.Map<NewsDTO>(res);
                return Ok(result);
            }
            else
            {
                return BadRequest("");
            }
        }
        [HttpGet]
        public IActionResult GetAllNewsInGroupNews(int id)
        {
            if (id > 0)
            {
                var res = _newsService.GetNewsByNewsGroupID(id);
                var result = _mapper.Map<IList<NewsDTO>>(res);
                return Ok(result);
            }
            else
            {
                return BadRequest();
            }
        }
        [HttpGet]
        public IActionResult ShowNewsComment(int id)
        {
            if (id > 0)
            {
                var res = _commentService.GetCummentsByNewsID(id);
                var result = _mapper.Map<List<Comment>>(res);
                return Ok(result);
            }
            else
            {
                return BadRequest();
            }
        }
        [HttpGet]
        public IActionResult ShowReportedNews()
        {
            var resource = _newsService.GetReportedNews();
            var result = _mapper.Map<IList<NewsDTO>>(resource);
            return Ok(result);
        }
        [HttpPost]
        public IActionResult AddNews(NewsDTO inModel)
        {
            if (ModelState.IsValid)
            {
                var res = _mapper.Map<News>(inModel);
                _newsService.CreateNews(res);
                _newsService.Save();
                return Json(new OutDTO<NewsDTO>() { ErrorMessage = "News added Completely", Status = 100 });
            }
            else
            {
                return Json(new OutDTO<NewsDTO>() { Status = 100, ErrorMessage = "this is a test" });
            }
        }
        [HttpPut]
        public IActionResult EditNews([FromBody] NewsDTO News, int id)
        {
            if (ModelState.IsValid && id > 0)
            {
                var res = _mapper.Map<News>(News);
                _newsService.UpdateNews(res);
                _newsService.Save();
                return Ok(new OutDTO<NewsDTO>() { Status = 200, ErrorMessage = "News is Updated" });
            }
            else
            {
                return BadRequest(new OutDTO<NewsDTO>() { Status = 200, ErrorMessage = "model is invalid" });
            }
        }
        [HttpDelete]
        public IActionResult DeleteNews(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new OutDTO<NewsDTO>() { Status = 200, ErrorMessage = "id is Invalid" });
            }
            else
            {
                _newsService.DeleteNews(id);
                _newsService.Save();
                return Ok(new OutDTO<NewsDTO>() { Status = 200, ErrorMessage = "News is Deleted" });
            }
        }
        [HttpPost]
        public IActionResult ReportNews(int id)
        {
            if (id <= 0)
            {
                return BadRequest(new OutDTO<NewsDTO>() { Status = 200, ErrorMessage = "news id is invalid" });
            }
            else
            {
                _newsService.ReportNews(id);
                _newsService.Save();
                return Ok(new OutDTO<NewsDTO>() { Status = 200, ErrorMessage = "news is reported" });
            }
        }
        [HttpPost]
        public IActionResult LeftComment([FromBody] CommentsDTO comments ,int id)
        {
            if (ModelState.IsValid)
            {
                var res = _mapper.Map<Comment>(comments);
                _newsService.AddComment(res);
                _newsService.Save();
                return Ok(new OutDTO<NewsDTO>() { Status = 200, ErrorMessage = "Coment is added" });
            }
            else
            {
                return BadRequest("Model is invalid or id is empty");
            }
        }
    }
}
