﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DataLayer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Utilities;

namespace NewsProject.Controllers
{
    [ApiController]
    [Route("api/[Controller]/[Action]")]
    //[Route("[NewsGroup]/[GetNewsGroup]")]
    public class NewsGroupController : Controller
    {
        private INewsGroupService _newsGroup;
        private readonly IMapper _mapper;

        public NewsGroupController(INewsGroupService newsGroup, IMapper mapper)
        {
            _newsGroup = newsGroup;
            _mapper = mapper;
        }
        [HttpGet]
        public IActionResult GetNewsGroup()
        {
            var result = _newsGroup.GetAllNewsGroups();
            try
            {
                var model = _mapper.Map<List<NewsGroupDTO>>(result);

                var r = new OutDTO<NewsGroupDTO>();

                r.DTO = model;
                r.Status = 100;
                r.ErrorMessage = "Test error";
                return Json(r);
            }
            catch (Exception e)
            {
                string s = e.ToString();
            }
            return Json(result);
        }

        [HttpPost]
        public IActionResult CreateNewsGroup(NewsGroupDTO inDTO)
        {
            if (ModelState.IsValid)
            {
                var model = _mapper.Map<NewsGroup>(inDTO);
                _newsGroup.AddNewsGroup(model);
                _newsGroup.save();
                return Json(new OutDTO<NewsGroupDTO>() { Status = 200, ErrorMessage = "NewsGroup Is Saved Correctly" });
            }
            else
            {
                return Json(new OutDTO<NewsGroupDTO>() { Status = 500, ErrorMessage = "NewsGroup did not saved" });
            }
        }
        [HttpDelete]
        public IActionResult DeleteNewsGroup(int id)
        {
            if (id == 0)
            {
                return Json(new OutDTO<NewsGroupDTO>() { Status = 500, ErrorMessage = "Error Message" });
            }
            else
            {
                bool res = _newsGroup.DeleteNewsGroup(id);
                if (res == false)
                {
                    return Json(new OutDTO<NewsGroupDTO>() { Status = 100, ErrorMessage = "Error Message" });
                }
                else
                {
                    _newsGroup.save();
                    return Json(new OutDTO<NewsGroupDTO>() { Status = 100, ErrorMessage = "Delete Succeded" });
                }
            }
        }
        [HttpPut]
        public IActionResult UpdateNewsGroup(int id, NewsGroupDTO InModel)
        {
            if (ModelState.IsValid)
            {
                if (id == InModel.ID)
                {
                    var model = _mapper.Map<NewsGroup>(InModel);
                    _newsGroup.UpdateNewsGroup(model);
                    _newsGroup.save();
                    return Json(new OutDTO<NewsGroupDTO>() { Status = 100, ErrorMessage = "Update Message" });
                }
                else
                {
                    return Json(new OutDTO<NewsGroupDTO>() { Status = 100, ErrorMessage = "this id has been changed" });
                }
            }
            else
            {
                return Json(new OutDTO<NewsGroupDTO>() { Status = 100, ErrorMessage = "input model is not valid" });
            }
        }
    }
}
