﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DataLayer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Utilities;

namespace NewsProject.Controllers
{
    [ApiController]
    [Route("api/[Controller]/[Action]")]
    public class HomePageController : Controller
    {
        private INewsGroupService _newsGroupService;
        private INewsService _newsService;
        private readonly IMapper _mapper;
        public HomePageController(INewsService newsService, INewsGroupService newsGroup, IMapper mapper)
        {
            _newsService = newsService;
            _mapper = mapper;
            _newsGroupService = newsGroup;
        }
        [HttpGet]
        public IActionResult Index()
        {
            var resource = _newsGroupService.GetAllNewsGroups();
            var result = _mapper.Map<List<NewsGroupDTO>>(resource);
            return Ok(result);
        }
        [HttpPost]
        public IActionResult SearchNews([FromBody] string NewsTitle)
        {
            var res = _newsService.SearchByTitle(NewsTitle);
            List<NewsDTO> newsDTO = new List<NewsDTO>();
            var temp = new NewsDTO();

            foreach (var item in res)
            {
                temp.ID = item.ID;
                temp.NewsTitle = item.NewsTitle;
                newsDTO.Add(temp);
            }
            return Ok(newsDTO);
            //var res = _newsService.SearchByTitle(NewsTitle);
            //res.Select(a => new NewsDTO
            //{
            //    ID = a.ID,
            //    NewsTitle = a.NewsTitle
            //}).ToList();



            //return Ok(
            //    _newsService.SearchByTitle(NewsTitle).Select(
            //        a => new SelectListItem
            //    {
            //        Text = a.NewsTitle, 
            //        Value = a.ID.ToString()
            //    }));

        }
    }
}
