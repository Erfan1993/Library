﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using DataLayer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Utilities;


namespace NewsProject.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class UserController : ControllerBase
    {

        private IUserService _userService;
        private readonly IMapper _mapper;
        private readonly AppSettings _appSettings;
        public UserController(IUserService userService, IMapper mapper, IOptions<AppSettings> appSettings)
        {
            _appSettings = appSettings.Value;
            _mapper = mapper;
            _userService = userService;
        }
        [AllowAnonymous]
        [HttpPost]
        public IActionResult Register([FromBody] RegisterDTO registerUser)
        {
            User newsuser = new User()
            {
                UserName = registerUser.UserName,
                Name = "erfan",
                Family = "Jahani",
                Email = "Erfan.gmail.com",
                PhoneNumber = "09369935155"
            };

            var res = _userService.RegisterUser(newsuser, registerUser.Password);

            _userService.Save();
            // for test in postman
            return BadRequest("asdadasd");
        }

        [HttpPost]
        public IActionResult Login([FromBody] LoginDTO LoginUser)
        {

            var result = _userService.Authenticate(LoginUser.UserName, LoginUser.Password);
            if (result == null)
            {
                return BadRequest(new { Message = "User  Name and Password Incorrect" });
            }
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, result.ID.ToString())
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);
            return Ok(new
            {
                Id = result.ID,
                Username = result.UserName,
                FirstName = result.Family,
                LastName = result.Name,
                Token = tokenString
            });
        }
        [HttpGet]
        public IActionResult GetAllUsers()
        {
            string username = User.FindFirstValue(ClaimTypes.NameIdentifier);
            string Id = HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var res = User.IsInRole("Admin");
            return BadRequest();
        }
        [HttpPost]
        public IActionResult Logout()
        {
            return BadRequest();
        }
        [HttpPost]
        public IActionResult ChangePassword([FromBody] string Password)
        {
            return BadRequest();
        }
    }
}
