using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using DataLayer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Utilities;

namespace NewsProject
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }


        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();

            services.AddSingleton(Configuration);
            var mapperConfig = new MapperConfiguration(mc =>
            mc.AddProfile(new MappingProfile()));
            IMapper mapper = mapperConfig.CreateMapper();

            var appSettingsSection = Configuration.GetSection("AppSettings");
            services.Configure<AppSettings>(appSettingsSection);

            var appSettings = appSettingsSection.Get<AppSettings>();

            services.AddCustomAuthentication(appSettings);

            services.AddSwaggerSetting();

            services.AddSingleton(mapper);
            services.AddAutoMapper(typeof(Startup));

            services.AddControllers();
            services.AddScoped<INewsGroupService, NewsGroupRepository>();
            services.AddScoped<INewsService, NewsRepository>();
            services.AddScoped<IUserService, UserRepository>();
            services.AddScoped<ICommentService, CommentRepository>();


            services.AddDbContext<ApplicationContext>(option =>
            option.UseSqlServer(Configuration.GetConnectionString("NewsConnection")));
        }


        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseFileServer();
            app.UseStaticFiles();
            ////////////////////////////////////////////////////////
            app.UseCors(x => x
               .AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader());
            ////////////////////////////////////////////////////////

            app.UseAuthentication();
            app.UseAuthorization();
            ///////////////////////////////////////////////////////
            //app.UseEndpoints(endpoints =>
            //{
            //    endpoints.MapControllers();
            //    //endpoints.MapControllerRoute
            //    //(
            //    //    name: "Default",
            //    //    pattern: "{Controller=Home}/{Action=Index}/{id?}"
            //    //    );
            //    //endpoints.MapControllerRoute
            //    //(
            //    //    name:"Area",
            //    //    pattern:"{area:exists}/{Controller}/{Action=index}/{id?}"
            //    //    );
            //});
            app.UseRouting();
            app.UseEndpoints(end =>
            {
               end.MapControllers();
            });
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "v1");
            });
        }
    }
}
