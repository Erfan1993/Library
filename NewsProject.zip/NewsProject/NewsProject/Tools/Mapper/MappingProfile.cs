﻿using AutoMapper;
using DataLayer;
using System;
using System.Collections.Generic;
using System.Text;
using Utilities;

namespace NewsProject
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<NewsGroup, NewsGroupDTO>();
            CreateMap<NewsGroupDTO, NewsGroup>();
            ////////////////////////////////////////////////
            CreateMap<NewsDTO, News>();
            CreateMap<News, NewsDTO>();
            ////////////////////////////////////////////////
            CreateMap<User, RegisterDTO>();
            CreateMap<RegisterDTO, User>();
            ////////////////////////////////////////////////
            CreateMap<Comment, CommentsDTO>();
            CreateMap<CommentsDTO, Comment>();
            ////////////////////////////////////////////////
            CreateMap<News, NewsDTO>();
            CreateMap<NewsDTO, News>();
            ////////////////////////////////////////////////
        }
    }
}
