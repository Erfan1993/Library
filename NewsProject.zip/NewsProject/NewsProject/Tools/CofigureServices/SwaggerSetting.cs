﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsProject
{
    public static class SwaggerSetting
    {
        public static IServiceCollection AddSwaggerSetting(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
           {
               c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
               {
                   Version = "v1",
                   Title = "Swagger Demo",
                   Description = "Swagger Demo - angular-netcore.ir",
                   Contact = new Microsoft.OpenApi.Models.OpenApiContact()
                   {
                       Name = "Mohammad Moein Fazeli",
                       Email = "mmfazeli372@gmail.com"
                   }
               });
               c.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme()
               {
                   Description = "JWT Authorization header {token}",
                   Name = "Authorization"
               });
                //c.AddSecurityRequirement(new Dictionary<string, IEnumerable<string>>
                //{
                //    { "Bearer", new string[] { } }
                //});
            });
            return services;
        }
    }
}
