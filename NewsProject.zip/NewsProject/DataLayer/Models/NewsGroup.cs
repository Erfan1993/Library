﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataLayer
{
    public class NewsGroup
    {
        [Key]
        public int ID { get; set; }
        public string GroupTitle { get; set; }
        public string NewsGroupImage { get; set; }
        //-----------------------------------------------------------//
        public virtual List<News> News { get; set; }
        public NewsGroup()
        {

        }
    }
}
