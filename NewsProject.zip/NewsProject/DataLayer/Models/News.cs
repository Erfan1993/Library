﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataLayer
{
    public class News
    {
        [Key]
        public int ID { get; set; }
        public int GroupID { get; set; }
        public int UserID { get; set; }
        public string NewsTitle { get; set; }
        public string ShortDescription { get; set; }
        public string Text { get; set; }
        public string ImageName { get; set; }
        public DateTime CreatedTime { get; set; }
        public int Like { get; set; }
        public bool AddToSlider { get; set; }
        public bool IsReported { get; set; }

        // --------------------------------------------------------//

        public virtual List<Comment> Comments { get; set; }
        public virtual NewsGroup NewsGroup { get; set; }
        public User User { get; set; }
        public News()
        {

        }
    }
}
