﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataLayer
{
    public class Comment
    {
        [Key]
        public int ID { get; set; }
        public int NewsID { get; set; }
        public string CommentText { get; set; }
        public string UserName { get; set; }
        public DateTime CreatedTime { get; set; }
        public bool IsReported { get; set; }
        // --------------------- Navigation Property --------------------------//
        public virtual News News { get; set; }
        
    }
}
