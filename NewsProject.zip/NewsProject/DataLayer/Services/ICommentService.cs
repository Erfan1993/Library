﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public interface ICommentService
    {

        public IEnumerable<Comment> GetCummentsByNewsID(int id);
        public Comment FindComment(int id);
        public bool AddComment(Comment inComment);
        public bool DeleteComment(int id);
        public void ReportComment(int id);
        void SaveChanges();
    }
}
