﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public interface INewsService
    {
        IEnumerable<News> GetAllNews();
        IEnumerable<News> SearchNews(News news);
        IEnumerable<News> GetNewsByNewsGroupID(int id);
        IEnumerable<News> GetNewsByDate(DateTime StartDate, DateTime EndDate);
        IEnumerable<News> GetReportedNews();
        IEnumerable<News> SearchByTitle(string Title);
        void ReportNews(int id);
        void AddComment(Comment comment);
        News FindNewsByID(int id);
        bool DeleteNews(int id);
        bool CreateNews(News inNews);
        bool UpdateNews(News inNews);
        void Save();
    }
}
