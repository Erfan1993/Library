﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public interface IRoleService
    {
        public bool CreateRole(Role inRole);
        public bool DeleteRole(int id);
        public IEnumerable<Role> GetAllRoles();
        public Role GetRoleByID(int Roleid);
        void Save();
    }
}
