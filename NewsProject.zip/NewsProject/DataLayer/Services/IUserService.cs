﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public interface IUserService
    {
        public bool DeleteUser(int id);
        public IEnumerable<User> GetAllUsers();
        public User GetUserByID(int id);
        public User UpdateUser(int id, User newUser);
        public User RegisterUser(User NewsUser, string Password);
        public User Authenticate(string UserName, string Password);
        public void Save();
        public void Logout();
    }
}
