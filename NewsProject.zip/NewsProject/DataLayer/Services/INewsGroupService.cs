﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public interface INewsGroupService
    {
        IEnumerable<NewsGroup> GetAllNewsGroups();
        NewsGroup FindNewsGroup(int id);
        bool AddNewsGroup(NewsGroup inModel);
        bool DeleteNewsGroup(int id);
        bool UpdateNewsGroup(NewsGroup newsGroup);
        void save();
    }
}
