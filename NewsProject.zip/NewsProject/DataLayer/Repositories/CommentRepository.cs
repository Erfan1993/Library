﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer
{
    public class CommentRepository : ICommentService
    {
        private ApplicationContext _Context;
        public CommentRepository(ApplicationContext context)
        {
            _Context = context;
        }
        public bool AddComment(Comment inComment)
        {
            if (inComment == null)
            {
                return false;
            }
            else
            {
                _Context.Comments.Add(inComment);
                return true;
            }
        }
        public bool DeleteComment(int id)
        {
            if (id == 0)
            {
                return false;
            }
            else
            {
                var m = FindComment(id);
                _Context.Comments.Remove(m);
                return true;
            }
        }
        public Comment FindComment(int id)
        {
            if (id == 0)
            {
                return _Context.Comments.FirstOrDefault();
            }
            else
            {
                return _Context.Comments.Find(id);
            }
        }
        public IEnumerable<Comment> GetCummentsByNewsID(int id)
        {
            if (id == 0)
            {
                return _Context.Comments.ToList().Take(10);
            }
            else
            {
                return _Context.Comments.Where(a => a.NewsID == id).ToList();
            }
        }
        public void ReportComment(int id)
        {
            var model = FindComment(id);
            model.IsReported = true;
            _Context.Comments.Update(model);
        }
        public void SaveChanges()
        {
            _Context.SaveChanges();
        }
    }
}
