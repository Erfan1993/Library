﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer
{
    public class RoleRepository : IRoleService
    {
        private ApplicationContext _context;
        public RoleRepository(ApplicationContext context)
        {
            _context = context;
        }
        public bool CreateRole(Role inRole)
        {
            if (inRole == null)
            {
                return false;
            }
            else
            {
                _context.Roles.Add(inRole);
                return true;
            }
        }

        public bool DeleteRole(int id)
        {
            if (id == 0)
            {
                return false;
            }
            else
            {
                var m = GetRoleByID(id);
                _context.Roles.Remove(m);
                return true;
            }
        }

        public IEnumerable<Role> GetAllRoles()
        {
            return _context.Roles.ToList();
        }

        public Role GetRoleByID(int Roleid)
        {
            if (Roleid == 0)
            {
                return _context.Roles.FirstOrDefault();
            }
            else
            {
                return _context.Roles.Find(Roleid);
            }
        }

        public void Save()
        {
            _context.SaveChanges();
        }
    }
}
