﻿using DataLayer;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer
{
    public class NewsGroupRepository : INewsGroupService
    {
        private ApplicationContext _context;
        public NewsGroupRepository(ApplicationContext context)
        {
            _context = context;
        }
        public bool AddNewsGroup(NewsGroup inModel)
        {
            if (inModel == null)
            {
                return false;
            }
            else
            {
                _context.NewsGroups.Add(inModel);
                return true;
            }
        }
        public bool DeleteNewsGroup(int id)
        {
            if (id == 0)
            {
                return false;
            }
            else
            {
                var Group = FindNewsGroup(id);
                _context.NewsGroups.Remove(Group);
                return true;
            }
        }
        public NewsGroup FindNewsGroup(int id)
        {
            return _context.NewsGroups.Find(id);
        }
        public IEnumerable<NewsGroup> GetAllNewsGroups()
        {
            return _context.NewsGroups.ToList();
        }
        public bool UpdateNewsGroup(NewsGroup newsGroup)
        {
            if (newsGroup == null)
            {
                return false;
            }
            else
            {
                
                var res = FindNewsGroup(newsGroup.ID);
                if (res != null)
                {
                    _context.Entry(res).State = EntityState.Detached;
                }
                _context.Entry(newsGroup).State = EntityState.Modified;


                return true;
            }
        }
        public void save()
        {
            _context.SaveChanges();
        }
    }
}
