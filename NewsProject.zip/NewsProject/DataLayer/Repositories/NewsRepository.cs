﻿using DataLayer;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer
{
    public class NewsRepository : INewsService
    {
        private ApplicationContext _context;
        public NewsRepository(ApplicationContext context)
        {
            _context = context;
        }
        public void AddComment(Comment incomment)
        {
            _context.Comments.Add(incomment);
        }
        public bool CreateNews(News inNews)
        {
            if (inNews == null)
            {
                return false;
            }
            else
            {
                inNews.IsReported = false;
                _context.News.Add(inNews);
                return true;
            }
        }
        public bool DeleteNews(int id)
        {
            if (id <= 0)
            {
                return false;
            }
            else
            {
                var res = FindNewsByID(id);
                _context.News.Remove(res);
                return true;
            }

        }
        public News FindNewsByID(int id)
        {
            if (id <= 0)
            {
                return _context.News.FirstOrDefault();
            }
            else
            {
                return _context.News.Find(id);
            }
        }
        public IEnumerable<News> GetAllNews()
        {
            return _context.News.ToList();
        }
        public IEnumerable<News> GetNewsByDate(DateTime StartDate, DateTime EndDate)
        {
            if (StartDate == null)
            {
                return _context.News.Where(a => a.CreatedTime >= StartDate).ToList();
            }
            else if (EndDate == null)
            {
                return _context.News.Where(a => a.CreatedTime <= EndDate).ToList();
            }
            else
            {
                return _context.News.Where(a => a.CreatedTime >= StartDate && a.CreatedTime <= EndDate).ToList();
            }
        }
        public IEnumerable<News> GetNewsByNewsGroupID(int id)
        {
            if (id <= 0)
            {
                return _context.News.ToList().Take(10);
            }
            else
            {
                return _context.News.Where(a => a.GroupID == id);
            }
        }
        public IEnumerable<News> GetReportedNews()
        {
            return _context.News.Where(a => a.IsReported == true).ToList();
        }
        public void ReportNews(int id)
        {
            var model = FindNewsByID(id);
            model.IsReported = true;
            _context.News.Update(model);
        }
        public void Save()
        {
            _context.SaveChanges();
        }
        public IEnumerable<News> SearchByTitle(string Title)
        {
            if (Title == null)
            {
                return null;
            }
            else
            {
                return _context.News.Where(a => a.NewsTitle.Contains(Title)).ToList().Take(5);
            }
        }
        public IEnumerable<News> SearchNews(News news)
        {
            if (news != null)
            {
                var model = _context.News.Include(a => a.NewsGroup).ToList();
                var res =
                    model.Where(a => a.NewsGroup.GroupTitle == news.NewsGroup.GroupTitle)
                        .Where(a => a.NewsTitle == news.NewsTitle)
                        .Where(a => a.ShortDescription.Contains(news.ShortDescription))
                        .Where(a => a.CreatedTime == news.CreatedTime).ToList();

                return res;
            }
            else
            {
                return _context.News.ToList().Take(10);
            }
        }
        public bool UpdateNews(News inNews)
        {
            if (inNews != null)
            {
                //var r = FindNewsByID(inNews.ID);
                //r = inNews;
                //_context.News.Update(r);

                var res = FindNewsByID(inNews.ID);
                if (res != null)
                {
                    _context.Entry(res).State = EntityState.Detached;
                }
                _context.Entry(inNews).State = EntityState.Modified;


                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
