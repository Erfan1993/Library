﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class UserRepository : IUserService
    {
        private ApplicationContext _context;
        public UserRepository(ApplicationContext context)
        {
            _context = context;
        }
        public User Authenticate(string UserName, string Password)
        {
            if ((string.IsNullOrEmpty(UserName)) || (string.IsNullOrEmpty(Password)))
            {
                return null;
            }
            var result = _context.Users.FirstOrDefault(x => x.UserName == UserName);
            if (result == null)
            {
                return null;
            }
            //if (!VerifyPasswordHash(Password, result.PasswordHash, result.PasswordSalt))
            //{
            //    bool res = true;
            //}
            bool ress = VerifyPasswordHash(Password, result.PasswordHash, result.PasswordSalt);
            if (ress == true && result != null && result.UserName == UserName)
            {
                return result;
            }
            else
            {
                return null;
            }
        }
        public bool DeleteUser(int id)
        {
            if (id == 0)
            {
                return false;
            }
            else
            {
                var res = GetUserByID(id);
                _context.Users.Remove(res);
                return true;
            }
        }
        public IEnumerable<User> GetAllUsers()
        {
            return _context.Users.Include(a => a.Role).ToList();
        }
        public User GetUserByID(int id)
        {
            return _context.Users.Find(id);
        }
        public User RegisterUser(User NewsUser, string Password)
        {
            if (string.IsNullOrEmpty(Password))
            {
                throw new Exception("Password Is Required");
            }
            if (_context.Users.Any(a => a.UserName == NewsUser.UserName))
            {
                throw new Exception("UserName " + NewsUser.UserName + " is already taken");
            }
            byte[] PasswordHash, Passwordsalt;
            CreatePasswordHash(Password, out PasswordHash, out Passwordsalt);
            NewsUser.PasswordHash = PasswordHash;
            NewsUser.PasswordSalt = Passwordsalt;
            NewsUser.RoleID = 1;

            NewsUser.Role = _context.Roles.Where(a => a.ID == 1).FirstOrDefault();
            _context.Users.Add(NewsUser);
            return NewsUser;
        }
        public void Save()
        {
            _context.SaveChanges();
        }
        public User UpdateUser(int id, User newUser)
        {
            throw new NotImplementedException();
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////
        private static void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");

            using (var hmac = new System.Security.Cryptography.HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }
        ////////////////////////////////////////////////////////////////////
        private static bool VerifyPasswordHash(string password, byte[] storedHash, byte[] storedSalt)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");
            if (storedHash.Length != 64) throw new ArgumentException("Invalid length of password hash (64 bytes expected).", "passwordHash");
            if (storedSalt.Length != 128) throw new ArgumentException("Invalid length of password salt (128 bytes expected).", "passwordHash");

            using (var hmac = new System.Security.Cryptography.HMACSHA512(storedSalt))
            {
                var computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                for (int i = 0; i < computedHash.Length; i++)
                {
                    if (computedHash[i] != storedHash[i]) return false;
                }
            }

            return true;
        }

        public void Logout()
        {
            throw new NotImplementedException();
        }
    }
}
