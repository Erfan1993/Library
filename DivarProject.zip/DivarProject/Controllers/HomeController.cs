﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataLayer.Models;
using DataLayer.Services;
using Microsoft.AspNetCore.Mvc;
using ViewModelLayer.NotifyViewModels;

namespace DivarProject.Controllers
{
    public class HomeController : Controller
    {
        private INotifyServices _notifyServices;
        private IAccountService _accountService;

        public HomeController(
            INotifyServices notifyServices
            , IAccountService accountService)
        {
            _notifyServices = notifyServices;
            _accountService = accountService;
        }
        public IActionResult Index(List<ShowNotifyViewModel> result)
        {
            if (result.Count == 0)
            {
                var res = _notifyServices.GetAllNotify().Take(10);
                var output = new List<ShowNotifyViewModel>();
                foreach (var item in res)
                {
                    ShowNotifyViewModel m = new ShowNotifyViewModel()
                    {
                        CityName = item.CityName,
                        CountryName = item.CountryName,
                        NotifyTitle = item.NotifyTitle,
                        Price = item.Price,
                        StateName = item.StateName,
                        NotifyID = item.NotifyID,
                        Image = item.Image
                    };
                    output.Add(m);
                }
                return View(output);
            }
            else
            {
                return View(result);
            }
        }
        public IActionResult ShowNotify(int id)
        {
            var model = _notifyServices.GetNotifyByID(id);

            var result = new ShowNotifyViewModel()
            {
                NotifyID = model.NotifyID,
                NotifyTitle = model.NotifyTitle,
                Price = model.Price,
                StateName = model.StateName,
                PhoneNumber = model.PhoneNumber.ToString(),
                CountryName = model.CountryName,
                CityName = model.CityName,
                Image = model.Image,
            };
            result.UserName = _accountService.GetserNamebyUserID(model.UserID);
            return View(result);
        }

        public IActionResult SerachNotify(
            string NotifyName
            , int MinPrice
            , int MaxPrice
            , string CountryName
            , string StateName
            , string CityName)
        {

            var models = _notifyServices.SearchNotify(NotifyName, MaxPrice, MinPrice, CountryName, StateName, CityName);
            List<ShowNotifyViewModel> result = new List<ShowNotifyViewModel>();
            foreach (var item in models)
            {
                ShowNotifyViewModel m = new ShowNotifyViewModel()
                {
                    CityName = item.CityName,
                    CountryName = item.CountryName,
                    NotifyTitle = item.NotifyTitle,
                    Price = item.Price,
                    StateName = item.StateName,
                    NotifyID = item.NotifyID,
                    Image = item.Image
                };
                result.Add(m);
            }


            return RedirectToAction("Index", new { result= result.ToList()});
        }



    }
}