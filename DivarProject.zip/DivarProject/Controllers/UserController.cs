﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DataLayer.Models;
using DataLayer.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using ViewModelLayer.NotifyViewModels;

namespace DivarProject.Controllers
{
    public class UserController : Controller
    {
        private readonly INotifyServices _notifyServices;
        private IAccountService _accountService;

        private IServiceProvider _serviceProvider;
        private IHostingEnvironment _AppEnvironment;

        public UserController(
              INotifyServices notify
            , IAccountService accountService
            , IServiceProvider serviceProvider
            , IHostingEnvironment appEnvironment)
        {
            _notifyServices = notify;
            _accountService = accountService;
            _serviceProvider = serviceProvider;
            _AppEnvironment = appEnvironment;
        }
        [Authorize]
        public IActionResult Index()
        {
            string UserID = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var res = _accountService.GetserNamebyUserID(UserID).ToString();
            return View("index",res.ToString());
        }
        [HttpGet]
        [Authorize]
        public IActionResult CreateNotify()
        {
            string UserID = User.FindFirstValue(ClaimTypes.NameIdentifier);
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CreateNotify(CreateNotifyViewModel model)
        {
            if (ModelState.IsValid)
            {
                NotifyModel notifymodel = new NotifyModel
                {
                    UserID = User.FindFirstValue(ClaimTypes.NameIdentifier),
                    NotifyTitle = model.NotifyTitle,
                    Price = model.Price,
                    CountryName = model.CountryName,
                    StateName = model.StateName,
                    CityName = model.CityName,
                    Date = DateTime.Now,
                    PhoneNumber = model.PhoneNumber
                };

                var Imagemodel = model.Image;
                if (Imagemodel != null && Imagemodel.Length > 0)
                {
                    var uploads = Path.Combine(_AppEnvironment.WebRootPath, @"NormalImage\");
                    if (Imagemodel.Length > 0)
                    {
                        var fileName = Guid.NewGuid().ToString().Replace("-", "") + Path.GetExtension(Imagemodel.FileName);
                        using (var fileStream = new FileStream(Path.Combine(uploads, fileName), FileMode.Create))
                        {
                            await Imagemodel.CopyToAsync(fileStream);
                            notifymodel.Image = fileName;
                        }
                    }
                }
                _notifyServices.CreateNotidy(notifymodel);
                _notifyServices.Save();
            }
            return View();
        }
        //[Authorize]
        public IActionResult ShowUserNotifies()
        {
            string UserID = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var model = _notifyServices.GetNotifyByUserID(UserID);
            var result = new List<ShowNotifyViewModel>();
            foreach (var item in model)
            {
                var m = new ShowNotifyViewModel();
                var res = new ShowNotifyViewModel()
                {
                    NotifyID = item.NotifyID,
                    NotifyTitle = item.NotifyTitle,
                    Price = item.Price,
                    StateName = item.StateName,
                    PhoneNumber = item.PhoneNumber.ToString(),
                    CountryName = item.CountryName,
                    CityName = item.CityName,
                    Image = item.Image,
                };
                result.Add(res);
            }
            return View(result);
        }
        public IActionResult DeleteNotify(int id)
        {
            _notifyServices.DeleteNotify(id);
            _notifyServices.Save();
            return RedirectToAction("ShowUserNotifies","User");
        }
    }
}