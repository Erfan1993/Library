﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataLayer.IdentityModels;
using DataLayer.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using ViewModels.AccountViewModel;
using ViewModels.AccountViewModels;

namespace DivarProject.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<UserModel> _usermanager;
        private readonly SignInManager<UserModel> _signInManager;
        private readonly RoleManager<RolesModel> _roleManager;
        private IAccountService _AccountService;


        public AccountController(
              IAccountService accountService
            , RoleManager<RolesModel> roleManager
            , SignInManager<UserModel> signInManager
            , UserManager<UserModel> userManager)
        {
            _AccountService = accountService;
            _signInManager = signInManager;
            _usermanager = userManager;
        }
        //////////Authentication///////////////////////////////////////////////////////////////////////
        [HttpGet]
        public IActionResult Login()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        //public IActionResult login(UserLoginViewModel inputModel)
        //{
        public async Task<IActionResult> Login(UserLoginViewModel model, IFormCollection form)
        {
            //string urlToPost = "https://www.google.com/recaptcha/api/siteverify";
            //string secretKey = "6LcI9rIUAAAAADEW-pHPQAfVhVExQYU4qmYiLnsB"; // change this
            //string gRecaptchaResponse = form["g-recaptcha-response"];

            //var postData = "secret=" + secretKey + "&response=" + gRecaptchaResponse;

            //// send post data
            //HttpWebRequest request = (HttpWebRequest)WebRequest.Create(urlToPost);
            //request.Method = "POST";
            //request.ContentLength = postData.Length;
            //request.ContentType = "application/x-www-form-urlencoded";

            //using (var streamWriter = new StreamWriter(request.GetRequestStream()))
            //{
            //    streamWriter.Write(postData);
            //}

            //// receive the response now
            //string result = string.Empty;
            //using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            //{
            //    using (var reader = new StreamReader(response.GetResponseStream()))
            //    {
            //        result = reader.ReadToEnd();
            //    }
            //}

            //// validate the response from Google reCaptcha
            //var captChaesponse = JsonConvert.DeserializeObject<ReCaptchaResponse>(result);
            //if (!captChaesponse.Success)
            //{
            //    ViewBag.Message = "Sorry, please validate the reCAPTCHA";
            //    return View();
            //}
            if (ModelState.IsValid)
            {
                var loginresult =
                    await _signInManager
                    .PasswordSignInAsync(model.UserName, model.Password, model.RememberMe, lockoutOnFailure: false);
                if (loginresult.Succeeded)
                {
                    var usert = User.Identity.IsAuthenticated;
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid Login Information");
                }
            }
            return View();
            //}
            //if (ModelState.IsValid)
            //{
            //       var result = _userService.Login(inputModel.UserName, inputModel.Password, inputModel.RememberMe);
            //        if (result==true)
            //        {
            //            return RedirectToAction("Index", "Home");
            //        }
            //        else
            //        {
            //        return View("_ExeptionPage", "Login Was Not Complete Because Wrong Information");
            //    }
            //}
            //else
            //{
            //    return View("_ExeptionPage","Wrong Login Information You Entered");
            //}
        }
        public IActionResult Logout()
        {
            _AccountService.Logout();
            return RedirectToAction("Index", "Home");
        }
        //////////Authentication///////////////////////////////////////////////////////////////////////

        //////////Users///////////////////////////////////////////////////////////////////////
        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(UserRegisterViewModel inputModel)
        {
            if (ModelState.IsValid)
            {
                var user = new UserModel
                {
                    Email = inputModel.EmailAddress,
                    Family = inputModel.Family,
                    Name = inputModel.Name,
                    NationCode = inputModel.NationCode,
                    PhoneNumber = inputModel.PhoneNumber,
                    UserName = inputModel.UserName
                };
                var result = _AccountService.RegisterUser(user, inputModel.Password, inputModel.ConfirmPassword);
                if (result == true)
                {
                    _AccountService.AddToRole(user, "User");
                    return RedirectToAction("Login", "Account");
                }
                else
                {
                    return View("_ExeptionPage", "You Must Insert Correct Information");
                }
            }
            else
            {
                return View("_ExeptionPage", "Wrong Information You Entered");
            }
        }
        public IActionResult DeleteAccount()
        {
            return View();
        }
        //////////Users///////////////////////////////////////////////////////////////////////

        //////////Roles///////////////////////////////////////////////////////////////////////
        [HttpGet]
        public IActionResult RoleList()
        {
            var model = _AccountService.GetAllRoles();
            List<RolesViewModel> outputmodel = new List<RolesViewModel>();
            foreach (var item in model)
            {
                RolesViewModel m = new RolesViewModel();
                m.RoleID = item.Id;
                m.RoleName = item.Name;
                m.Role = item.NormalizedName;
                outputmodel.Add(m);
            }
            return View(outputmodel);
        }

        [HttpGet]
        public IActionResult CreateRole()
        {
            return View();
        }

        [HttpGet]
        public IActionResult EditRole(string Id)
        {
            var model = _AccountService.FindRole(Id);
            RolesViewModel outputmodel = new RolesViewModel();
            outputmodel.RoleID = model.Id;
            outputmodel.Role = model.NormalizedName;
            outputmodel.RoleName = model.Name;
            return View(outputmodel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateEditRole(RolesViewModel inputRole)
        {
            if (inputRole.RoleID == null)
            {
                var model = new RolesModel
                {
                    Name = inputRole.RoleName,
                    NormalizedName = inputRole.Role
                };
                bool res = _AccountService.CreateRole(model);
                if (res == true)
                {
                    return RedirectToAction("RoleList", "Account");
                }
                else
                {
                    //error 
                }
            }
            else if (inputRole.RoleID != null)
            {
                var model = new RolesModel
                {
                    Id = inputRole.RoleID,
                    Name = inputRole.RoleName,
                    NormalizedName = inputRole.Role
                };
                bool result = _AccountService.EditRole(model);
                if (result == true)
                {
                    return RedirectToAction("RoleList", "Account");
                }
                else
                {
                    return RedirectToAction("RoleList", "Account");
                }

            }
            return RedirectToAction("RoleList", "Account");
        }

        [HttpGet]
        public IActionResult DeleteRole(string Id)
        {
            var model = _AccountService.FindRole(Id);
            RolesViewModel outputmodel = new RolesViewModel();
            outputmodel.RoleID = model.Id;
            outputmodel.Role = model.NormalizedName;
            outputmodel.RoleName = model.Name;
            return View(outputmodel);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteRole(string Id, IFormCollection form)
        {
            bool result = _AccountService.Delete(Id);
            if (result == true)
            {
                return RedirectToAction("RoleList", "Account");
            }
            else
            {
                //Redirect to error Page
                return RedirectToAction("RoleList", "Account");
            }
        }
    }
}